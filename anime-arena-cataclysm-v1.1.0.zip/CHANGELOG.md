# Changelog

All notable changes to **ANIME ARENA: CATACLYSM — 3D RANDOM BATTLE** are documented in this file following Semantic Versioning.

## [1.1.0] — 2026-11-14

### Added

#### 1. Roster Expansion — 12 Validated Original Fighters
- Added **Zephyrion Vale** — *Sovereign of the Frost-Moon Blade* (`S+` Tier, Crystal dual-katana **Duelist**): Twin Frost-Fang Cross, Glacier Severance, Hoarfrost Mirage Step, Mirror-Ice Riposte, Lotus of Absolute Zero, and the **Zero-Kelvin Dimension Slash** ultimate.
- Added **Solaria Vex** — *Valkyrie of the Plasma Singularity* (`S` Tier, Photon lance-cannon **Tactician**): Plasma Lance Barrage, Hyper-Thruster Impale, Afterburner Vector Boost, Aegis Phase-Matrix, Valkyrie Ion Cannon, and the **Heaven-Fall Orbital Convergence** ultimate.
- Added new appearance archetypes: `dual-katanas`, `lance-cannon` weapons; `silver-ponytail`, `valkyrie-crest` hair; `frost-lotus`, `plasma-thrusters` accessories — all fully modelled in the procedural 3D rig, Character Studio dropdowns, and the glTF asset generator (18 assets, 12 eligible rigs).

#### 2. Anime Clash Lock (Blade / Beam Clash) System
- New `ClashLockRuntime` simulation entity: two fighters can lock weapons (`blade-clash`) or collide opposing energy signatures (`beam-clash`) into a timed struggle.
- Clash requires both fighters to be mid-offensive at close range; Duelist/Juggernaut archetypes and beam-capable kits receive a clash frequency bonus.
- Momentum is resolved deterministically tick-by-tick from attack stat, Awakening state, slow/stun debuffs, and seeded jitter.
- Losers take a dominance-scaled breakthrough hit, are stunned and shoved; winners gain 34 energy, an attack buff, and a `clashesWon` stat credit.
- Locked fighters are physically pinned (zero velocity, forced facing) and emit `clash-burst` spark VFX throughout the struggle.
- Full `CLASH_LOCK` event stream, replay-safe snapshots, tactical radar ping, HUD badge, and breakthrough outcome card.

#### 3. Stage-Specific Mid-Battle Arena Cataclysm Events
- New `src/data/cataclysmEvents.ts` with 8 signature phenomena: **Skyfall Meteor, Runic Consecration, Plasma Meltdown, EMP Overload, Gravity Collapse, Star-Core Implosion, Aether Flood, Shatter Rain**.
- Each arena owns a themed cataclysm pool, and each event declares which arena stages it can fire in, its telegraph length, danger radius, and damage.
- Cataclysms target the most crowded region of the arena (seeded sampling), telegraph with a warning banner + countdown + descending meteor pillar, then detonate for radial damage.
- Event-specific secondary effects: energy drain (EMP), attack blessing (Runic), gravity pull (Collapse), burn (Plasma), shred (Star-Core / Shatter), slow (Aether Flood), stun (Skyfall).
- Events fire on a stage-scaled cadence (Stage I: 30s → Stage III: 17s) and are fully recorded in the replay event stream.

#### 4. 3D Cinematic Upgrade — Ribbons, Afterimages, Expressions & Bullet-Time
- **3D weapon slash ribbons**: three additive crescent meshes that expand, spin and fade per swing, scaled up for Signature Skills and Ultimates.
- **Dash & Awakening afterimages**: up to four translucent capsule ghosts trail high-velocity movement, ascension bursts, and ultimate poses.
- **Dynamic anime facial expressions**: eyes and brow blades narrow into a killing glare during Ultimates, blow wide on Awakening, and close on elimination; eye emissive glows react to `isAwakened`.
- **Off-hand weapon rig** for dual-katana and dagger fighters, plus dedicated `dual-katanas` and `lance-cannon` weapon meshes.
- **Clash Lock scene visuals**: crossed 3D blades/colliding beam shards, rotating spark corona and a ground shock ring at every struggle.
- **Arena Cataclysm theatre**: danger-ring telegraph, pulsing fill, descending meteor cone and support column.
- **Slow-motion final blow (0.2x bullet-time)**: the director detects the killing blow of the final elimination and locks into a tight orbiting finisher shot with letterbox bars and a speed-line field while the simulation clock runs at 0.2x.

#### 5. UI Upgrade — Tactical Radar, Cut-In Banner & GLB Inspector
- **`TacticalRadar` minimap**: full top-down arena with boundary/tactical rings, rotating sweep, fighter blips with facing wedges, awakened halo, Ultimate pulses, alliance tethers, sanctuary/hazard zones, clash markers, and cataclysm danger circles. Clicking a blip switches to the follow camera.
- **`UltimateCutIn` full-screen anime banner**: diagonal speed lines, skewed colour slash band, character silhouette plate, oversized slanted ability typography, and the fighter's signature voice line — triggered for Ultimates, Awakenings, and Clash Locks in both live and replay playback.
- **Cataclysm warning banner** with live impact countdown, plus a **clash breakthrough outcome card**.
- **Character Studio `.glb` / `.gltf` drag-and-drop inspection**: new `inspectGltfFile` / `inspectGltfAssetFile` / `parseGlbContainer` pipeline functions parse binary GLB chunk-by-chunk (JSON + BIN), report glTF version, generator, node/mesh/material/texture/animation counts, joint coverage against the 22-bone contract, 13-clip animation coverage, embedded buffer size, diagnostics and hard errors, and sync the draft's provenance record.

#### 6. Simulation Pacing & Quality
- **Calibrated Spectator Pacing**: damage scaling is now anchored to a measured baseline (Fast ≈ 90s, Standard ≈ 135s, Epic ≈ 210s) with a late-game "finishing pressure" ramp that prevents stalled matches, so the advertised broadcast windows are actually met.
- Extended combat state: `clashesWon` stat, `clashLockEnabled` and `cataclysmEventsEnabled` settings toggles exposed in Advanced Arena Settings.
- Replay payload schema bumped to `1.1.0` with backward-compatible `1.0.0` import support.
- Test suite expanded to **11 tests across 2 files**, including clash resolution, cataclysm telegraph/impact, binary GLB round-trip parsing, 12-character determinism, and a mounted `BattleSpectatorView` integration smoke test.

### Fixed
- Fixed fighters retaining stale velocity inside the first frame of a Clash Lock.
- Fixed the auto-director camera orbiting a long-dead finisher after the bullet-time window closed.

## [1.0.0] — 2026-11-14

### Added
- **Milestone 0 (Project Bootstrap)**:
  - Created isolated Vercel project `anime-arena-cataclysm` (`prj_SqYbnVcKaSezSDYSvxug39MrMSM1`).
  - Established TypeScript + Vite + React 18 + Three.js modular architecture and ADR-001.
  - Created automated glTF 2.0 asset generator and validator (`scripts/generate-assets.mjs`, `scripts/validate-assets.mjs`).
- **Milestone 1 & 2 (Complete Playable Vertical Slice & Content Expansion)**:
  - Implemented 10 original, 9-point validated 3D anime characters (`Kaelen Vance`, `Vespera Noctis`, `Raiden Kurogami`, `Seraphina Solis`, `Zero-Nine (Akira)`, `Malakor the Unbound`, `Lyra Celestis`, `Ryuji Kazama`, `Nyx Valeria`, `Orion Solaris`).
  - Implemented 3 polished Dynamic Living Arenas (`Aetherium Sanctum`, `Neo-Kyoto Crater`, `Obsidian Rift`) with 3 dynamic stages, weather particles, central shrine blessings, and 10 destructible objects per arena.
  - Built authoritative fixed-timestep `BattleSimulation` engine with Hybrid Power Balance, elemental cross-reactions, counters/parries, Awakenings, and Signature Ultimates.
  - Built Local Hybrid AI combining Utility AI intent scoring, Behavior Trees, fighter memory, and an `8x8` dynamic relationship matrix supporting alliances and betrayals.
- **Milestone 3 (Spectator Experience)**:
  - Implemented Intelligent Automatic Cinematic Director Camera, Wide Spectator Camera, and Character Follow Camera.
  - Implemented toggleable **Cinematic HUD** and **Tactical HUD**, playback speed controls (`0.5x`, `1x`, `2x`, `4x`), live combat log, and full post-battle 8-character analytics modal.
- **Milestone 4 (Replay & Persistence)**:
  - Built `HybridReplayController` with timeline scrubbing, snapshot interpolation, and deterministic seed re-simulation verification.
  - Built persistent IndexedDB `BattleArchive` with search, sort, rename, delete, and versioned JSON export/import.
  - Built `ArenaChronicle` computing authentic historical win rates, K/D ratios, Hall of Fame, rivalries, and 12 unlockable achievements.
- **Milestone 5 & 6 (Character Studio, Audio, Settings & Production QA)**:
  - Built `Original Character Studio` with live 3D rig turntable, 13 animation state previews, appearance/ability/AI editor, and Blender-compatible glTF 2.0 import/export.
  - Built 4-bus spatial WebAudio synthesizer (`music`, `sfx`, `voice`, `ambient`) and `Advanced Arena Settings` with presets and Ultra/High/Medium/Low graphics quality controls.
  - Added automated Vitest QA suite (`tests/simulationAndSystems.test.ts`) verifying all core systems.
