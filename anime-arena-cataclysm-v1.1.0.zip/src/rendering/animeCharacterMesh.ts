import * as THREE from 'three';
import {
  CharacterDefinition,
  FighterAnimationState,
  GraphicsQualityPreset,
} from '../types/game';

let cachedToonGradientMap: THREE.DataTexture | null = null;

/**
 * Generates a crisp 4-band anime cel-shading ramp texture using NearestFilter.
 */
export function getAnimeCelGradientMap(): THREE.DataTexture {
  if (cachedToonGradientMap) return cachedToonGradientMap;
  const colors = new Uint8Array([
    68, 68, 78, 255,   // Deep anime shadow band
    138, 138, 152, 255, // Mid-shadow band
    215, 215, 228, 255, // Lit band
    255, 255, 255, 255, // Specular rim band
  ]);
  const texture = new THREE.DataTexture(colors, 4, 1, THREE.RGBAFormat);
  texture.minFilter = THREE.NearestFilter;
  texture.magFilter = THREE.NearestFilter;
  texture.generateMipmaps = false;
  texture.needsUpdate = true;
  cachedToonGradientMap = texture;
  return texture;
}

export interface ArticulatedCharacterRig {
  characterId: string;
  root: THREE.Group;
  hips: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  hair: THREE.Group;
  accessory: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  weapon: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  auraRing: THREE.Mesh;
  awakeningCorona: THREE.Mesh;
  guardDome: THREE.Mesh;
  targetLine?: THREE.Line;
  // v1.1.0 cinematic upgrades
  /** Eye pieces whose scale/emissive react to combat emotion */
  eyes: {
    left: THREE.Mesh;
    right: THREE.Mesh;
    leftBrow: THREE.Mesh;
    rightBrow: THREE.Mesh;
    material: THREE.MeshBasicMaterial;
  };
  /** Cyclone of 3D weapon slash ribbons driven by the active ability */
  slashRibbons: {
    group: THREE.Group;
    meshes: THREE.Mesh[];
  };
  /** Ghost silhouettes left behind during dashes and awakening bursts */
  afterimages: {
    group: THREE.Group;
    ghosts: THREE.Mesh[];
    material: THREE.MeshBasicMaterial;
  };
  /** Secondary off-hand weapon (dual katanas / focus talisman) */
  offhandWeapon?: THREE.Group;
  previousPosition: THREE.Vector3;
  facingAngle: number;
}

function createCelMaterial(hexColor: string, emissiveHex?: string, emissiveIntensity = 0.15): THREE.MeshToonMaterial {
  return new THREE.MeshToonMaterial({
    color: new THREE.Color(hexColor),
    gradientMap: getAnimeCelGradientMap(),
    emissive: emissiveHex ? new THREE.Color(emissiveHex) : new THREE.Color(hexColor),
    emissiveIntensity,
  });
}

function addOutlineSubmesh(mesh: THREE.Mesh, thickness = 0.032): void {
  const outlineMat = new THREE.MeshBasicMaterial({
    color: 0x070912,
    side: THREE.BackSide,
  });
  const outline = new THREE.Mesh(mesh.geometry, outlineMat);
  outline.scale.setScalar(1 + thickness);
  outline.name = 'cel_outline';
  mesh.add(outline);
}

export function buildArticulatedAnimeCharacter(
  def: CharacterDefinition,
  quality: GraphicsQualityPreset = 'Ultra'
): ArticulatedCharacterRig {
  const enableOutlines = quality === 'Ultra' || quality === 'High';
  const segs = quality === 'Low' ? 8 : quality === 'Medium' ? 12 : 16;

  const root = new THREE.Group();
  root.name = `Fighter_${def.id}`;
  const scale = def.appearance.heightScale || 1.0;
  root.scale.setScalar(scale);

  const primaryMat = createCelMaterial(def.appearance.primaryColor, def.appearance.primaryColor, 0.14);
  const secondaryMat = createCelMaterial(def.appearance.secondaryColor, '#000000', 0.04);
  const accentMat = createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.35);
  const skinMat = createCelMaterial(def.appearance.skinTone, def.appearance.skinTone, 0.06);
  const hairMat = createCelMaterial(def.appearance.hairColor, def.appearance.hairColor, 0.18);

  const hips = new THREE.Group();
  hips.position.set(0, 0.95, 0);
  root.add(hips);

  // --- TORSO & ANIME COAT ---
  const torso = new THREE.Group();
  hips.add(torso);

  const chestMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.28, 0.21, 0.68, segs),
    secondaryMat
  );
  chestMesh.position.set(0, 0.34, 0);
  chestMesh.castShadow = quality !== 'Low';
  if (enableOutlines) addOutlineSubmesh(chestMesh, 0.04);
  torso.add(chestMesh);

  // Anime Jacket / Armor Mantle
  const coatFlair = new THREE.Mesh(
    new THREE.ConeGeometry(0.38, 0.56, segs, 1, true),
    primaryMat
  );
  coatFlair.position.set(0, 0.05, 0);
  torso.add(coatFlair);

  // Glowing Astral Core Crest on Chest
  const chestCore = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.1, 0),
    accentMat
  );
  chestCore.position.set(0, 0.44, 0.25);
  torso.add(chestCore);

  // --- HEAD, ANIME EYES & STYLIZED HAIR ---
  const head = new THREE.Group();
  head.position.set(0, 0.82, 0);
  torso.add(head);

  const headSphere = new THREE.Mesh(
    new THREE.SphereGeometry(0.24, segs, segs),
    skinMat
  );
  headSphere.scale.set(0.95, 1.05, 0.96);
  headSphere.castShadow = quality !== 'Low';
  if (enableOutlines) addOutlineSubmesh(headSphere, 0.045);
  head.add(headSphere);

  // Glowing Anime Eyes (v1.1.0: dynamic expression rig)
  const eyeMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(def.appearance.eyeColor) });
  eyeMat.userData.baseEyeColor = new THREE.Color(def.appearance.eyeColor);
  const eyeGeo = new THREE.BoxGeometry(0.075, 0.052, 0.03);
  const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
  leftEye.position.set(-0.082, 0.02, 0.222);
  const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
  rightEye.position.set(0.082, 0.02, 0.222);
  head.add(leftEye, rightEye);

  // Angry anime eyebrow blades that tilt with combat emotion
  const browMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(def.appearance.hairColor) });
  const browGeo = new THREE.BoxGeometry(0.095, 0.016, 0.02);
  const leftBrow = new THREE.Mesh(browGeo, browMat);
  leftBrow.position.set(-0.082, 0.088, 0.238);
  leftBrow.rotation.z = 0.16;
  const rightBrow = new THREE.Mesh(browGeo, browMat);
  rightBrow.position.set(0.082, 0.088, 0.238);
  rightBrow.rotation.z = -0.16;
  head.add(leftBrow, rightBrow);

  // Distinct Hair Silhouette
  const hair = new THREE.Group();
  head.add(hair);

  const hairCap = new THREE.Mesh(
    new THREE.SphereGeometry(0.255, segs, segs, 0, Math.PI * 2, 0, Math.PI * 0.65),
    hairMat
  );
  hairCap.position.set(0, 0.03, -0.02);
  hair.add(hairCap);

  if (def.appearance.hairStyle === 'twintails') {
    for (const side of [-1, 1]) {
      const tail = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.72, 8), hairMat);
      tail.position.set(side * 0.28, -0.18, -0.1);
      tail.rotation.z = side * 0.35;
      tail.rotation.x = 0.25;
      hair.add(tail);
    }
  } else if (def.appearance.hairStyle === 'horned-mane') {
    const hornMat = createCelMaterial('#1f2937', def.appearance.accentColor, 0.4);
    for (const side of [-1, 1]) {
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.38, 8), hornMat);
      horn.position.set(side * 0.16, 0.28, 0.05);
      horn.rotation.z = -side * 0.35;
      horn.rotation.x = -0.2;
      hair.add(horn);
    }
  } else if (def.appearance.hairStyle === 'silver-ponytail' || def.appearance.hairStyle === 'ribbon-long') {
    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.9 * 0.14, 0.98, 8), hairMat);
    tail.position.set(0, -0.22, -0.24);
    tail.rotation.x = 0.35;
    hair.add(tail);
    const tie = new THREE.Mesh(new THREE.TorusGeometry(0.075, 0.02, 6, 12), createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.4));
    tie.position.set(0, 0.16, -0.2);
    tie.rotation.x = Math.PI / 2;
    hair.add(tie);
    for (const side of [-1, 1]) {
      const fringe = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.24, 6), hairMat);
      fringe.position.set(side * 0.12, 0.12, 0.17);
      fringe.rotation.x = 0.5;
      hair.add(fringe);
    }
  } else if (def.appearance.hairStyle === 'valkyrie-crest' || def.appearance.hairStyle === 'visor-crop') {
    // Swept-back crest with a bright central blade
    const crest = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.46, 0.2), hairMat);
    crest.position.set(0, 0.24, -0.02);
    crest.rotation.x = -0.32;
    hair.add(crest);
    for (const side of [-1, 1]) {
      const sweep = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.4, 6), hairMat);
      sweep.position.set(side * 0.19, 0.1, -0.06);
      sweep.rotation.z = side * 1.15;
      sweep.rotation.x = -0.2;
      hair.add(sweep);
    }
    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(0.4, 0.05, 0.04),
      createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.75)
    );
    visor.position.set(0, 0.06, 0.22);
    head.add(visor);
  } else {
    // Stylized anime hair spikes
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.085, 0.32, 6), hairMat);
      spike.position.set(Math.sin(angle) * 0.18, 0.18, Math.cos(angle) * 0.16 - 0.04);
      spike.rotation.x = Math.cos(angle) * 0.55 - 0.2;
      spike.rotation.z = -Math.sin(angle) * 0.55;
      hair.add(spike);
    }
  }

  // --- DISTINCTIVE BACK ACCESSORY / WINGS / HALO / CAPE ---
  const accessory = new THREE.Group();
  accessory.position.set(0, 0.55, -0.22);
  torso.add(accessory);

  if (def.appearance.accessory === 'astral-halo' || def.appearance.accessory === 'chrono-ring') {
    const halo = new THREE.Mesh(
      new THREE.TorusGeometry(0.55, 0.035, 8, 24),
      accentMat
    );
    halo.position.set(0, 0.25, -0.15);
    accessory.add(halo);
  } else if (def.appearance.accessory === 'solar-wings') {
    for (const side of [-1, 1]) {
      for (let w = 0; w < 3; w++) {
        const wingBlade = new THREE.Mesh(
          new THREE.BoxGeometry(0.68 - w * 0.12, 0.09, 0.03),
          accentMat
        );
        wingBlade.position.set(side * (0.38 + w * 0.06), 0.18 - w * 0.16, -0.1);
        wingBlade.rotation.z = side * (0.35 - w * 0.22);
        accessory.add(wingBlade);
      }
    }
  } else if (def.appearance.accessory === 'frost-lotus') {
    // Eight-petal crystalline frost lotus hovering behind the shoulders
    for (let p = 0; p < 8; p++) {
      const a = (p / 8) * Math.PI * 2;
      const petal = new THREE.Mesh(
        new THREE.ConeGeometry(0.085, 0.52, 5),
        createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.6)
      );
      petal.position.set(Math.cos(a) * 0.34, 0.1 + Math.sin(a) * 0.34, -0.16);
      petal.rotation.z = -a + Math.PI / 2;
      accessory.add(petal);
    }
    const heart = new THREE.Mesh(new THREE.OctahedronGeometry(0.12, 0), accentMat);
    heart.position.set(0, 0.1, -0.16);
    accessory.add(heart);
  } else if (def.appearance.accessory === 'plasma-thrusters') {
    for (const side of [-1, 1]) {
      const thruster = new THREE.Mesh(
        new THREE.CylinderGeometry(0.085, 0.11, 0.44, 8),
        createCelMaterial(def.appearance.secondaryColor, def.appearance.accentColor, 0.3)
      );
      thruster.position.set(side * 0.3, -0.02, -0.16);
      thruster.rotation.x = 0.18;
      accessory.add(thruster);
      const plume = new THREE.Mesh(
        new THREE.ConeGeometry(0.085, 0.5, 8),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(def.appearance.accentColor),
          transparent: true,
          opacity: 0.72,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      );
      plume.position.set(side * 0.3, -0.34, -0.2);
      plume.rotation.x = Math.PI;
      accessory.add(plume);
      const wingBlade = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.06, 0.03), accentMat);
      wingBlade.position.set(side * 0.42, 0.16, -0.14);
      wingBlade.rotation.z = side * 0.42;
      accessory.add(wingBlade);
    }
  } else if (def.appearance.accessory === 'thunder-drums' || def.appearance.accessory === 'runic-orbs') {
    for (let d = 0; d < 5; d++) {
      const a = (d / 5) * Math.PI * 1.4 - Math.PI * 0.2;
      const orb = new THREE.Mesh(new THREE.OctahedronGeometry(0.11, 0), accentMat);
      orb.position.set(Math.cos(a) * 0.52, Math.sin(a) * 0.52 + 0.15, -0.15);
      accessory.add(orb);
    }
  } else {
    // Flowing Anime Cape / Mantle
    const capeGeo = new THREE.BoxGeometry(0.58, 0.95, 0.04);
    const capeMesh = new THREE.Mesh(capeGeo, primaryMat);
    capeMesh.position.set(0, -0.35, -0.06);
    capeMesh.rotation.x = 0.18;
    accessory.add(capeMesh);
  }

  // --- ARMS & WEAPONS ---
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.34, 0.58, 0);
  torso.add(leftArm);

  const leftArmMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.075, 0.065, 0.56, 8),
    primaryMat
  );
  leftArmMesh.position.set(0, -0.24, 0);
  leftArm.add(leftArmMesh);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.34, 0.58, 0);
  torso.add(rightArm);

  const rightArmMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.075, 0.065, 0.56, 8),
    primaryMat
  );
  rightArmMesh.position.set(0, -0.24, 0);
  rightArm.add(rightArmMesh);

  // Weapon Group attached to Right Hand
  const weapon = new THREE.Group();
  weapon.position.set(0, -0.5, 0.12);
  rightArm.add(weapon);

  buildWeaponMesh(weapon, def.appearance.weapon, accentMat, secondaryMat);

  // Off-hand weapon for dual-wield archetypes
  let offhandWeapon: THREE.Group | undefined;
  if (def.appearance.weapon === 'dual-katanas' || def.appearance.weapon === 'daggers') {
    offhandWeapon = new THREE.Group();
    offhandWeapon.position.set(0, -0.5, 0.12);
    offhandWeapon.rotation.x = Math.PI * 0.38;
    leftArm.add(offhandWeapon);
    buildWeaponMesh(offhandWeapon, def.appearance.weapon, accentMat, secondaryMat);
  }

  // --- LEGS ---
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.14, 0, 0);
  hips.add(leftLeg);

  const leftLegMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.095, 0.075, 0.88, 8),
    secondaryMat
  );
  leftLegMesh.position.set(0, -0.44, 0);
  leftLeg.add(leftLegMesh);

  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.14, 0, 0);
  hips.add(rightLeg);

  const rightLegMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.095, 0.075, 0.88, 8),
    secondaryMat
  );
  rightLegMesh.position.set(0, -0.44, 0);
  rightLeg.add(rightLegMesh);

  // --- GROUND SELECTION / FACTION RING & AWAKENING AURA ---
  const auraRing = new THREE.Mesh(
    new THREE.RingGeometry(0.68, 0.86, 24),
    new THREE.MeshBasicMaterial({
      color: new THREE.Color(def.appearance.primaryColor),
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.75,
    })
  );
  auraRing.rotation.x = -Math.PI / 2;
  auraRing.position.set(0, 0.04, 0);
  root.add(auraRing);

  const awakeningCorona = new THREE.Mesh(
    new THREE.CylinderGeometry(0.65, 0.85, 2.2, 16, 1, true),
    new THREE.MeshBasicMaterial({
      color: new THREE.Color(def.appearance.auraColor),
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  awakeningCorona.position.set(0, 1.1, 0);
  awakeningCorona.visible = false;
  root.add(awakeningCorona);

  const guardDome = new THREE.Mesh(
    new THREE.SphereGeometry(1.15, 16, 12),
    new THREE.MeshBasicMaterial({
      color: new THREE.Color(def.appearance.accentColor),
      wireframe: true,
      transparent: true,
      opacity: 0.55,
    })
  );
  guardDome.position.set(0, 1.05, 0);
  guardDome.visible = false;
  root.add(guardDome);

  // --- v1.1.0 3D WEAPON SLASH RIBBONS ---
  const slashRibbonGroup = new THREE.Group();
  slashRibbonGroup.position.set(0, 1.05, 0);
  slashRibbonGroup.visible = false;
  root.add(slashRibbonGroup);

  const slashRibbonMeshes: THREE.Mesh[] = [];
  for (let i = 0; i < 3; i++) {
    const ribbonMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(i === 1 ? def.appearance.accentColor : def.appearance.primaryColor),
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const ribbon = new THREE.Mesh(
      new THREE.RingGeometry(0.55 + i * 0.22, 0.95 + i * 0.3, 24, 1, 0, Math.PI * 0.95),
      ribbonMat
    );
    ribbon.rotation.x = -Math.PI / 2 + 0.35;
    ribbon.userData.phase = i * 0.35;
    slashRibbonGroup.add(ribbon);
    slashRibbonMeshes.push(ribbon);
  }

  // --- v1.1.0 DASH / AWAKENING AFTERIMAGE GHOSTS ---
  const afterimageGroup = new THREE.Group();
  root.add(afterimageGroup);
  const ghostMaterial = new THREE.MeshBasicMaterial({
    color: new THREE.Color(def.appearance.auraColor),
    transparent: true,
    opacity: 0,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const ghostMeshes: THREE.Mesh[] = [];
  for (let i = 0; i < 4; i++) {
    const ghost = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 1.15, 4, 8), ghostMaterial);
    ghost.position.set(0, 0.95, 0);
    ghost.visible = false;
    afterimageGroup.add(ghost);
    ghostMeshes.push(ghost);
  }

  return {
    characterId: def.id,
    root,
    hips,
    torso,
    head,
    hair,
    accessory,
    leftArm,
    rightArm,
    weapon,
    leftLeg,
    rightLeg,
    auraRing,
    awakeningCorona,
    guardDome,
    eyes: { left: leftEye, right: rightEye, leftBrow, rightBrow, material: eyeMat },
    slashRibbons: { group: slashRibbonGroup, meshes: slashRibbonMeshes },
    afterimages: { group: afterimageGroup, ghosts: ghostMeshes, material: ghostMaterial },
    offhandWeapon,
    previousPosition: new THREE.Vector3(),
    facingAngle: 0,
  };
}

function buildWeaponMesh(
  weaponGroup: THREE.Group,
  weaponType: CharacterDefinition['appearance']['weapon'],
  accentMat: THREE.Material,
  darkMat: THREE.Material
): void {
  if (weaponType === 'odachi') {
    const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.35, 8), darkMat);
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.03, 1.45, 0.08), accentMat);
    blade.position.set(0, 0.85, 0);
    weaponGroup.add(hilt, blade);
    weaponGroup.rotation.x = Math.PI * 0.38;
  } else if (weaponType === 'scythe') {
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.85, 8), darkMat);
    shaft.position.set(0, 0.45, 0);
    const crescent = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.95, 6), accentMat);
    crescent.position.set(0, 1.35, 0.38);
    crescent.rotation.x = Math.PI * 0.55;
    weaponGroup.add(shaft, crescent);
    weaponGroup.rotation.x = Math.PI * 0.25;
  } else if (weaponType === 'halberd') {
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 1.75, 8), darkMat);
    shaft.position.set(0, 0.45, 0);
    const spearTip = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.55, 6), accentMat);
    spearTip.position.set(0, 1.45, 0);
    weaponGroup.add(shaft, spearTip);
    weaponGroup.rotation.x = Math.PI * 0.3;
  } else if (weaponType === 'greatbow') {
    const bowArc = new THREE.Mesh(
      new THREE.TorusGeometry(0.55, 0.035, 8, 18, Math.PI),
      accentMat
    );
    bowArc.rotation.z = -Math.PI / 2;
    weaponGroup.add(bowArc);
  } else if (weaponType === 'grimoire') {
    const book = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.42, 0.08), accentMat);
    book.position.set(0.15, 0.35, 0.35);
    weaponGroup.add(book);
  } else if (weaponType === 'dual-katanas') {
    const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.3, 8), darkMat);
    const guard = new THREE.Mesh(new THREE.TorusGeometry(0.085, 0.018, 6, 12), darkMat);
    guard.rotation.x = Math.PI / 2;
    guard.position.y = 0.14;
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.035, 1.15, 0.055), accentMat);
    blade.position.set(0, 0.72, 0);
    weaponGroup.add(hilt, guard, blade);
    weaponGroup.rotation.x = Math.PI * 0.36;
  } else if (weaponType === 'lance-cannon') {
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.075, 1.5, 10), darkMat);
    shaft.position.set(0, 0.5, 0);
    const lanceTip = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.62, 8), accentMat);
    lanceTip.position.set(0, 1.52, 0);
    for (let v = 0; v < 3; v++) {
      const vent = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.02, 6, 14), accentMat);
      vent.rotation.x = Math.PI / 2;
      vent.position.set(0, 0.55 + v * 0.32, 0);
      weaponGroup.add(vent);
    }
    const muzzle = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.09, 0.22, 10), accentMat);
    muzzle.position.set(0, 1.08, 0.1);
    muzzle.rotation.x = Math.PI / 2.4;
    weaponGroup.add(shaft, lanceTip, muzzle);
    weaponGroup.rotation.x = Math.PI * 0.2;
  } else if (weaponType === 'chakram') {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.04, 8, 20), accentMat);
    weaponGroup.add(ring);
  } else {
    // Gauntlets / Tonfa / Daggers / Greaves
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.65, 0.14), accentMat);
    blade.position.set(0, 0.2, 0.1);
    weaponGroup.add(blade);
    weaponGroup.rotation.x = Math.PI * 0.4;
  }
}

/**
 * Procedural Skeletal Animation Driver for all 13 FighterAnimationStates.
 */
/**
 * v1.1.0 — Dynamic anime facial expression states.
 * Eyes narrow into a killing glare during ultimates, blow wide on awakening,
 * and the brows tilt per animation state for readable emotion at arena scale.
 */
export function updateAnimeExpression(
  rig: ArticulatedCharacterRig,
  animState: FighterAnimationState,
  isAwakened: boolean,
  elapsedSec: number
): void {
  const { eyes } = rig;
  let eyeScaleX = 1;
  let eyeScaleY = 1;
  let browTilt = 0.16;
  let browLift = 0;
  let glow = 1;

  switch (animState) {
    case 'ultimate':
      eyeScaleX = 1.28;
      eyeScaleY = 0.55; // Fierce narrowed glare
      browTilt = 0.62;
      browLift = -0.012;
      glow = 1.85 + Math.sin(elapsedSec * 22) * 0.2;
      break;
    case 'awakening':
      eyeScaleX = 1.42;
      eyeScaleY = 1.5; // Wide open shock of ascension
      browTilt = 0.02;
      browLift = 0.028;
      glow = 2.3;
      break;
    case 'basicCombo':
    case 'heavyAttack':
    case 'signatureSkill':
      eyeScaleX = 1.12;
      eyeScaleY = 0.72;
      browTilt = 0.5;
      glow = 1.35;
      break;
    case 'hit':
      eyeScaleX = 0.82;
      eyeScaleY = 0.7;
      browTilt = -0.18;
      browLift = 0.014;
      glow = 0.85;
      break;
    case 'defend':
    case 'counter':
      eyeScaleX = 1.05;
      eyeScaleY = 0.66;
      browTilt = 0.4;
      glow = 1.25;
      break;
    case 'move':
    case 'movementSkill':
      eyeScaleX = 1.08;
      eyeScaleY = 0.86;
      browTilt = 0.3;
      glow = 1.15;
      break;
    case 'victory':
      eyeScaleX = 1.1;
      eyeScaleY = 1.05;
      browTilt = 0.08;
      browLift = 0.01;
      glow = 1.5;
      break;
    case 'eliminated':
      eyeScaleX = 1;
      eyeScaleY = 0.08; // Eyes closed in astral dissolution
      browTilt = -0.05;
      glow = 0.3;
      break;
    default:
      break;
  }

  if (isAwakened && animState !== 'eliminated') glow *= 1.35;

  eyes.left.scale.set(eyeScaleX, eyeScaleY, 1);
  eyes.right.scale.set(eyeScaleX, eyeScaleY, 1);
  eyes.leftBrow.rotation.z = browTilt;
  eyes.rightBrow.rotation.z = -browTilt;
  eyes.leftBrow.position.y = 0.088 + browLift;
  eyes.rightBrow.position.y = 0.088 + browLift;
  const baseColor = (eyes.material.userData.baseEyeColor as THREE.Color | undefined) ??
    new THREE.Color('#f8fafc');
  eyes.material.color.copy(baseColor).multiplyScalar(Math.min(1.9, glow));
}

/**
 * v1.1.0 — 3D weapon slash ribbons.
 * Draws expanding additive crescent trails locked to the weapon swing.
 */
export function updateSlashRibbons(
  rig: ArticulatedCharacterRig,
  animState: FighterAnimationState,
  elapsedSec: number
): void {
  const group = rig.slashRibbons.group;
  const active =
    animState === 'basicCombo' ||
    animState === 'heavyAttack' ||
    animState === 'signatureSkill' ||
    animState === 'ultimate' ||
    animState === 'counter';

  if (!active) {
    group.visible = false;
    return;
  }

  group.visible = true;
  const intensity = animState === 'ultimate' ? 1 : animState === 'signatureSkill' ? 0.85 : 0.6;
  const travel = animState === 'ultimate' ? 2.35 : animState === 'signatureSkill' ? 1.75 : 1.25;

  rig.slashRibbons.meshes.forEach((ribbon, idx) => {
    const mat = ribbon.material as THREE.MeshBasicMaterial;
    const localPhase = (elapsedSec * (animState === 'ultimate' ? 11 : 8.5) + ribbon.userData.phase) % 1;
    const fade = Math.sin(localPhase * Math.PI);
    mat.opacity = fade * intensity * (1 - idx * 0.2);
    const scale = 0.62 + localPhase * travel;
    ribbon.scale.set(scale, scale, scale);
    ribbon.rotation.z = -2.4 + localPhase * 5.2;
    ribbon.position.y = 0.05 + idx * 0.1;
  });
}

/**
 * v1.1.0 — Dash & Awakening afterimage ghosts.
 * Trails translucent silhouettes behind high-velocity movement and ascension bursts.
 */
export function updateAfterimages(
  rig: ArticulatedCharacterRig,
  animState: FighterAnimationState,
  isAwakened: boolean,
  elapsedSec: number,
  deltaPosXZ: number
): void {
  const { ghosts, material } = rig.afterimages;
  const dashing = animState === 'movementSkill' || (animState === 'move' && deltaPosXZ > 0.24);
  const ascending = animState === 'awakening';
  const ulting = animState === 'ultimate';

  if (!dashing && !ascending && !ulting) {
    material.opacity = Math.max(0, material.opacity - 0.08);
    if (material.opacity <= 0.001) ghosts.forEach((g) => (g.visible = false));
    return;
  }

  const baseOpacity = ascending ? 0.82 : ulting ? 0.4 : 0.55;
  material.opacity = baseOpacity * (isAwakened ? 1.2 : 1);
  if (material.opacity > 1) material.opacity = 1;

  ghosts.forEach((ghost, idx) => {
    ghost.visible = true;
    const stretched = ascending ? 1 + idx * 0.35 : 1 + idx * 0.05;
    ghost.scale.set(1 - idx * 0.12, stretched, 1 - idx * 0.12);
    const offset = (idx + 1) * (dashing ? 0.85 : 0.22);
    ghost.position.set(0, 0.95 + (ascending ? idx * 0.32 : 0), -offset);
  });

  rig.afterimages.group.rotation.y = Math.sin(elapsedSec * 3) * 0.05;
}

export function updateCharacterAnimation(
  rig: ArticulatedCharacterRig,
  animState: FighterAnimationState,
  elapsedSec: number,
  isAwakened: boolean,
  isGuarding: boolean
): void {
  const phase = elapsedSec * 7.5 + rig.characterId.charCodeAt(5);

  rig.awakeningCorona.visible = isAwakened && animState !== 'eliminated';
  if (rig.awakeningCorona.visible) {
    rig.awakeningCorona.rotation.y = elapsedSec * 3.2;
    const pulse = 1 + Math.sin(elapsedSec * 9) * 0.08;
    rig.awakeningCorona.scale.set(pulse, 1, pulse);
  }

  rig.guardDome.visible = isGuarding && animState !== 'eliminated';
  if (rig.guardDome.visible) {
    rig.guardDome.rotation.y = -elapsedSec * 2.5;
  }

  if (animState === 'eliminated') {
    // Non-graphic fallen kneel/dissolution pose
    rig.hips.position.y = 0.32;
    rig.torso.rotation.x = 0.55;
    rig.leftArm.rotation.x = 0.4;
    rig.rightArm.rotation.x = 0.4;
    rig.leftLeg.rotation.x = -1.2;
    rig.rightLeg.rotation.x = -1.1;
    rig.auraRing.visible = false;
    return;
  }

  rig.auraRing.visible = true;
  rig.accessory.rotation.x = 0.15 + Math.sin(phase * 0.8) * 0.12;

  switch (animState) {
    case 'move': {
      rig.hips.position.y = 0.93 + Math.abs(Math.sin(phase * 1.4)) * 0.08;
      rig.torso.rotation.x = 0.22; // Anime sprint lean
      rig.torso.rotation.y = Math.sin(phase * 1.4) * 0.12;
      rig.leftLeg.rotation.x = Math.sin(phase * 1.4) * 0.75;
      rig.rightLeg.rotation.x = -Math.sin(phase * 1.4) * 0.75;
      rig.leftArm.rotation.x = -Math.sin(phase * 1.4) * 0.65;
      rig.rightArm.rotation.x = Math.sin(phase * 1.4) * 0.55 - 0.3;
      break;
    }
    case 'basicCombo': {
      rig.hips.position.y = 0.9;
      rig.torso.rotation.x = 0.18;
      rig.torso.rotation.y = Math.sin(elapsedSec * 28) * 0.65;
      rig.rightArm.rotation.x = -1.4 + Math.cos(elapsedSec * 28) * 0.95;
      rig.rightArm.rotation.z = -0.35;
      rig.leftArm.rotation.x = -0.5;
      break;
    }
    case 'heavyAttack':
    case 'signatureSkill': {
      rig.hips.position.y = 1.05;
      rig.torso.rotation.x = -0.15;
      rig.torso.rotation.y = Math.sin(elapsedSec * 18) * 0.85;
      rig.rightArm.rotation.x = -2.1 + Math.sin(elapsedSec * 20) * 1.2;
      rig.leftArm.rotation.x = -1.2;
      break;
    }
    case 'ultimate': {
      // Dramatic aerial ascension pose during Ultimate
      rig.hips.position.y = 2.15 + Math.sin(elapsedSec * 12) * 0.25;
      rig.torso.rotation.x = -0.25;
      rig.torso.rotation.y = elapsedSec * 6.0;
      rig.leftArm.rotation.z = -0.85;
      rig.rightArm.rotation.z = 0.85;
      rig.rightArm.rotation.x = -1.8;
      break;
    }
    case 'awakening': {
      rig.hips.position.y = 1.45;
      rig.torso.rotation.x = -0.35;
      rig.leftArm.rotation.z = -1.1;
      rig.rightArm.rotation.z = 1.1;
      break;
    }
    case 'movementSkill': {
      rig.hips.position.y = 1.15;
      rig.torso.rotation.x = 0.48;
      rig.leftLeg.rotation.x = -0.6;
      rig.rightLeg.rotation.x = 0.5;
      break;
    }
    case 'defend':
    case 'counter': {
      rig.hips.position.y = 0.86;
      rig.torso.rotation.x = 0.1;
      rig.rightArm.rotation.x = -1.35;
      rig.rightArm.rotation.z = 0.55;
      rig.leftArm.rotation.x = -1.2;
      break;
    }
    case 'hit': {
      rig.hips.position.y = 0.92;
      rig.torso.rotation.x = -0.32;
      rig.leftArm.rotation.x = 0.35;
      rig.rightArm.rotation.x = 0.35;
      break;
    }
    case 'victory': {
      rig.hips.position.y = 0.98 + Math.sin(phase * 0.6) * 0.04;
      rig.torso.rotation.x = -0.12;
      rig.torso.rotation.y = Math.sin(phase * 0.4) * 0.2;
      rig.rightArm.rotation.x = -2.45; // Raised weapon triumphantly
      rig.leftArm.rotation.z = -0.35;
      break;
    }
    case 'idle':
    default: {
      rig.hips.position.y = 0.95 + Math.sin(phase * 0.5) * 0.03;
      rig.torso.rotation.x = 0.04;
      rig.torso.rotation.y = Math.sin(phase * 0.35) * 0.08;
      rig.leftArm.rotation.x = Math.sin(phase * 0.5) * 0.12;
      rig.rightArm.rotation.x = -0.25 + Math.cos(phase * 0.5) * 0.12;
      rig.leftLeg.rotation.x = 0;
      rig.rightLeg.rotation.x = 0;
      break;
    }
  }
}
