# Changelog

All notable changes to **ANIME ARENA: CATACLYSM — 3D RANDOM BATTLE** are documented in this file following Semantic Versioning.

## [1.4.0] — 2026-11-14

### Fixed — the camera let scenery block the fight

Found by watching nine full fights rather than reading code. In one sampled
frame eight fighters were alive, the combat feed was reporting elemental
reactions, and the entire viewport was filled by a single destructible pillar.

`pickClearOrbit()` scored ten candidate angles and *penalised* blocked sight
lines — but never rejected them. When every candidate was blocked it returned
the least-bad one anyway. A penalty is not a rejection.

- Added `segmentBlocked()`, a hard boolean test for any live destructible
  intersecting the lens→focus line.
- If the winning shot is still occluded, the camera now lifts in 1.5 m steps
  (up to 13.5 m, pulling back slightly as it rises) until the line clears.
- If nothing clears, it falls back to a bird's-eye that nothing in-arena can
  occlude.

### Added — projected fighter nameplates

Eight fighters in a 38 m arena meant the roster was only identifiable from the
10px sidebar. Every living fighter now carries a DOM nameplate projected above
their head, with a health bar that shifts emerald → amber → rose.

- The fighter currently being narrated in the voice banner is highlighted amber,
  so the feed and the arena finally agree about who is doing what.
- Plates are DOM, not canvas — text stays crisp at any orbit distance.
- Fighters behind the lens or off-screen are filtered out automatically
  (visible count ranges 3–8 depending on framing, which is correct behaviour).
- New renderer API: `projectToScreen(x, y, z, w, h)`.

### Verified

- 22/22 Vitest tests green.
- Nine consecutive frames sampled in a live 8-fighter battle; nameplates present
  and tracking in all of them, zero page errors.
- Close-quarters melee frames now read as fights rather than silhouettes.

## [1.3.0] — 2026-11-14

### Fixed — twelve fighters rendered as five

The roster has always authored twelve unique hair styles, twelve weapons and
twelve accessories. The renderer silently ignored most of them and fell back to
three hardcoded defaults, so distinct characters became the same person in a
different colour.

| Property | Authored | Was rendered | Now |
| --- | --- | --- | --- |
| Hair styles | 12 | 6 | **12** |
| Accessories | 12 | 7 | **12** |
| Weapons | 12 | 8 | **12** |

- **5 fighters wore the identical plain box cape** (Kaelen, Zero-Nine, Malakor,
  Ryuji, Nyx) → now `cape`, `tactical-cloak`, `abyss-mantle`, `dragon-sash`,
  `rose-chains`, each a distinct silhouette.
- **4 carried the identical blade blob** (Raiden, Ryuji, Nyx, Orion) → now
  `tonfa`, `greaves`, `gauntlets`, `daggers`.
- **6 shared one spike-ball hairstyle** → now `spiky`, `cyber-swept`,
  `braided-crown`, `headband-wild`, `gothic-bob`, `alchemist-crest`.
- Unknown values now fall back to a sensible variant instead of a bare box, so a
  future data addition degrades gracefully rather than silently flattening.

### Added

- **The Twelve** — a rotating roster gallery screen, reachable from the main
  menu. All twelve fighters in a ring, labelled, so the authored designs can be
  compared directly (`?gallery=1` for the dev view, `?gallery=1&focus=N` for a
  single close-up).
- The braided crown sits proud of the hair cap and adds a braided topknot —
  the first version was swallowed inside the skull mesh and read as a bald head.

### Verified

- 22/22 Vitest tests still green.
- All twelve screenshotted individually and inspected; contact sheet at
  `shots/ROSTER-TWELVE.png`.
- Full 8-fighter battle re-rendered with the new meshes — zero page errors.

## [1.2.0] — 2026-11-14

### Added

#### 1. Anime Bloom Post-Processing
- New `EffectComposer` pipeline (`RenderPass` -> `UnrealBloomPass` -> `OutputPass`), built on passes already bundled with three.js r170 — **no new dependency**.
- Every VFX in the game (slash arcs, clash bursts, ultimate inlays, awakening coronas, eye glow) was additive but rendered flat; it now blooms as intended.
- Bloom is **dynamic**: strength surges during Ultimates (+0.22/fighter), Awakenings (+0.16), active Clash Locks (+0.18) and the 0.2x bullet-time final blow (+0.30), with a 0.22 s time-constant ease so it breathes instead of popping.
- Quality-gated: Ultra 0.62 / High 0.48 / Medium 0.30 / Low disabled entirely (falls back to the plain forward renderer).

#### 2. Full-Silhouette Anime Ink Outlines
- Outlines were previously limited to the head and chest. `inkOutlineSilhouette()` now inks every toon-shaded surface: torso, coat, hands, weapons, hair (all styles), accessories, and legs.
- Outline weight is chosen per-part from the mesh's smallest bounding dimension, so thin blades and hair spikes get a proportionally fatter line than the torso.
- All outlines share a single `MeshBasicMaterial` instead of one material per mesh (~96 materials per battle saved at High/Ultra).
- Additive auras, eyes and glow meshes are explicitly excluded so they don't turn into black blobs under bloom.

#### 3. The Cataclysm Ascent — Tournament Mode
- New three-round elimination tournament (`src/engine/ascentTournament.ts`), reachable from the main menu.
- **Respects the 8-fighter rule**: a 1v1 bracket would violate it, so each round is instead a full 8-way Cataclysm battle.
  - Round I — The Opening Cataclysm: 8 seeded entrants
  - Round II — The Survivors Clash: top 4 advance + 4 newcomers
  - Round III — The Grand Final: top 4 advance + challengers, one Ascendant crowned
- Deterministic end to end: the root seed derives every round seed, and each round's arena is chosen from that round seed, so a whole tournament replays identically.
- Standings come from the engine's own `placement` field, so the bracket can never disagree with the battle just fought.
- **`risen` challengers**: a 12-fighter roster cannot field three unique rounds of eight (8 + 4 + 4 exhausts the bench). Rather than weaken the 8-fighter rule, the Grand Final calls back the strongest eliminated fighters, ranked by best finish, as `risen` entrants.
- Full bracket UI (`AscentView`) with round rail, entrant cards (SEEDED / ADVANCED / NEWCOMER / RISEN badges), completed-round standings and champion banner.
- The victory modal gains a **Return to the Ascent** action during tournament play; battles are named `ASCENT n/3 — <arena>`.

### Fixed
- **Critical-event camera aimed at the wrong point.** Ultimate / elimination / betrayal shots used the ability's `impactCenter`, which can sit metres from the fighters, pushing the bodies to the top edge of frame. It now aims at the midpoint of the actual actor and victim, at a slightly wider 10.5 m orbit.
- **Draw-call telemetry broke under post-processing.** Post passes reset `renderer.info`, so the HUD reported the final fullscreen quad (`1 draws, 1 tris`). Stats are now sampled inside the `RenderPass` and report the real scene (e.g. `228 draws, 19,088 tris`).

### Testing
- **22/22 Vitest tests** (11 existing + 11 new tournament tests): 8 unique entrants every round, determinism across identical seeds, top-4 advancement, no re-admission of eliminated fighters, full 12-fighter roster consumption, champion crowning, out-of-order round rejection, insufficient-roster rejection and bench accounting.

## [1.1.1] — 2026-11-14

Camera and framing pass driven by direct visual inspection of the live build (Playwright + real WebGL screenshots), not by bundle-hash checks.

### Fixed
- **Automatic director framed empty floor.** The camera aimed at the centroid of all eight fighters, which sits at arena centre at spawn. Replaced with a local **action-hotspot director**: every living fighter is treated as the anchor of a body cluster (11 m), clusters are scored on proximity, combat animation state (ultimate / awakening / signature / heavy / counter / combo), low HP, active target locks and brawl size, and the focus point is the weighted centroid of the winning cluster — so the focus can never land on an empty patch of floor.
- **Camera smoothing was frame-rate dependent.** Camera position and look-at used a fixed per-frame lerp, so it converged in ~0.25 s at 60 fps but ~10 s at 3 fps, leaving the lens stuck on the previous shot while the fight moved on. Smoothing is now exponential in real elapsed time (`cameraAlpha`), giving identical framing response at any frame rate.
- **Camera clipped through scenery.** Destructibles (crystals, pillars, plinths) could sit between lens and subject. The orbit candidate search now runs a **line-of-sight test** against every standing structure and keeps a 5 m standoff from every fighter body, plus a mild preference for higher angles that graze over props.
- **Composition drifted into the frame edge.** A multiplicative 0.88 pull toward the arena centre pushed the action into the corner; the focus point is now only clamped inward when the fight is genuinely pinned against the arena lip.
- **Close shots cropped the fighters.** Orbit distance is now derived from the framed cluster's actual spread (≈9 m for a tight duel, up to ≈17.5 m for a five-way brawl) with a slow breathing drift, instead of a fixed 7.6–11.8 m.
- **Critical beats were never actually captured.** Ultimate / elimination / betrayal / awakening shots have a 2 s window but the camera had to pan in from wherever it was. It now cuts when the subject is more than 14 m away and converges ~4× faster while the window is open.

### Changed
- Destructible structures gained stone plinths and additive wisps, and the central altar was shrunk so it no longer dominates the frame.
- Procedural per-arena stone floor texture with hex glows and rim veins; floor brightness retuned (no more flat gold wash).
- Right-hand battle HUD compacted (`w-72`, smaller radar, tighter coalitions card) so it stops overlapping the top bar.

### Verified
- 11/11 Vitest tests pass, `npm run build` clean (940.66 KB JS / 250.53 KB gzip, 35.61 KB CSS).
- Visual QA: 30+ screenshots at 1280×800 and 1440×860 across spawn, duel, brawl, blade clash, beam clash, ultimate cut-in, final blow and champion modal, with zero console errors.

## [1.1.0] — 2026-11-14

### Added

#### 1. Roster Expansion — 12 Validated Original Fighters
- Added **Zephyrion Vale** — *Sovereign of the Frost-Moon Blade* (`S+` Tier, Crystal dual-katana **Duelist**): Twin Frost-Fang Cross, Glacier Severance, Hoarfrost Mirage Step, Mirror-Ice Riposte, Lotus of Absolute Zero, and the **Zero-Kelvin Dimension Slash** ultimate.
- Added **Solaria Vex** — *Valkyrie of the Plasma Singularity* (`S` Tier, Photon lance-cannon **Tactician**): Plasma Lance Barrage, Hyper-Thruster Impale, Afterburner Vector Boost, Aegis Phase-Matrix, Valkyrie Ion Cannon, and the **Heaven-Fall Orbital Convergence** ultimate.
- Added new appearance archetypes: `dual-katanas`, `lance-cannon` weapons; `silver-ponytail`, `valkyrie-crest` hair; `frost-lotus`, `plasma-thrusters` accessories — all fully modelled in the procedural 3D rig, Character Studio dropdowns, and the glTF asset generator (18 assets, 12 eligible rigs).

#### 2. Anime Clash Lock (Blade / Beam Clash) System
- New `ClashLockRuntime` simulation entity: two fighters can lock weapons (`blade-clash`) or collide opposing energy signatures (`beam-clash`) into a timed struggle.
- Clash requires both fighters to be mid-offensive at close range; Duelist/Juggernaut archetypes and beam-capable kits receive a clash frequency bonus.
- Momentum is resolved deterministically tick-by-tick from attack stat, Awakening state, slow/stun debuffs, and seeded jitter.
- Losers take a dominance-scaled breakthrough hit, are stunned and shoved; winners gain 34 energy, an attack buff, and a `clashesWon` stat credit.
- Locked fighters are physically pinned (zero velocity, forced facing) and emit `clash-burst` spark VFX throughout the struggle.
- Full `CLASH_LOCK` event stream, replay-safe snapshots, tactical radar ping, HUD badge, and breakthrough outcome card.

#### 3. Stage-Specific Mid-Battle Arena Cataclysm Events
- New `src/data/cataclysmEvents.ts` with 8 signature phenomena: **Skyfall Meteor, Runic Consecration, Plasma Meltdown, EMP Overload, Gravity Collapse, Star-Core Implosion, Aether Flood, Shatter Rain**.
- Each arena owns a themed cataclysm pool, and each event declares which arena stages it can fire in, its telegraph length, danger radius, and damage.
- Cataclysms target the most crowded region of the arena (seeded sampling), telegraph with a warning banner + countdown + descending meteor pillar, then detonate for radial damage.
- Event-specific secondary effects: energy drain (EMP), attack blessing (Runic), gravity pull (Collapse), burn (Plasma), shred (Star-Core / Shatter), slow (Aether Flood), stun (Skyfall).
- Events fire on a stage-scaled cadence (Stage I: 30s → Stage III: 17s) and are fully recorded in the replay event stream.

#### 4. 3D Cinematic Upgrade — Ribbons, Afterimages, Expressions & Bullet-Time
- **3D weapon slash ribbons**: three additive crescent meshes that expand, spin and fade per swing, scaled up for Signature Skills and Ultimates.
- **Dash & Awakening afterimages**: up to four translucent capsule ghosts trail high-velocity movement, ascension bursts, and ultimate poses.
- **Dynamic anime facial expressions**: eyes and brow blades narrow into a killing glare during Ultimates, blow wide on Awakening, and close on elimination; eye emissive glows react to `isAwakened`.
- **Off-hand weapon rig** for dual-katana and dagger fighters, plus dedicated `dual-katanas` and `lance-cannon` weapon meshes.
- **Clash Lock scene visuals**: crossed 3D blades/colliding beam shards, rotating spark corona and a ground shock ring at every struggle.
- **Arena Cataclysm theatre**: danger-ring telegraph, pulsing fill, descending meteor cone and support column.
- **Slow-motion final blow (0.2x bullet-time)**: the director detects the killing blow of the final elimination and locks into a tight orbiting finisher shot with letterbox bars and a speed-line field while the simulation clock runs at 0.2x.

#### 5. UI Upgrade — Tactical Radar, Cut-In Banner & GLB Inspector
- **`TacticalRadar` minimap**: full top-down arena with boundary/tactical rings, rotating sweep, fighter blips with facing wedges, awakened halo, Ultimate pulses, alliance tethers, sanctuary/hazard zones, clash markers, and cataclysm danger circles. Clicking a blip switches to the follow camera.
- **`UltimateCutIn` full-screen anime banner**: diagonal speed lines, skewed colour slash band, character silhouette plate, oversized slanted ability typography, and the fighter's signature voice line — triggered for Ultimates, Awakenings, and Clash Locks in both live and replay playback.
- **Cataclysm warning banner** with live impact countdown, plus a **clash breakthrough outcome card**.
- **Character Studio `.glb` / `.gltf` drag-and-drop inspection**: new `inspectGltfFile` / `inspectGltfAssetFile` / `parseGlbContainer` pipeline functions parse binary GLB chunk-by-chunk (JSON + BIN), report glTF version, generator, node/mesh/material/texture/animation counts, joint coverage against the 22-bone contract, 13-clip animation coverage, embedded buffer size, diagnostics and hard errors, and sync the draft's provenance record.

#### 6. Simulation Pacing & Quality
- **Calibrated Spectator Pacing**: damage scaling is now anchored to a measured baseline (Fast ≈ 90s, Standard ≈ 135s, Epic ≈ 210s) with a late-game "finishing pressure" ramp that prevents stalled matches, so the advertised broadcast windows are actually met.
- Extended combat state: `clashesWon` stat, `clashLockEnabled` and `cataclysmEventsEnabled` settings toggles exposed in Advanced Arena Settings.
- Replay payload schema bumped to `1.1.0` with backward-compatible `1.0.0` import support.
- Test suite expanded to **11 tests across 2 files**, including clash resolution, cataclysm telegraph/impact, binary GLB round-trip parsing, 12-character determinism, and a mounted `BattleSpectatorView` integration smoke test.

### Fixed
- Fixed fighters retaining stale velocity inside the first frame of a Clash Lock.
- Fixed the auto-director camera orbiting a long-dead finisher after the bullet-time window closed.

## [1.0.0] — 2026-11-14

### Added
- **Milestone 0 (Project Bootstrap)**:
  - Created isolated Vercel project `anime-arena-cataclysm` (`prj_SqYbnVcKaSezSDYSvxug39MrMSM1`).
  - Established TypeScript + Vite + React 18 + Three.js modular architecture and ADR-001.
  - Created automated glTF 2.0 asset generator and validator (`scripts/generate-assets.mjs`, `scripts/validate-assets.mjs`).
- **Milestone 1 & 2 (Complete Playable Vertical Slice & Content Expansion)**:
  - Implemented 10 original, 9-point validated 3D anime characters (`Kaelen Vance`, `Vespera Noctis`, `Raiden Kurogami`, `Seraphina Solis`, `Zero-Nine (Akira)`, `Malakor the Unbound`, `Lyra Celestis`, `Ryuji Kazama`, `Nyx Valeria`, `Orion Solaris`).
  - Implemented 3 polished Dynamic Living Arenas (`Aetherium Sanctum`, `Neo-Kyoto Crater`, `Obsidian Rift`) with 3 dynamic stages, weather particles, central shrine blessings, and 10 destructible objects per arena.
  - Built authoritative fixed-timestep `BattleSimulation` engine with Hybrid Power Balance, elemental cross-reactions, counters/parries, Awakenings, and Signature Ultimates.
  - Built Local Hybrid AI combining Utility AI intent scoring, Behavior Trees, fighter memory, and an `8x8` dynamic relationship matrix supporting alliances and betrayals.
- **Milestone 3 (Spectator Experience)**:
  - Implemented Intelligent Automatic Cinematic Director Camera, Wide Spectator Camera, and Character Follow Camera.
  - Implemented toggleable **Cinematic HUD** and **Tactical HUD**, playback speed controls (`0.5x`, `1x`, `2x`, `4x`), live combat log, and full post-battle 8-character analytics modal.
- **Milestone 4 (Replay & Persistence)**:
  - Built `HybridReplayController` with timeline scrubbing, snapshot interpolation, and deterministic seed re-simulation verification.
  - Built persistent IndexedDB `BattleArchive` with search, sort, rename, delete, and versioned JSON export/import.
  - Built `ArenaChronicle` computing authentic historical win rates, K/D ratios, Hall of Fame, rivalries, and 12 unlockable achievements.
- **Milestone 5 & 6 (Character Studio, Audio, Settings & Production QA)**:
  - Built `Original Character Studio` with live 3D rig turntable, 13 animation state previews, appearance/ability/AI editor, and Blender-compatible glTF 2.0 import/export.
  - Built 4-bus spatial WebAudio synthesizer (`music`, `sfx`, `voice`, `ambient`) and `Advanced Arena Settings` with presets and Ultra/High/Medium/Low graphics quality controls.
  - Added automated Vitest QA suite (`tests/simulationAndSystems.test.ts`) verifying all core systems.
