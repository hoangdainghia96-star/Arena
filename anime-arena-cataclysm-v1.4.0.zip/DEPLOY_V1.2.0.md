# DEPLOY RECORD — v1.2.0 (LIVE)

**Production:** https://anime-arena-cataclysm.vercel.app
**Deployment:** `dpl_HXEvj5HkiyMEad7oyYgSGp1PmzQJ` — READY / PROMOTED
**Commit:** `24c6d2682dcee86148a31f87450ed03121b91afd` (main, "Add files via upload")
**Built in:** 15.5 s · Node 26.x · region iad1

## Verified live (not assumed)

| Check | Result |
| --- | --- |
| `index.html` references | `index-DMcyagia.js` + `index-3WiU8TxO.css` — exact match to local build |
| Bundle byte-identity | live sha256 `83a49e8c…8e8e22` == local build sha256 |
| `UnrealBloomPass` in bundle | present |
| `The Cataclysm Ascent` / `The Grand Final` in bundle | present |
| `ASCENT_ALREADY_COMPLETE` / `ASCENT_ROUND_MISMATCH` | present |
| Browser render (Playwright + WebGL) | tournament card visible, bracket renders, **0 page errors** |

Screenshot: `shots/PROD-v1.2.0-live.png`

## Rollback

| Version | Deployment |
| --- | --- |
| v1.1.0 | `dpl_8KSCwhNrsbmo7NKNdYkg7s3MHGgk` |
| v1.0.0 | `dpl_7Tp1y58Bp28V5tmWR72T3Y7rdQ4r` |

Roll back with `vercel rollback dpl_8KSCwhNrsbmo7NKNdYkg7s3MHGgk` or Promote in the dashboard.

## Why the git push did NOT auto-deploy

The project has **`gitProviderOptions.createDeployments = "disabled"`**. Vercel is linked to the
GitHub repo and receives pushes, but is configured not to create deployments from them. Earlier
releases only deployed because a deployment was triggered explicitly through the API.

**Fix (dashboard, one time):** Project → Settings → Git → "Git Provider Options" →
enable **Create deployments**, and disable "Repository Dispatch Events" only if it causes duplicate
builds. Until then, every release needs an explicit `create_deployment` call with
`git_source {type: github, ref: main, repoId: 1457433701}`.

## Install command

`unzip -o anime-arena-cataclysm-v1.2.0.zip && npm install`

This is hard-pinned to the v1.2.0 filename. **If you delete that zip from the repo, every future
build breaks until this string is updated.** Consider removing the install-command override entirely
once the source is committed directly to the repo — `vercel.json` already sets framework/build/output.
