# Release Record — v1.1.0 (LIVE)

**Promoted:** 2026-11-14
**Status:** ✅ Production, `READY` / `PROMOTED`, aliased and serving v1.1.0

---

## Live URLs

| Alias | URL |
|---|---|
| **Primary** | https://anime-arena-cataclysm.vercel.app |
| Project | https://anime-arena-cataclysm-hoangdainghia96-star.vercel.app |
| Branch | https://anime-arena-cataclysm-git-main-hoangdainghia96-star.vercel.app |
| Deployment | https://anime-arena-cataclysm-enbhyl4m9-hoangdainghia96-star.vercel.app |

## Deployment

```
Deployment ID   dpl_8KSCwhNrsbmo7NKNdYkg7s3MHGgk
State           READY   (readySubstate: PROMOTED)
Build time      15,071 ms
Target          production
Git commit      7bca929575c3fa712441c38651e148e39c893eb3  ("Add files via upload", branch main)
Repo            hoangdainghia96-star/Arena  (repoId 1457433701)
Project         prj_SqYbnVcKaSezSDYSvxug39MrMSM1  (anime-arena-cataclysm, framework vite)
Team            team_gBddsOL3SnDZZSOfaIuoHUFf
Inspector       https://vercel.com/hoangdainghia96-star/anime-arena-cataclysm/8KSCwhNrsbmo7NKNdYkg7s3MHGgk
```

## Build configuration (project settings)

```
Install Command   unzip -o anime-arena-cataclysm-v1.1.0.zip && npm install
Build Command     npm run build
Output Directory  dist
Node Version      26.x
```
The archive also ships its own `vercel.json` (framework, build/output, SPA rewrite), so these
dashboard values are no longer load-bearing.

## Artifact

```
releases/anime-arena-cataclysm-v1.1.0.zip
  size      213,916 bytes
  entries   64
  sha256    22d28b1c4a8f28fe959a59691c63c610bac64a78a9041a65ba90180626e909b1
GitHub      https://github.com/hoangdainghia96-star/Arena/blob/main/anime-arena-cataclysm-v1.1.0.zip
```

The uploaded bytes were verified to be **byte-identical** to the local artifact (SHA-256 match
after re-download from `raw.githubusercontent.com`).

## Verification evidence (run against production)

| Check | Result |
|---|---|
| `index.html` bundle reference | `index-3SOb1Er1.js` + `index-C-mDBX-T.css` — **matches local v1.1.0 build exactly** |
| JS payload | 937,173 bytes, HTTP 200 |
| Asset manifest | 18 assets · **12 eligible rigs** · 3 arenas |
| Roster names in manifest | all 12 present, incl. **Zephyrion Vale** and **Solaria Vex** |
| `/assets/models/char_zephyrion.gltf` | HTTP 200, 6,541 b |
| `/assets/models/char_solaria.gltf` | HTTP 200, 6,528 b |
| Feature markers in deployed JS | `1.1.0`, `Live Tactical Radar`, `ULTIMATE ART`, `ARENA CATACLYSM`, `CLASH LOCK`, `Slow Motion`, `Zephyrion Vale`, `Solaria Vex`, `Star-Core Implosion`, `glb-binary` — **all found** |

Pre-deploy, the archive was also validated in two clean rooms:
`unzip → npm ci (229 pkgs) → npm run build` (identical hash) → `vitest 11/11` → `validate-assets 18/18`.

---

## Rollback

Promote any earlier deployment from
https://vercel.com/hoangdainghia96-star/anime-arena-cataclysm/deployments → **⋯ → Promote to Production**.

| Deployment | Serves |
|---|---|
| `dpl_7Tp1y58Bp28V5tmWR72T3Y7rdQ4r` | v1.0.0 (previous promoted) |
| `dpl_AWsdkbYgnBiX9gc71uQxpdpipdoP` | v1.0.0 (original release) |
| `dpl_8KSCwhNrsbmo7NKNdYkg7s3MHGgk` | **v1.1.0 — current** |

To go back to v1.0.0 *and* keep the archive-based build flow, set the install command back to
`unzip -o anime-arena-cataclysm-v1.0.0.zip && npm install` before promoting.

---

## Notes for next release (v1.2.0)

1. Bump the archive filename **and** the Vercel install command together, or the build will
   silently redeploy the previous version.
2. Because `dist/assets/*` filenames are content-hashed, the fastest way to confirm a promotion
   is comparing the `index-<hash>.js` reference to the local build.
3. Users with a previously installed service worker must hard-refresh once
   (`Ctrl/Cmd + Shift + R`) to drop the v1.0.0 cached shell.
