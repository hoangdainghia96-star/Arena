# RELEASE RECORD — v1.1.1 (camera & framing pass)

**Project:** ANIME ARENA: CATACLYSM — 3D RANDOM BATTLE
**Version:** 1.1.1
**Date:** 2026-11-14
**Supersedes:** v1.1.0 (`dpl_8KSCwhNrsbmo7NKNdYkg7s3MHGgk`)

## Why this release exists

v1.1.0 shipped and was verified by bundle hash, asset count and string greps — but nobody had
ever looked at it. When the screenshots were finally taken with real WebGL, the automatic
director camera was framing empty arena floor while the fight happened off-frame, the close
shots cropped the fighters, and the 3–8 FPS readings turned out to be headless SwiftShader
software rasterisation rather than a problem with the game.

v1.1.1 is a pure camera/composition + HUD-layout pass. It changes **no simulation code**, so
replays, seeds, winners and elimination orders are bit-identical to v1.1.0.

## Local build

| Item | Value |
| --- | --- |
| JS bundle | `dist/assets/index-DNgfQ-jh.js` — 940.66 KB (250.53 KB gzip) |
| CSS bundle | `dist/assets/index-DYBXtPZE.css` — 35.61 KB (6.80 KB gzip) |
| Tests | `npx vitest run` → 11/11 passing (2 files) |
| Build time | 3.90 s |

## Release artifact

| Item | Value |
| --- | --- |
| Path | `releases/anime-arena-cataclysm-v1.1.1.zip` |
| Size | 223,864 bytes |
| sha256 | `25290c5691afb7e2ba508e6ca049c9ef797586fceb3fd8b2b51b376da7186a7d` |
| Entries | 66 files |

Clean-room check: the archive was unzipped into an empty directory and confirmed to contain
`package.json` v1.1.1, `vercel.json`, `public/assets/asset-manifest.json` (18 assets),
18 model files, and the v1.1.1 camera code (`cameraAlpha`, action-hotspot director,
line-of-sight test, procedural floor texture). `shots/`, `releases/`, `dist/`, `node_modules/`
and the operator deploy docs are excluded.

## What changed

### Camera director (the substance of this release)
1. **Action-hotspot framing.** The old director aimed at the centroid of all eight fighters
   (arena centre at spawn) or at the midpoint of the highest-scoring *pair* — both of which can
   be an empty patch of floor. It now scores local body clusters and focuses on the weighted
   centroid of real fighters, so the focus point is always on top of somebody.
2. **Frame-rate independent smoothing.** Position/look-at lerps are exponential in real elapsed
   time (`cameraAlpha`). Previously a fixed per-frame factor meant a ~0.25 s convergence at
   60 fps but ~10 s at 3 fps — the lens simply never arrived before the shot was over.
3. **Line-of-sight and standoff.** Orbit candidates are rejected for blocked sight lines through
   standing destructibles, for coming within 5 m of any fighter, and for leaving the arena lip;
   higher angles are mildly preferred.
4. **Distance from the shot.** Orbit radius derives from the framed cluster's spread
   (≈9 m tight duel → ≈17.5 m five-way brawl) with a slow breathing drift, instead of a fixed
   7.6–11.8 m.
5. **Critical beats land.** Ultimate / elimination / betrayal / awakening shots cut when the
   subject is more than 14 m away and converge ~4× faster inside their 2 s window.
6. **No corner drift.** The 0.88 multiplicative pull to centre (which shoved the action into the
   frame edge) is replaced by a clamp that only engages at the arena lip.

### Scene
- Procedural per-arena stone floor texture (8×8 tiles, hex glows, rim veins), brightness retuned.
- Destructibles got stone plinths and additive wisps; smaller central altar.

### HUD
- Right panel compacted (`w-72`, radar `size={158}`) so it clears the top bar.

## Visual verification

30+ screenshots at 1280×800 and 1440×860 through `shots/` (v1110-*, end-*, fb-*), covering
spawn, tight duel, brawl, blade clash, beam clash, ultimate cut-in banner, final blow and the
champion standings modal. Zero console/page errors in every run.

The 1–4 FPS shown in the QA screenshots is headless SwiftShader software rasterisation — it
scales linearly with viewport area (7.9 fps at 480×300 → 3.2 fps at 1600×950) with zero
longtasks. Hardware GPUs are unaffected. Do not "optimise" the renderer for it.

## Deployment steps

1. Upload `releases/anime-arena-cataclysm-v1.1.1.zip` to `hoangdainghia96-star/Arena` (`main`).
2. Update the Vercel project install command to
   `unzip -o anime-arena-cataclysm-v1.1.1.zip && npm install`
   (zip name and install command must be changed together).
3. Trigger a production deployment from `main`.
4. Verify: production `index.html` must reference `index-DNgfQ-jh.js` + `index-DYBXtPZE.css`.
   Hard-refresh to defeat any stale service worker.

## Rollback

| Version | Deployment ID |
| --- | --- |
| v1.1.0 | `dpl_8KSCwhNrsbmo7NKNdYkg7s3MHGgk` |
| v1.0.0 | `dpl_7Tp1y58Bp28V5tmWR72T3Y7rdQ4r` |

Promote from the Vercel deployments page; the install command must be reverted to the matching
zip name at the same time.
