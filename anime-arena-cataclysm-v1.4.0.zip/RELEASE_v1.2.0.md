# RELEASE RECORD — v1.2.0 (Bloom + Anime Ink + The Cataclysm Ascent)

**Version:** 1.2.0 · **Date:** 2026-11-14 · **Supersedes:** v1.1.1

## Local build

| Item | Value |
| --- | --- |
| JS | `dist/assets/index-DMcyagia.js` — 973.89 KB (258.99 KB gzip) |
| CSS | `dist/assets/index-3WiU8TxO.css` — 39.40 KB (7.30 KB gzip) |
| Tests | **22/22 passing**, 3 files |

## Artifact

| Item | Value |
| --- | --- |
| Path | `releases/anime-arena-cataclysm-v1.2.0.zip` |
| Size | ≈239 KB (exact size + checksum in `releases/SHA256SUMS.txt`) |
| sha256 | see `releases/SHA256SUMS.txt` |

Clean-room verified: unzipped into an empty directory, `npm ci` + `vitest` (22/22) + `npm run build`
reproduce byte-identical bundle hashes.

## What shipped

1. **Bloom post-processing** — EffectComposer chain using passes already in three.js r170 (zero new
   dependencies). Dynamic strength: surges on Ultimates, Awakenings, Clash Locks and bullet-time.
   Disabled at Low quality.
2. **Full-silhouette ink outlines** — was head+chest only; now every toon surface including weapons,
   hair and legs, with per-part line weight and one shared outline material.
3. **The Cataclysm Ascent** — three-round, 8-fighter-per-round elimination tournament, fully
   deterministic from a root seed, with a dedicated bracket UI.

## Design decisions worth remembering

- **A 1v1 bracket was rejected on purpose.** The standing rule is that every battle starts with
  exactly 8 unique validated fighters. Multi-round 8-way battles satisfy it; a bracket does not.
- **Health does not carry between rounds.** Carry-over would require mutating the combat engine and
  would jeopardise bit-exact replay. Each round is independent and seeds from the root.
- **`risen` challengers exist because of arithmetic.** With 12 fighters, three unique rounds of eight
  are impossible (8 + 4 + 4 exhausts the bench). The Grand Final calls back the strongest eliminated
  fighters, ranked by best finish, rather than weakening the 8-fighter rule.

## Verification performed

- 22/22 unit tests (11 new tournament tests covering determinism, advancement, no re-admission,
  roster exhaustion, champion crowning and error paths).
- Live browser QA via Playwright + WebGL: main menu, bracket, Round I start, full round played to
  completion, champion modal, "Return to the Ascent", Round II staged with 4 ADVANCED + 4 NEWCOMER.
- Zero console/page errors across every run.

## Deploy

Deployment is pending a Vercel token (direct upload) or the zip-upload flow. Production
`index.html` must reference `index-DMcyagia.js` + `index-3WiU8TxO.css` once promoted.

## Rollback

| Version | Deployment ID |
| --- | --- |
| v1.1.0 | `dpl_8KSCwhNrsbmo7NKNdYkg7s3MHGgk` |
| v1.0.0 | `dpl_7Tp1y58Bp28V5tmWR72T3Y7rdQ4r` |
