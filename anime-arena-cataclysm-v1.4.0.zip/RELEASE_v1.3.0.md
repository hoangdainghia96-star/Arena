# RELEASE RECORD — v1.3.0 (The Twelve)

**Version:** 1.3.0 · **Date:** 2026-11-14 · **Supersedes:** v1.2.0

## Build

| Item | Value |
| --- | --- |
| JS | `dist/assets/index-Cjm7I6HX.js` — 985.39 KB (262.18 KB gzip) |
| CSS | `dist/assets/index-jh-p1Rpf.css` — 39.59 KB (7.32 KB gzip) |
| Tests | 22/22 passing, 3 files |

## Artifact

`releases/anime-arena-cataclysm-v1.3.0.zip` — 246,936 bytes · 72 files
sha256 `dc67f9e80387cbd384559074dcb65b4f4091340f37c7a4e659245632e3f3c4c5`

Clean-room verified: unzipped to an empty dir, `npm ci` + `vitest` (22/22) +
`npm run build` reproduce byte-identical bundle hashes.

## The actual bug this fixes

`characters.ts` has always authored 12 unique hair styles, 12 weapons and 12
accessories. `animeCharacterMesh.ts` implemented a subset and fell through the
rest into three hardcoded defaults:

- 5 fighters → identical plain box cape
- 4 fighters → identical blade blob
- 6 fighters → identical generic spike hair

Result: twelve characters looked like about five, told apart only by hue, which
is the first thing you lose at arena distance.

## What shipped

1. Six new hairstyles: spiky, cyber-swept, braided-crown, headband-wild,
   gothic-bob, alchemist-crest.
2. Five new accessories: cape, tactical-cloak, abyss-mantle, dragon-sash,
   rose-chains.
3. Four new weapons: tonfa, greaves, gauntlets, daggers.
4. Unknown-value fallbacks now produce a sensible variant rather than a bare box.
5. **The Twelve** roster gallery screen (main menu) + `?gallery=1` dev view with
   `&focus=N` close-ups.

## Verification

- Every one of the 12 screenshotted individually and visually inspected.
- Contact sheet: `shots/ROSTER-TWELVE.png`; in-game: `shots/BATTLE-v130.png`;
  gallery screen: `shots/ROSTER-SCREEN.png`.
- Full 8-fighter battle re-rendered with the new meshes, zero page errors.

## Note for the next session

`node_modules` is not part of the workspace snapshot and is gone between
sessions — `npm install` is required before building. Chromium system libraries
(playwright deps) also need reinstalling; `npx playwright install chromium` and
the `apt-get` list in the session log.
