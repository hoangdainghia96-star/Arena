import React from 'react';
import { ChevronRight, Crown, Flame, Swords, Trophy, Users, X } from 'lucide-react';
import { CharacterDefinition } from '../types/game';
import {
  ASCENT_ADVANCERS_PER_ROUND,
  ASCENT_TOTAL_ROUNDS,
  AscentState,
  getAscentRoundName,
} from '../engine/ascentTournament';

interface AscentViewProps {
  ascent: AscentState;
  roster: CharacterDefinition[];
  onFightRound: () => void;
  onAbandon: () => void;
}

const ENTRY_LABEL: Record<string, { label: string; className: string }> = {
  seeded: { label: 'SEEDED', className: 'bg-slate-700/70 text-slate-200' },
  advanced: { label: 'ADVANCED', className: 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40' },
  newcomer: { label: 'NEWCOMER', className: 'bg-sky-500/20 text-sky-300 border border-sky-400/40' },
  risen: { label: 'RISEN', className: 'bg-amber-500/25 text-amber-200 border border-amber-400/50' },
};

export const AscentView: React.FC<AscentViewProps> = ({
  ascent,
  roster,
  onFightRound,
  onAbandon,
}) => {
  const byId = new Map(roster.map((c) => [c.id, c]));
  const isComplete = ascent.status === 'completed';
  const roundLabel = getAscentRoundName(ascent.currentRound);

  return (
    <div className="min-h-screen w-full bg-[#080a14] text-slate-100">
      {/* Ambient backdrop */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -left-40 top-0 h-[520px] w-[520px] rounded-full bg-fuchsia-600/10 blur-[110px]" />
        <div className="absolute -right-32 top-40 h-[560px] w-[560px] rounded-full bg-cyan-500/10 blur-[120px]" />
        <div className="absolute bottom-0 left-1/3 h-[420px] w-[620px] rounded-full bg-amber-500/10 blur-[130px]" />
      </div>

      <div className="relative mx-auto max-w-6xl px-6 py-10">
        {/* Header */}
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-semibold tracking-[0.35em] text-amber-300/80">
              <Flame className="h-3.5 w-3.5" />
              TOURNAMENT MODE
            </div>
            <h1 className="mt-2 text-4xl font-black tracking-tight">
              THE CATACLYSM <span className="text-amber-300">ASCENT</span>
            </h1>
            <p className="mt-2 max-w-2xl text-sm text-slate-400">
              Three consecutive eight-fighter Cataclysm battles. The top{' '}
              {ASCENT_ADVANCERS_PER_ROUND} survivors of each round advance; fresh challengers
              join from the bench. Win the Grand Final to be crowned Ascendant.
            </p>
          </div>
          <button
            onClick={onAbandon}
            className="flex items-center gap-2 rounded-lg border border-slate-700 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:border-slate-500 hover:text-white"
          >
            <X className="h-3.5 w-3.5" /> Abandon Ascent
          </button>
        </div>

        {/* Round progress rail */}
        <div className="mt-8 flex items-stretch gap-2">
          {Array.from({ length: ASCENT_TOTAL_ROUNDS }, (_, i) => {
            const n = i + 1;
            const done = ascent.rounds.some((r) => r.roundNumber === n);
            const active = n === ascent.currentRound && !isComplete;
            return (
              <div
                key={n}
                className={`flex-1 rounded-lg border px-3 py-2 ${
                  active
                    ? 'border-amber-400/70 bg-amber-400/10'
                    : done
                      ? 'border-emerald-500/40 bg-emerald-500/10'
                      : 'border-slate-800 bg-slate-900/40'
                }`}
              >
                <div className="text-[10px] font-bold tracking-widest text-slate-400">
                  ROUND {n}
                </div>
                <div
                  className={`mt-0.5 truncate text-xs font-semibold ${
                    active ? 'text-amber-200' : done ? 'text-emerald-300' : 'text-slate-500'
                  }`}
                >
                  {done ? 'Complete' : active ? 'In progress' : 'Locked'}
                </div>
              </div>
            );
          })}
        </div>

        {/* Champion banner */}
        {isComplete && ascent.championName && (
          <div className="mt-8 overflow-hidden rounded-2xl border border-amber-400/50 bg-gradient-to-r from-amber-500/20 via-amber-400/10 to-transparent p-6">
            <div className="flex items-center gap-4">
              <div className="rounded-xl bg-amber-400/20 p-3">
                <Crown className="h-7 w-7 text-amber-300" />
              </div>
              <div>
                <div className="text-[11px] font-bold tracking-[0.3em] text-amber-300">
                  ASCENDANT CHAMPION
                </div>
                <div className="text-2xl font-black">{ascent.championName}</div>
                <div className="text-xs text-slate-400">
                  Survived {ASCENT_TOTAL_ROUNDS} rounds of the Cataclysm
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Next round entrants */}
        {!isComplete && (
          <div className="mt-8 rounded-2xl border border-slate-800 bg-slate-950/60 p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-amber-300" />
                <h2 className="text-sm font-bold tracking-wide text-slate-200">
                  {roundLabel} — entrants
                </h2>
              </div>
              <span className="text-[11px] text-slate-500">
                Seed <span className="font-mono text-slate-400">{ascent.rootSeed}</span>
              </span>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {ascent.pendingEntrants.map((entry) => {
                const def = byId.get(entry.characterId);
                const badge = ENTRY_LABEL[entry.entry] ?? ENTRY_LABEL.seeded;
                return (
                  <div
                    key={entry.characterId}
                    className="rounded-lg border border-slate-800 bg-slate-900/70 p-3"
                    style={{ borderLeftColor: def?.appearance.primaryColor, borderLeftWidth: 3 }}
                  >
                    <div className="truncate text-xs font-bold text-slate-100">{entry.name}</div>
                    <div className="mt-0.5 truncate text-[10px] text-slate-500">
                      {def?.attributes.powerTier ? `${def.attributes.powerTier} Tier` : ''}
                      {def?.aiProfile.archetype ? ` · ${def.aiProfile.archetype}` : ''}
                    </div>
                    <span
                      className={`mt-2 inline-block rounded px-1.5 py-0.5 text-[9px] font-bold tracking-wider ${badge.className}`}
                    >
                      {badge.label}
                    </span>
                  </div>
                );
              })}
            </div>

            <button
              onClick={onFightRound}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 px-6 py-3 text-sm font-black tracking-wide text-slate-950 transition hover:from-amber-300 hover:to-orange-400"
            >
              <Swords className="h-4 w-4" />
              {ascent.currentRound === 1 ? 'BEGIN THE ASCENT' : `FIGHT ${roundLabel.split('—')[0].trim()}`}
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        )}

        {/* Completed rounds */}
        {ascent.rounds.length > 0 && (
          <div className="mt-6 space-y-3">
            {ascent.rounds.map((round) => (
              <div key={round.roundNumber} className="rounded-xl border border-slate-800 bg-slate-950/50 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Trophy className="h-4 w-4 text-emerald-400" />
                    <span className="text-xs font-bold tracking-wide text-slate-200">
                      {getAscentRoundName(round.roundNumber)}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    {round.arenaName} · winner{' '}
                    <span className="font-semibold text-emerald-300">{round.winnerName}</span> ·{' '}
                    {round.durationSec.toFixed(0)}s
                  </span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-1.5 sm:grid-cols-4">
                  {[...round.standings]
                    .sort((a, b) => a.rank - b.rank)
                    .map((s) => {
                      const advanced = round.advancedIds.includes(s.characterId);
                      return (
                        <div
                          key={s.characterId}
                          className={`flex items-center gap-2 rounded px-2 py-1.5 text-[11px] ${
                            advanced
                              ? 'bg-emerald-500/10 text-emerald-200'
                              : 'bg-slate-900/60 text-slate-500'
                          }`}
                        >
                          <span className="w-4 shrink-0 font-mono text-[10px] opacity-70">
                            #{s.rank}
                          </span>
                          <span className="truncate font-semibold">{s.name}</span>
                          {advanced && <ChevronRight className="ml-auto h-3 w-3 shrink-0" />}
                        </div>
                      );
                    })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
