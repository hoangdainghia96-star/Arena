import React from 'react';
import { Radar } from 'lucide-react';
import { BattleSimulationState, CharacterDefinition } from '../types/game';

interface TacticalRadarProps {
  state: BattleSimulationState;
  roster: CharacterDefinition[];
  playableRadius: number;
  followFighterId: string | null;
  onSelectFighter: (fighterId: string) => void;
  size?: number;
}

/**
 * v1.1.0 — Live Tactical Radar / Minimap
 *
 * Renders the whole living arena in top-down form: fighter blips (faction coloured),
 * facing wedges, alliance tethers, Hazards, Sanctum Core, active Clash Locks,
 * in-flight Ultimates/Awakenings, and incoming Arena Cataclysm telegraphs.
 */
export const TacticalRadar: React.FC<TacticalRadarProps> = ({
  state,
  roster,
  playableRadius,
  followFighterId,
  onSelectFighter,
  size = 196,
}) => {
  const cx = size / 2;
  const cy = size / 2;
  const pad = 8;
  const scale = (size / 2 - pad) / playableRadius;
  const colorOf = (id: string) =>
    roster.find((c) => c.id === id)?.appearance.primaryColor ?? '#f43f5e';

  const project = (x: number, z: number): [number, number] => [
    cx + x * scale,
    cy + z * scale,
  ];

  const cataclysm = state.activeCataclysm;

  return (
    <div className="bg-slate-900/85 backdrop-blur-md border border-slate-800/90 rounded-xl p-2.5">
      <div className="flex items-center justify-between mb-1.5">
        <span className="flex items-center gap-1.5 text-xs font-bold text-slate-200">
          <Radar className="w-3.5 h-3.5 text-cyan-400" />
          Live Tactical Radar
        </span>
        <span className="text-[9px] font-mono text-slate-500 uppercase">
          {(state.radarPings ?? []).length} pings
        </span>
      </div>

      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="rounded-full bg-slate-950/90 border border-cyan-500/25"
        role="img"
        aria-label="Tactical radar of the living arena"
      >
        <defs>
          <radialGradient id="radarFade" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#0ea5e9" stopOpacity="0.16" />
            <stop offset="100%" stopColor="#020617" stopOpacity="0.9" />
          </radialGradient>
        </defs>

        <circle cx={cx} cy={cy} r={size / 2 - 2} fill="url(#radarFade)" />

        {/* Arena boundary & tactical rings */}
        <circle cx={cx} cy={cy} r={playableRadius * scale} fill="none" stroke="#22d3ee" strokeOpacity="0.55" strokeWidth="1.5" />
        {[0.33, 0.66].map((r) => (
          <circle
            key={`ring-${r}`}
            cx={cx}
            cy={cy}
            r={playableRadius * scale * r}
            fill="none"
            stroke="#38bdf8"
            strokeOpacity="0.16"
            strokeWidth="1"
            strokeDasharray="3 5"
          />
        ))}
        <line x1={cx} y1={pad} x2={cx} y2={size - pad} stroke="#38bdf8" strokeOpacity="0.12" strokeWidth="1" />
        <line x1={pad} y1={cy} x2={size - pad} y2={cy} stroke="#38bdf8" strokeOpacity="0.12" strokeWidth="1" />

        {/* Radar sweep */}
        <g style={{ transformOrigin: `${cx}px ${cy}px`, transform: `rotate(${(state.elapsedSec * 55) % 360}deg)` }}>
          <path
            d={`M ${cx} ${cy} L ${cx} ${pad} A ${size / 2 - pad} ${size / 2 - pad} 0 0 1 ${cx + (size / 2 - pad) * 0.71} ${cy - (size / 2 - pad) * 0.71} Z`}
            fill="#22d3ee"
            fillOpacity="0.08"
          />
        </g>

        {/* Incoming Arena Cataclysm telegraph */}
        {cataclysm &&
          (() => {
            const [px, py] = project(cataclysm.position[0], cataclysm.position[2]);
            return (
              <g>
                <circle
                  cx={px}
                  cy={py}
                  r={cataclysm.radius * scale}
                  fill={cataclysm.color}
                  fillOpacity="0.18"
                  stroke={cataclysm.color}
                  strokeWidth="1.5"
                  strokeDasharray="4 3"
                />
                <circle cx={px} cy={py} r={3} fill={cataclysm.accentColor} />
              </g>
            );
          })()}

        {/* Environmental hazard / shrine zones */}
        {state.activeZones.map((zone) => {
          const [px, py] = project(zone.position[0], zone.position[2]);
          const isShrine = zone.type === 'shrine-blessing';
          return (
            <circle
              key={zone.id}
              cx={px}
              cy={py}
              r={Math.max(3, zone.radius * scale)}
              fill={zone.color}
              fillOpacity={isShrine ? 0.24 : 0.12}
              stroke={zone.color}
              strokeOpacity="0.7"
              strokeWidth="1"
            />
          );
        })}

        {/* Alliance tethers */}
        {state.alliances
          .filter((al) => al.outcome === 'active')
          .map((al) => {
            const a = state.fighters.find((f) => f.id === al.memberAId);
            const b = state.fighters.find((f) => f.id === al.memberBId);
            if (!a || !b || !a.isAlive || !b.isAlive) return null;
            const [ax, ay] = project(a.position[0], a.position[2]);
            const [bx, by] = project(b.position[0], b.position[2]);
            return (
              <line
                key={al.id}
                x1={ax}
                y1={ay}
                x2={bx}
                y2={by}
                stroke="#facc15"
                strokeWidth="1.4"
                strokeDasharray="4 3"
                strokeOpacity="0.8"
              />
            );
          })}

        {/* Clash Lock struggle markers */}
        {(state.clashLocks ?? [])
          .filter((l) => !l.resolved)
          .map((lock) => {
            const [px, py] = project(lock.position[0], lock.position[2]);
            return (
              <g key={lock.id}>
                <circle cx={px} cy={py} r={9} fill="none" stroke="#fde047" strokeWidth="1.6">
                  <animate attributeName="r" values="6;11;6" dur="0.9s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="1;0.35;1" dur="0.9s" repeatCount="indefinite" />
                </circle>
                <path
                  d={`M ${px - 4} ${py - 4} L ${px + 4} ${py + 4} M ${px + 4} ${py - 4} L ${px - 4} ${py + 4}`}
                  stroke="#fef9c3"
                  strokeWidth="1.8"
                />
              </g>
            );
          })}

        {/* Fighter blips */}
        {state.fighters.map((f) => {
          const [px, py] = project(f.position[0], f.position[2]);
          const col = colorOf(f.id);
          const isFollowed = followFighterId === f.id;
          const clashLocked = (state.clashLocks ?? []).some(
            (l) => !l.resolved && (l.fighterAId === f.id || l.fighterBId === f.id)
          );

          return (
            <g
              key={f.id}
              onClick={() => onSelectFighter(f.id)}
              style={{ cursor: 'pointer' }}
              opacity={f.isAlive ? 1 : 0.35}
            >
              {/* Facing wedge */}
              {f.isAlive && (
                <path
                  d={`M ${px} ${py} L ${px + Math.sin(f.rotationY) * 13 - Math.cos(f.rotationY) * 4} ${
                    py + Math.cos(f.rotationY) * 13 + Math.sin(f.rotationY) * 4
                  } L ${px + Math.sin(f.rotationY) * 13 + Math.cos(f.rotationY) * 4} ${
                    py + Math.cos(f.rotationY) * 13 - Math.sin(f.rotationY) * 4
                  } Z`}
                  fill={col}
                  fillOpacity="0.28"
                />
              )}
              {isFollowed && (
                <circle cx={px} cy={py} r={8} fill="none" stroke="#fcd34d" strokeWidth="1.6" />
              )}
              <circle
                cx={px}
                cy={py}
                r={f.isAlive ? 4.6 : 3}
                fill={f.isAlive ? col : '#475569'}
                stroke={f.isAwakened ? '#fde047' : '#0f172a'}
                strokeWidth={f.isAwakened ? 1.8 : 1}
              >
                {f.isAwakened && f.isAlive && (
                  <animate attributeName="stroke-opacity" values="1;0.35;1" dur="1.1s" repeatCount="indefinite" />
                )}
              </circle>
              {clashLocked && (
                <circle cx={px} cy={py} r={7} fill="none" stroke="#fbbf24" strokeWidth="1.2" strokeDasharray="2 2" />
              )}
              {f.animationState === 'ultimate' && f.isAlive && (
                <circle cx={px} cy={py} r={10} fill="none" stroke="#a855f7" strokeWidth="1.4">
                  <animate attributeName="r" values="8;14;8" dur="0.8s" repeatCount="indefinite" />
                </circle>
              )}
            </g>
          );
        })}
      </svg>

      {/* Radar legend */}
      <div className="mt-1.5 grid grid-cols-2 gap-x-2 gap-y-0.5 text-[9px] text-slate-400">
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-300" /> Clash Lock
        </span>
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500" /> Cataclysm
        </span>
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-violet-400" /> Ultimate
        </span>
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> Sanctum
        </span>
      </div>
    </div>
  );
};
