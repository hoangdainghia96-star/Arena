import React from 'react';
import { Swords, Sparkles, Zap } from 'lucide-react';
import { BattleEvent, CharacterDefinition } from '../types/game';

export interface CutInBannerData {
  eventId: string;
  actorId: string;
  actorName: string;
  abilityName: string;
  kind: 'ultimate' | 'awakening' | 'clash' | 'cataclysm';
  quote: string;
}

const KIND_META: Record<
  CutInBannerData['kind'],
  { label: string; from: string; via: string; icon: React.ReactNode }
> = {
  ultimate: {
    label: 'ULTIMATE ART',
    from: 'from-violet-600/95',
    via: 'via-fuchsia-600/80',
    icon: <Zap className="w-4 h-4" />,
  },
  awakening: {
    label: 'AWAKENING',
    from: 'from-rose-600/95',
    via: 'via-amber-500/80',
    icon: <Sparkles className="w-4 h-4" />,
  },
  clash: {
    label: 'CLASH LOCK',
    from: 'from-amber-500/95',
    via: 'via-orange-600/80',
    icon: <Swords className="w-4 h-4" />,
  },
  cataclysm: {
    label: 'ARENA CATACLYSM',
    from: 'from-sky-600/95',
    via: 'via-cyan-500/80',
    icon: <Sparkles className="w-4 h-4" />,
  },
};

/**
 * v1.1.0 — Full-Screen Anime Ultimate / Awakening Cut-In Banner.
 * A true anime cut-in: diagonal speed lines, character silhouette plate,
 * oversized slanted typography, and the signature voice line.
 */
export const UltimateCutIn: React.FC<{
  data: CutInBannerData;
  character?: CharacterDefinition;
  exiting?: boolean;
}> = ({ data, character, exiting = false }) => {
  const meta = KIND_META[data.kind];
  const accent = character?.appearance.accentColor ?? '#fde047';
  const primary = character?.appearance.primaryColor ?? '#f43f5e';

  return (
    <div
      className={`pointer-events-none absolute inset-0 z-30 overflow-hidden transition-opacity duration-300 ${
        exiting ? 'opacity-0' : 'opacity-100'
      }`}
      aria-live="polite"
    >
      {/* Diagonal anime speed-line field */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `repeating-linear-gradient(112deg, rgba(255,255,255,0.14) 0px, rgba(255,255,255,0.14) 2px, transparent 2px, transparent 16px)`,
          opacity: 0.5,
          maskImage: 'radial-gradient(ellipse at center, black 30%, transparent 78%)',
          WebkitMaskImage: 'radial-gradient(ellipse at center, black 30%, transparent 78%)',
        }}
      />

      {/* Colour slash band across the middle */}
      <div
        className={`absolute left-0 right-0 top-[38%] h-[26%] bg-gradient-to-r ${meta.from} ${meta.via} to-transparent shadow-[0_0_80px_rgba(0,0,0,0.6)]`}
        style={{
          transform: 'skewY(-3.5deg)',
          borderTop: `2px solid ${accent}`,
          borderBottom: `2px solid ${accent}`,
        }}
      >
        <div className="absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              'repeating-linear-gradient(90deg, rgba(0,0,0,0.35) 0px, rgba(0,0,0,0.35) 1px, transparent 1px, transparent 12px)',
          }}
        />
      </div>

      {/* Character silhouette plate */}
      <div
        className="absolute right-6 sm:right-16 top-[30%] h-[42%] w-40 sm:w-56 rounded-2xl border-2 shadow-2xl overflow-hidden"
        style={{
          borderColor: accent,
          background: `linear-gradient(160deg, ${primary}, #020617 78%)`,
        }}
      >
        <div
          className="absolute inset-0 opacity-70"
          style={{
            background: `radial-gradient(circle at 50% 32%, ${accent}55, transparent 62%)`,
          }}
        />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-3">
          <span
            className="text-[10px] font-black uppercase tracking-[0.28em] mb-1"
            style={{ color: accent }}
          >
            {character?.universe ?? 'Cataclysm Fighter'}
          </span>
          <span className="text-lg sm:text-2xl font-black text-white leading-tight drop-shadow">
            {data.actorName}
          </span>
          <span className="text-[10px] text-slate-300 mt-1">{character?.title}</span>
          <span
            className="mt-2 text-[9px] font-black px-2 py-0.5 rounded"
            style={{ backgroundColor: accent, color: '#0f172a' }}
          >
            TIER {character?.attributes.powerTier ?? 'S'}
          </span>
        </div>
      </div>

      {/* Slanted typography */}
      <div
        className="absolute left-6 sm:left-14 top-[38%] h-[26%] flex flex-col justify-center"
        style={{ transform: 'skewY(-3.5deg)' }}
      >
        <div className="flex items-center gap-2 text-white">
          <span className="px-2 py-0.5 rounded bg-black/45 border border-white/40 text-[10px] font-black uppercase tracking-[0.22em] flex items-center gap-1.5">
            {meta.icon}
            {meta.label}
          </span>
        </div>
        <h2
          className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white uppercase mt-1"
          style={{ textShadow: `0 3px 0 ${primary}, 0 0 34px ${accent}aa` }}
        >
          {data.abilityName}
        </h2>
        <p className="text-xs sm:text-sm italic text-white/90 max-w-xl mt-1 line-clamp-2">
          “{data.quote}”
        </p>
      </div>
    </div>
  );
};

/**
 * Builds cut-in banner data from a BattleEvent when the event is dramatic enough.
 */
export function buildCutInData(
  event: BattleEvent,
  character: CharacterDefinition | undefined
): CutInBannerData | null {
  if (event.type === 'ULTIMATE_UNLEASHED' && event.actorId) {
    return {
      eventId: event.id,
      actorId: event.actorId,
      actorName: event.actorName ?? 'Unknown Fighter',
      abilityName: event.abilityName ?? 'Ultimate Art',
      kind: 'ultimate',
      quote: event.voiceLine ?? character?.voicePack.ultimate ?? 'Witness true power!',
    };
  }
  if (event.type === 'AWAKENING_TRIGGERED' && event.actorId) {
    return {
      eventId: event.id,
      actorId: event.actorId,
      actorName: event.actorName ?? 'Unknown Fighter',
      abilityName: event.abilityName ?? 'Awakening',
      kind: 'awakening',
      quote: event.voiceLine ?? character?.voicePack.awakening ?? 'I will not fall here!',
    };
  }
  if (event.type === 'CLASH_LOCK' && event.actorId && event.targetId) {
    return {
      eventId: event.id,
      actorId: event.actorId,
      actorName: `${event.actorName}  ⟷  ${event.targetName}`,
      abilityName: event.abilityName ?? 'Clash Lock',
      kind: 'clash',
      quote: 'Steel screams as two wills collide — who breaks first?!',
    };
  }
  return null;
}
