import { ArenaCataclysmEventSpec, CataclysmEventType } from '../types/game';

/**
 * v1.1.0 — Stage-Specific Mid-Battle "Arena Cataclysm" Events
 *
 * Each living 3D arena possesses its own signature cataclysm phenomenon.
 * Events telegraph (warning ring + countdown) before impact so spectators and
 * fighters can read the danger, then detonate with a stage-coloured shockwave.
 */
export const CATACLYSM_EVENT_SPECS: Record<CataclysmEventType, ArenaCataclysmEventSpec> = {
  'skyfall-meteor': {
    id: 'skyfall-meteor',
    name: 'Skyfall Meteor',
    description: 'A burning shard of the shattered sky cathedral plummets onto the arena floor.',
    stages: [1, 2, 3],
    telegraphSec: 2.6,
    dangerDamage: 78,
    radius: 6.4,
    color: '#f59e0b',
    accentColor: '#fef08a',
  },
  'runic-consecration': {
    id: 'runic-consecration',
    name: 'Runic Consecration',
    description: 'The Sanctum Runes consecrate the central altar — holy pillars erupt for those who linger.',
    stages: [2, 3],
    telegraphSec: 2.2,
    dangerDamage: 64,
    radius: 7.2,
    color: '#fbbf24',
    accentColor: '#fef3c7',
  },
  'plasma-meltdown': {
    id: 'plasma-meltdown',
    name: 'Plasma Meltdown',
    description: 'Neo-Kyoto reactor vents rupture and spray superheated plasma across the crater.',
    stages: [1, 2, 3],
    telegraphSec: 2.4,
    dangerDamage: 72,
    radius: 5.8,
    color: '#06b6d4',
    accentColor: '#a5f3fc',
  },
  'emp-overload': {
    id: 'emp-overload',
    name: 'Emp Overload',
    description: 'A grid EMP shock drains Aether energy from every fighter caught in the discharge.',
    stages: [2, 3],
    telegraphSec: 2.0,
    dangerDamage: 46,
    radius: 8.5,
    color: '#22d3ee',
    accentColor: '#ecfeff',
  },
  'gravity-collapse': {
    id: 'gravity-collapse',
    name: 'Gravity Collapse',
    description: 'The Obsidian Rift folds inward, dragging fighters toward a crushing gravity singularity.',
    stages: [2, 3],
    telegraphSec: 2.5,
    dangerDamage: 68,
    radius: 7.8,
    color: '#a855f7',
    accentColor: '#e9d5ff',
  },
  'star-core-implosion': {
    id: 'star-core-implosion',
    name: 'Star-Core Implosion',
    description: 'A fallen star-core destabilises and implodes, releasing a cataclysmic shockwave.',
    stages: [3],
    telegraphSec: 2.8,
    dangerDamage: 96,
    radius: 9.4,
    color: '#ef4444',
    accentColor: '#fca5a5',
  },
  'aether-flood': {
    id: 'aether-flood',
    name: 'Aether Flood',
    description: 'Raw Aether overflows the altar and surges outward in a luminous tide.',
    stages: [2, 3],
    telegraphSec: 2.3,
    dangerDamage: 54,
    radius: 9.8,
    color: '#38bdf8',
    accentColor: '#bae6fd',
  },
  'shatter-rain': {
    id: 'shatter-rain',
    name: 'Shatter Rain',
    description: 'Crystalline debris rains from the collapsing outer arches in a razor barrage.',
    stages: [3],
    telegraphSec: 2.1,
    dangerDamage: 62,
    radius: 6.8,
    color: '#f472b6',
    accentColor: '#fbcfe8',
  },
};

/** Signature cataclysm pool per arena theme. */
export const ARENA_CATACLYSM_POOLS: Record<string, CataclysmEventType[]> = {
  arena_sanctum: ['skyfall-meteor', 'runic-consecration', 'aether-flood', 'shatter-rain'],
  arena_neokyoto: ['plasma-meltdown', 'emp-overload', 'skyfall-meteor', 'plasma-meltdown'],
  arena_obsidian: ['gravity-collapse', 'star-core-implosion', 'skyfall-meteor', 'shatter-rain'],
};

export const FALLBACK_CATACLYSM_POOL: CataclysmEventType[] = [
  'skyfall-meteor',
  'shatter-rain',
  'plasma-meltdown',
];
