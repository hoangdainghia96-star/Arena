import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { INITIAL_CHARACTER_ROSTER } from '../data/characters';
import { buildArticulatedAnimeCharacter } from '../rendering/animeCharacterMesh';

/**
 * v1.3.0 dev-only roster gallery.
 * Renders all twelve fighters in a ring so the authored hair / accessory /
 * weapon designs can be compared side by side. Reached with ?gallery=1.
 */
export const RosterGallery: React.FC = () => {
  const mountRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const width = window.innerWidth;
    const height = window.innerHeight;
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#0a0d1c');

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 200);
    camera.position.set(0, 7.2, 15.5);
    camera.lookAt(0, 1.15, 0);

    scene.add(new THREE.AmbientLight(0xffffff, 1.15));
    const key = new THREE.DirectionalLight(0xffffff, 1.6);
    key.position.set(6, 12, 8);
    scene.add(key);
    const rim = new THREE.DirectionalLight(0x88aaff, 0.9);
    rim.position.set(-8, 6, -9);
    scene.add(rim);

    const grid = new THREE.GridHelper(30, 30, 0x223055, 0x151c30);
    grid.position.y = 0;
    scene.add(grid);

    const params = new URLSearchParams(window.location.search);
    const focusRaw = params.get('focus');
    const focus = focusRaw === null ? null : Number(focusRaw);

    const roster = INITIAL_CHARACTER_ROSTER.slice(0, 12);
    const radius = focus === null ? 7.4 : 0;
    const labels: { el: HTMLDivElement }[] = [];

    const shown = focus === null ? roster : [roster[focus]].filter(Boolean);
    shown.forEach((def, i) => {
      const a = (i / shown.length) * Math.PI * 2 - Math.PI / 2;
      const rig = buildArticulatedAnimeCharacter(def, 'Ultra');
      rig.root.position.set(Math.cos(a) * radius, 0, Math.sin(a) * radius);
      // face the camera-ish centre
      rig.root.rotation.y = Math.atan2(-Math.cos(a), -Math.sin(a));
      scene.add(rig.root);

      const el = document.createElement('div');
      el.textContent = def.name;
      el.style.cssText = [
        'position:absolute',
        'transform:translate(-50%,0)',
        'font:700 12px/1.4 ui-sans-serif,system-ui,sans-serif',
        'color:#e8eeff',
        'text-shadow:0 1px 6px #000,0 0 12px #000',
        'background:rgba(10,14,28,.72)',
        'border:1px solid rgba(120,150,220,.35)',
        'border-radius:6px',
        'padding:3px 7px',
        'white-space:nowrap',
        'pointer-events:none',
      ].join(';');
      mount.appendChild(el);
      labels.push({ el });
    });

    if (focus !== null) {
      camera.position.set(1.7, 2.35, 3.5);
      camera.lookAt(0, 1.25, 0);
      grid.visible = false;
    }

    const labelHost = mount;
    const tmp = new THREE.Vector3();

    let raf = 0;
    let t = 0;
    const animate = () => {
      t += 0.016;
      // gentle turntable so every silhouette is seen from the front
      const spin = t * 0.06;
      let idx = 0;
      for (const child of scene.children) {
        if ((child as THREE.Group).name?.startsWith('Fighter_')) {
          child.position.y = Math.sin(t * 1.1 + idx * 0.6) * 0.045;
          const a = focus !== null
            ? Math.PI * 0.78
            : (idx / shown.length) * Math.PI * 2 - Math.PI / 2 + spin;
          child.position.x = Math.cos(a) * radius;
          child.position.z = Math.sin(a) * radius;
          child.rotation.y = focus !== null
            ? -0.5
            : Math.atan2(-Math.cos(a), -Math.sin(a));
          idx++;
        }
      }
      // reposition labels each frame
      let k = 0;
      for (const child of scene.children) {
        if ((child as THREE.Group).name?.startsWith('Fighter_')) {
          tmp.set(child.position.x, 2.55, child.position.z).project(camera);
          const x = (tmp.x * 0.5 + 0.5) * width;
          const y = (-tmp.y * 0.5 + 0.5) * height;
          const lbl = labels[k]?.el;
          if (lbl) {
            lbl.style.left = `${x}px`;
            lbl.style.top = `${y}px`;
            lbl.style.opacity = tmp.z > 1 ? '0' : '1';
          }
          k++;
        }
      }
      renderer.render(scene, camera);
      raf = requestAnimationFrame(animate);
    };
    animate();
    lblFix(labelHost);

    return () => {
      cancelAnimationFrame(raf);
      renderer.dispose();
      if (renderer.domElement.parentElement === mount) mount.removeChild(renderer.domElement);
      labels.forEach((l) => l.el.remove());
    };
  }, []);

  return <div ref={mountRef} style={{ position: 'fixed', inset: 0, background: '#0a0d1c' }} />;
}
export const RosterGalleryMount = RosterGallery;
function unusedPlaceholder() {
  return null;
};

function lblFix(_host: HTMLElement) {
  /* labels are appended to the mount in the effect above */
}
