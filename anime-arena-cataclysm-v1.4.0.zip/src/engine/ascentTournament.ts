import { CharacterDefinition } from '../types/game';
import { SeededRNG } from '../utils/prng';

/**
 * v1.2.0 — THE CATACLYSM ASCENT
 *
 * A three-round elimination gauntlet.
 *
 * Design constraint that shaped everything here: every battle in this game must
 * start with exactly 8 unique validated fighters. A classic 1v1 bracket would
 * break that rule, so each round is instead a full 8-way Cataclysm battle:
 *
 *   Round 1: 8 seeded entrants       -> top 4 survivors advance
 *   Round 2: 4 survivors + 4 newcomers -> top 4 advance
 *   Round 3 (Grand Final): 4 survivors + 4 newcomers -> one champion
 *
 * With a 12-fighter roster that consumes exactly all 12 fighters, and every
 * round is independent and deterministic given its own seed. No fighter's health
 * carries between rounds — that would mutate the combat engine and jeopardise the
 * bit-exact replay guarantee.
 */

export const ASCENT_TOTAL_ROUNDS = 3;
export const ASCENT_ADVANCERS_PER_ROUND = 4;

export const ASCENT_ROUND_NAMES = [
  'Round I — The Opening Cataclysm',
  'Round II — The Survivors Clash',
  'Round III — The Grand Final',
] as const;

export interface AscentRoundEntrant {
  characterId: string;
  name: string;
  /**
   * How the fighter got into this round.
   * `risen` = previously eliminated, called back by the Cataclysm because the
   * bench ran dry. Only happens on the Grand Final with a 12-fighter roster.
   */
  entry: 'seeded' | 'advanced' | 'newcomer' | 'risen';
  /** Round they last fought in, if they advanced from one. */
  fromRound?: number;
}

export interface AscentRoundResult {
  roundNumber: number;
  seed: string;
  arenaId: string;
  arenaName: string;
  battleId: string;
  entrantIds: string[];
  /** Ordered elimination list, winner first. */
  standings: {
    characterId: string;
    name: string;
    rank: number;
    eliminatedAtSec: number | null;
  }[];
  winnerId: string;
  winnerName: string;
  durationSec: number;
  advancedIds: string[];
}

export interface AscentState {
  id: string;
  createdAtIso: string;
  /** Seed root — every round seed is derived from this, so a whole tournament replays exactly. */
  rootSeed: string;
  rosterIds: string[];
  currentRound: number;
  rounds: AscentRoundResult[];
  /** Entrants staged for the round currently being played. */
  pendingEntrants: AscentRoundEntrant[];
  status: 'ready' | 'in-progress' | 'completed';
  championId: string | null;
  championName: string | null;
}

/** Deterministic per-round seed: same root seed always yields the same ladder. */
export function deriveRoundSeed(rootSeed: string, roundNumber: number): string {
  const rng = new SeededRNG(`${rootSeed}:round:${roundNumber}`);
  return rng.seedString;
}

/**
 * Builds round 1: eight distinct entrants drawn from the eligible roster.
 * Mirrors `selectEightRandomFighters` but seeded from the tournament root so the
 * opening round is reproducible.
 */
export function createAscent(
  eligible: CharacterDefinition[],
  seedInput?: string
): AscentState {
  if (eligible.length < 8) {
    throw new Error(
      `INSUFFICIENT_ELIGIBLE_FIGHTERS: The Ascent requires at least 8 validated fighters, got ${eligible.length}.`
    );
  }

  const rng = new SeededRNG(seedInput);
  const rootSeed = rng.seedString;
  const shuffled = rng.shuffle(eligible).slice(0, 8);

  const pendingEntrants: AscentRoundEntrant[] = shuffled.map((c) => ({
    characterId: c.id,
    name: c.name,
    entry: 'seeded',
  }));

  return {
    id: `ascent_${rootSeed.slice(-8)}`,
    createdAtIso: new Date().toISOString(),
    rootSeed,
    rosterIds: eligible.map((c) => c.id),
    currentRound: 1,
    rounds: [],
    pendingEntrants,
    status: 'ready',
    championId: null,
    championName: null,
  };
}

/** Fighters not currently in the tournament — the pool that refills each round. */
export function getBenchFighters(
  eligible: CharacterDefinition[],
  state: AscentState
): CharacterDefinition[] {
  const used = new Set(state.pendingEntrants.map((e) => e.characterId));
  for (const round of state.rounds) {
    for (const id of round.entrantIds) used.add(id);
  }
  return eligible.filter((c) => !used.has(c.id));
}

export interface AscentStandingInput {
  characterId: string;
  name: string;
  rank: number;
  eliminatedAtSec: number | null;
}

/**
 * Records a finished round and stages the next one.
 *
 * Advanced fighters keep their identity; the remaining slots are filled from the
 * bench, drawn deterministically from the round seed so a replay of the same
 * tournament produces the same matchups.
 */
export function recordAscentRound(
  state: AscentState,
  result: Omit<AscentRoundResult, 'advancedIds'>,
  eligible: CharacterDefinition[]
): AscentState {
  if (state.status === 'completed') {
    throw new Error('ASCENT_ALREADY_COMPLETE');
  }
  if (result.roundNumber !== state.currentRound) {
    throw new Error(
      `ASCENT_ROUND_MISMATCH: expected round ${state.currentRound}, got ${result.roundNumber}.`
    );
  }

  // 1. Declare the advancers (top N of the standings).
  const advancers = [...result.standings]
    .sort((a, b) => a.rank - b.rank)
    .slice(0, ASCENT_ADVANCERS_PER_ROUND);

  const advancedIds = advancers.map((a) => a.characterId);
  const completedRound: AscentRoundResult = { ...result, advancedIds };

  const rounds = [...state.rounds, completedRound];
  const isFinal = result.roundNumber >= ASCENT_TOTAL_ROUNDS;

  // 2. Grand Final finished — the rank-1 fighter is champion.
  if (isFinal) {
    const champion = advancers[0];
    return {
      ...state,
      rounds,
      currentRound: result.roundNumber,
      pendingEntrants: [],
      status: 'completed',
      championId: champion.characterId,
      championName: champion.name,
    };
  }

  // 3. Stage the next round: advancers + deterministic bench fill.
  const nextRound = result.roundNumber + 1;
  const advancedEntrants: AscentRoundEntrant[] = advancers.map((a) => ({
    characterId: a.characterId,
    name: a.name,
    entry: 'advanced',
    fromRound: result.roundNumber,
  }));

  const alreadyIn = new Set([
    ...advancedEntrants.map((e) => e.characterId),
    // Nobody who already fought and was eliminated may return.
    ...rounds.flatMap((r) =>
      r.standings
        .filter((s) => !r.advancedIds.includes(s.characterId))
        .map((s) => s.characterId)
    ),
  ]);

  const bench = eligible.filter((c) => !alreadyIn.has(c.id));
  const needed = 8 - advancedEntrants.length;
  const fillRng = new SeededRNG(`${state.rootSeed}:fill:${nextRound}`);
  const newcomers: AscentRoundEntrant[] = fillRng
    .shuffle(bench)
    .slice(0, needed)
    .map((c) => ({ characterId: c.id, name: c.name, entry: 'newcomer' }));

  // A 12-fighter roster cannot sustain three rounds of eight unique fighters
  // (8 + 4 + 4 exhausts the bench). Rather than shrink the final or weaken the
  // 8-fighter rule, the Cataclysm calls back the strongest eliminated fighters
  // as `risen` challengers. Deterministic: best rank across all rounds first.
  const stillNeeded = needed - newcomers.length;
  const risenEntrants: AscentRoundEntrant[] = [];
  if (stillNeeded > 0) {
    const bestRankById = new Map<string, number>();
    for (const round of rounds) {
      for (const standing of round.standings) {
        if (round.advancedIds.includes(standing.characterId)) continue;
        const prev = bestRankById.get(standing.characterId);
        if (prev === undefined || standing.rank < prev) {
          bestRankById.set(standing.characterId, standing.rank);
        }
      }
    }
    // NOTE: deliberately NOT filtered by `alreadyIn` — that set holds every
    // eliminated fighter, which is exactly the pool being called back. Only
    // fighters who have advanced into this round are ineligible.
    const inThisRound = new Set(advancedEntrants.map((e) => e.characterId));
    const callable = eligible
      .filter((c) => bestRankById.has(c.id) && !inThisRound.has(c.id))
      .sort((a, b) => (bestRankById.get(a.id) ?? 99) - (bestRankById.get(b.id) ?? 99));

    for (const c of callable.slice(0, stillNeeded)) {
      risenEntrants.push({ characterId: c.id, name: c.name, entry: 'risen' });
    }
  }

  const staged = [...advancedEntrants, ...newcomers, ...risenEntrants];
  if (staged.length < 8) {
    throw new Error(
      `ASCENT_NOT_ENOUGH_FIGHTERS: round ${nextRound} needs 8 fighters but only ${staged.length} are available (roster of ${eligible.length}).`
    );
  }

  return {
    ...state,
    rounds,
    currentRound: nextRound,
    pendingEntrants: staged,
    status: 'ready',
  };
}

export function getAscentRoundName(roundNumber: number): string {
  return ASCENT_ROUND_NAMES[roundNumber - 1] ?? `Round ${roundNumber}`;
}
