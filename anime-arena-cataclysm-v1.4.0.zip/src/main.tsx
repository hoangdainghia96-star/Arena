/// <reference types="vite/client" />
import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import { RosterGallery } from './dev/RosterGallery';
import './index.css';

// Register service worker for local/offline asset caching when supported
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {
      // Service worker optional in sandboxed preview iframes
    });
  });
}

// v1.3.0 — dev-only roster gallery, reached with ?gallery=1
const showGallery = new URLSearchParams(window.location.search).get('gallery') === '1';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    {showGallery ? <RosterGallery /> : <App />}
  </React.StrictMode>
);
