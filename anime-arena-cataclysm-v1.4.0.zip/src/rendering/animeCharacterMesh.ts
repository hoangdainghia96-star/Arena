import * as THREE from 'three';
import {
  CharacterDefinition,
  FighterAnimationState,
  GraphicsQualityPreset,
} from '../types/game';

let cachedToonGradientMap: THREE.DataTexture | null = null;

/**
 * Generates a crisp 4-band anime cel-shading ramp texture using NearestFilter.
 */
export function getAnimeCelGradientMap(): THREE.DataTexture {
  if (cachedToonGradientMap) return cachedToonGradientMap;
  const colors = new Uint8Array([
    68, 68, 78, 255,   // Deep anime shadow band
    138, 138, 152, 255, // Mid-shadow band
    215, 215, 228, 255, // Lit band
    255, 255, 255, 255, // Specular rim band
  ]);
  const texture = new THREE.DataTexture(colors, 4, 1, THREE.RGBAFormat);
  texture.minFilter = THREE.NearestFilter;
  texture.magFilter = THREE.NearestFilter;
  texture.generateMipmaps = false;
  texture.needsUpdate = true;
  cachedToonGradientMap = texture;
  return texture;
}

export interface ArticulatedCharacterRig {
  characterId: string;
  root: THREE.Group;
  hips: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  hair: THREE.Group;
  accessory: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  weapon: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  auraRing: THREE.Mesh;
  awakeningCorona: THREE.Mesh;
  guardDome: THREE.Mesh;
  targetLine?: THREE.Line;
  // v1.1.0 cinematic upgrades
  /** Eye pieces whose scale/emissive react to combat emotion */
  eyes: {
    left: THREE.Mesh;
    right: THREE.Mesh;
    leftBrow: THREE.Mesh;
    rightBrow: THREE.Mesh;
    material: THREE.MeshBasicMaterial;
  };
  /** Cyclone of 3D weapon slash ribbons driven by the active ability */
  slashRibbons: {
    group: THREE.Group;
    meshes: THREE.Mesh[];
  };
  /** Ghost silhouettes left behind during dashes and awakening bursts */
  afterimages: {
    group: THREE.Group;
    ghosts: THREE.Mesh[];
    material: THREE.MeshBasicMaterial;
  };
  /** Secondary off-hand weapon (dual katanas / focus talisman) */
  offhandWeapon?: THREE.Group;
  previousPosition: THREE.Vector3;
  facingAngle: number;
}

function createCelMaterial(hexColor: string, emissiveHex?: string, emissiveIntensity = 0.15): THREE.MeshToonMaterial {
  return new THREE.MeshToonMaterial({
    color: new THREE.Color(hexColor),
    gradientMap: getAnimeCelGradientMap(),
    emissive: emissiveHex ? new THREE.Color(emissiveHex) : new THREE.Color(hexColor),
    emissiveIntensity,
  });
}

/**
 * v1.2.0 — Anime ink outlines.
 *
 * One shared material for every outline in the game (outlines are pure flat
 * black, so there is no reason for 8 fighters x 12 meshes to own 96 materials).
 * Outlining the full silhouette — limbs, weapons, hair, cape — is what makes the
 * cel-shading read as hand-inked anime rather than shaded low-poly.
 */
let sharedInkOutlineMaterial: THREE.MeshBasicMaterial | null = null;
function getInkOutlineMaterial(): THREE.MeshBasicMaterial {
  if (!sharedInkOutlineMaterial) {
    sharedInkOutlineMaterial = new THREE.MeshBasicMaterial({
      color: 0x05060c,
      side: THREE.BackSide,
    });
  }
  return sharedInkOutlineMaterial;
}

function addOutlineSubmesh(mesh: THREE.Mesh, thickness = 0.032): void {
  if (mesh.userData.hasInkOutline) return;
  mesh.userData.hasInkOutline = true;
  const outline = new THREE.Mesh(mesh.geometry, getInkOutlineMaterial());
  outline.scale.setScalar(1 + thickness);
  outline.name = 'cel_outline';
  outline.castShadow = false;
  outline.receiveShadow = false;
  mesh.add(outline);
}

/** Outlines every cel-shaded surface under a node, tuned per-part. */
function inkOutlineSilhouette(node: THREE.Object3D): void {
  node.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (!mesh.isMesh) return;
    if (mesh.name === 'cel_outline') return;
    if (Array.isArray(mesh.material)) return;
    // Only cel surfaces get inked — additive auras, eyes and glow meshes must
    // stay unoutlined or they turn into black blobs under bloom.
    if (!(mesh.material instanceof THREE.MeshToonMaterial)) return;
    if (mesh.userData.hasInkOutline) return;
    // Thin parts (blades, spikes, fringe) need a fatter relative outline to read
    const box = new THREE.Box3().setFromObject(mesh);
    const size = box.getSize(new THREE.Vector3());
    const minDim = Math.min(size.x, size.y, size.z);
    const thickness = minDim < 0.12 ? 0.14 : minDim < 0.3 ? 0.075 : 0.045;
    addOutlineSubmesh(mesh, thickness);
  });
}

export function buildArticulatedAnimeCharacter(
  def: CharacterDefinition,
  quality: GraphicsQualityPreset = 'Ultra'
): ArticulatedCharacterRig {
  const enableOutlines = quality === 'Ultra' || quality === 'High';
  const segs = quality === 'Low' ? 8 : quality === 'Medium' ? 12 : 16;

  const root = new THREE.Group();
  root.name = `Fighter_${def.id}`;
  const scale = def.appearance.heightScale || 1.0;
  root.scale.setScalar(scale);

  const primaryMat = createCelMaterial(def.appearance.primaryColor, def.appearance.primaryColor, 0.14);
  const secondaryMat = createCelMaterial(def.appearance.secondaryColor, '#000000', 0.04);
  const accentMat = createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.35);
  const skinMat = createCelMaterial(def.appearance.skinTone, def.appearance.skinTone, 0.06);
  const hairMat = createCelMaterial(def.appearance.hairColor, def.appearance.hairColor, 0.18);

  const hips = new THREE.Group();
  hips.position.set(0, 0.95, 0);
  root.add(hips);

  // --- TORSO & ANIME COAT ---
  const torso = new THREE.Group();
  hips.add(torso);

  const chestMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.28, 0.21, 0.68, segs),
    secondaryMat
  );
  chestMesh.position.set(0, 0.34, 0);
  chestMesh.castShadow = quality !== 'Low';
  if (enableOutlines) addOutlineSubmesh(chestMesh, 0.04);
  torso.add(chestMesh);

  // Anime Jacket / Armor Mantle
  const coatFlair = new THREE.Mesh(
    new THREE.ConeGeometry(0.38, 0.56, segs, 1, true),
    primaryMat
  );
  coatFlair.position.set(0, 0.05, 0);
  torso.add(coatFlair);

  // Glowing Astral Core Crest on Chest
  const chestCore = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.1, 0),
    accentMat
  );
  chestCore.position.set(0, 0.44, 0.25);
  torso.add(chestCore);

  // --- HEAD, ANIME EYES & STYLIZED HAIR ---
  const head = new THREE.Group();
  head.position.set(0, 0.82, 0);
  torso.add(head);

  const headSphere = new THREE.Mesh(
    new THREE.SphereGeometry(0.24, segs, segs),
    skinMat
  );
  headSphere.scale.set(0.95, 1.05, 0.96);
  headSphere.castShadow = quality !== 'Low';
  if (enableOutlines) addOutlineSubmesh(headSphere, 0.045);
  head.add(headSphere);

  // Glowing Anime Eyes (v1.1.0: dynamic expression rig)
  const eyeMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(def.appearance.eyeColor) });
  eyeMat.userData.baseEyeColor = new THREE.Color(def.appearance.eyeColor);
  const eyeGeo = new THREE.BoxGeometry(0.075, 0.052, 0.03);
  const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
  leftEye.position.set(-0.082, 0.02, 0.222);
  const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
  rightEye.position.set(0.082, 0.02, 0.222);
  head.add(leftEye, rightEye);

  // Angry anime eyebrow blades that tilt with combat emotion
  const browMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(def.appearance.hairColor) });
  const browGeo = new THREE.BoxGeometry(0.095, 0.016, 0.02);
  const leftBrow = new THREE.Mesh(browGeo, browMat);
  leftBrow.position.set(-0.082, 0.088, 0.238);
  leftBrow.rotation.z = 0.16;
  const rightBrow = new THREE.Mesh(browGeo, browMat);
  rightBrow.position.set(0.082, 0.088, 0.238);
  rightBrow.rotation.z = -0.16;
  head.add(leftBrow, rightBrow);

  // Distinct Hair Silhouette
  const hair = new THREE.Group();
  head.add(hair);

  const hairCap = new THREE.Mesh(
    new THREE.SphereGeometry(0.255, segs, segs, 0, Math.PI * 2, 0, Math.PI * 0.65),
    hairMat
  );
  hairCap.position.set(0, 0.03, -0.02);
  hair.add(hairCap);

  if (def.appearance.hairStyle === 'twintails') {
    for (const side of [-1, 1]) {
      const tail = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.72, 8), hairMat);
      tail.position.set(side * 0.28, -0.18, -0.1);
      tail.rotation.z = side * 0.35;
      tail.rotation.x = 0.25;
      hair.add(tail);
    }
  } else if (def.appearance.hairStyle === 'horned-mane') {
    const hornMat = createCelMaterial('#1f2937', def.appearance.accentColor, 0.4);
    for (const side of [-1, 1]) {
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.38, 8), hornMat);
      horn.position.set(side * 0.16, 0.28, 0.05);
      horn.rotation.z = -side * 0.35;
      horn.rotation.x = -0.2;
      hair.add(horn);
    }
  } else if (def.appearance.hairStyle === 'silver-ponytail' || def.appearance.hairStyle === 'ribbon-long') {
    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.9 * 0.14, 0.98, 8), hairMat);
    tail.position.set(0, -0.22, -0.24);
    tail.rotation.x = 0.35;
    hair.add(tail);
    const tie = new THREE.Mesh(new THREE.TorusGeometry(0.075, 0.02, 6, 12), createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.4));
    tie.position.set(0, 0.16, -0.2);
    tie.rotation.x = Math.PI / 2;
    hair.add(tie);
    for (const side of [-1, 1]) {
      const fringe = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.24, 6), hairMat);
      fringe.position.set(side * 0.12, 0.12, 0.17);
      fringe.rotation.x = 0.5;
      hair.add(fringe);
    }
  } else if (def.appearance.hairStyle === 'valkyrie-crest' || def.appearance.hairStyle === 'visor-crop') {
    // Swept-back crest with a bright central blade
    const crest = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.46, 0.2), hairMat);
    crest.position.set(0, 0.24, -0.02);
    crest.rotation.x = -0.32;
    hair.add(crest);
    for (const side of [-1, 1]) {
      const sweep = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.4, 6), hairMat);
      sweep.position.set(side * 0.19, 0.1, -0.06);
      sweep.rotation.z = side * 1.15;
      sweep.rotation.x = -0.2;
      hair.add(sweep);
    }
    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(0.4, 0.05, 0.04),
      createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.75)
    );
    visor.position.set(0, 0.06, 0.22);
    head.add(visor);
  } else if (def.appearance.hairStyle === 'spiky') {
    // Hero spikes: long, asymmetric, swept back off the crown
    for (let i = 0; i < 7; i++) {
      const angle = (i / 7) * Math.PI * 1.6 - Math.PI * 0.3;
      const len = 0.34 + (i % 3) * 0.11;
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.075, len, 5), hairMat);
      spike.position.set(Math.sin(angle) * 0.17, 0.2, Math.cos(angle) * 0.15 - 0.04);
      spike.rotation.x = Math.cos(angle) * 0.6 - 0.3;
      spike.rotation.z = -Math.sin(angle) * 0.62;
      hair.add(spike);
    }
    // Backward mane volume so the silhouette reads from behind
    const mane = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.4, 6), hairMat);
    mane.position.set(0, 0.06, -0.22);
    mane.rotation.x = 1.15;
    hair.add(mane);
  } else if (def.appearance.hairStyle === 'cyber-swept') {
    // Asymmetric undercut: one side shaved, the other swept across the brow
    const sweep = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.12, 0.3), hairMat);
    sweep.position.set(0.06, 0.16, 0.02);
    sweep.rotation.z = -0.34;
    sweep.rotation.y = 0.18;
    hair.add(sweep);
    for (let i = 0; i < 4; i++) {
      const strand = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.3 - i * 0.03, 5), hairMat);
      strand.position.set(-0.1 + i * 0.075, 0.19 - i * 0.02, 0.16);
      strand.rotation.z = 0.9 + i * 0.12;
      strand.rotation.x = 0.5;
      hair.add(strand);
    }
    // Shaved side: flat panel hugging the skull
    const shaved = new THREE.Mesh(new THREE.SphereGeometry(0.235, 10, 8, Math.PI, Math.PI), hairMat);
    shaved.position.set(-0.05, 0.02, 0);
    hair.add(shaved);
    const cyberLine = new THREE.Mesh(
      new THREE.BoxGeometry(0.03, 0.02, 0.26),
      createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.9)
    );
    cyberLine.position.set(-0.19, 0.13, 0.02);
    cyberLine.rotation.z = 0.4;
    hair.add(cyberLine);
  } else if (def.appearance.hairStyle === 'braided-crown') {
    // Interlocking braid ring around the crown — sits PROUD of the hair cap so
    // the braid actually reads instead of being swallowed by the skull mesh.
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      const bead = new THREE.Mesh(new THREE.SphereGeometry(0.072, 8, 6), hairMat);
      bead.position.set(
        Math.sin(a) * 0.272,
        0.16 + Math.cos(a * 3) * 0.028,
        Math.cos(a) * 0.262
      );
      bead.scale.set(1, 0.78, 1.2);
      bead.rotation.y = a;
      hair.add(bead);
    }
    // Braided topknot rising above the beads
    const knot = new THREE.Mesh(new THREE.SphereGeometry(0.115, 10, 8), hairMat);
    knot.position.set(0, 0.3, -0.03);
    knot.scale.set(1, 0.9, 1);
    hair.add(knot);
    for (let i = 0; i < 3; i++) {
      const coil = new THREE.Mesh(new THREE.TorusGeometry(0.1 + i * 0.012, 0.022, 6, 14), hairMat);
      coil.position.set(0, 0.24 + i * 0.06, -0.03);
      coil.rotation.x = Math.PI / 2;
      hair.add(coil);
    }
    // Two braids falling behind the shoulders
    for (const side of [-1, 1]) {
      const braid = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.52, 4, 8), hairMat);
      braid.position.set(side * 0.17, -0.3, -0.16);
      braid.rotation.z = side * 0.13;
      braid.rotation.x = 0.16;
      hair.add(braid);
      const tipRing = new THREE.Mesh(
        new THREE.TorusGeometry(0.052, 0.016, 6, 10),
        createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.6)
      );
      tipRing.position.set(side * 0.2, -0.57, -0.14);
      tipRing.rotation.x = Math.PI / 2;
      hair.add(tipRing);
    }
  } else if (def.appearance.hairStyle === 'headband-wild') {
    // Wild shag with a taut headband cutting across it
    for (let i = 0; i < 9; i++) {
      const angle = (i / 9) * Math.PI * 2;
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.24 + (i % 2) * 0.14, 5), hairMat);
      spike.position.set(Math.sin(angle) * 0.2, 0.1 + Math.cos(angle) * 0.06, Math.cos(angle) * 0.18);
      spike.rotation.x = Math.cos(angle) * 0.9;
      spike.rotation.z = -Math.sin(angle) * 0.9;
      hair.add(spike);
    }
    const band = new THREE.Mesh(
      new THREE.TorusGeometry(0.235, 0.032, 8, 20),
      createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.55)
    );
    band.position.set(0, 0.13, -0.01);
    band.rotation.x = Math.PI / 2 - 0.12;
    hair.add(band);
    // Trailing knot tails behind
    for (const side of [-1, 1]) {
      const tail = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.3, 0.02), createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.35));
      tail.position.set(side * 0.1, 0.1, -0.28);
      tail.rotation.x = -0.5;
      tail.rotation.z = side * 0.25;
      hair.add(tail);
    }
  } else if (def.appearance.hairStyle === 'gothic-bob') {
    // Blunt-cut bob framing the face
    const bob = new THREE.Mesh(new THREE.SphereGeometry(0.275, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.72), hairMat);
    bob.position.set(0, 0.0, -0.02);
    bob.scale.set(1, 1.02, 1.05);
    hair.add(bob);
    // Straight blunt fringe
    const fringe = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.15, 0.1), hairMat);
    fringe.position.set(0, 0.1, 0.19);
    fringe.rotation.x = -0.12;
    hair.add(fringe);
    // Twin blunt side locks
    for (const side of [-1, 1]) {
      const lock = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.36, 0.12), hairMat);
      lock.position.set(side * 0.235, -0.13, 0.04);
      lock.rotation.z = side * 0.06;
      hair.add(lock);
    }
    const ribbon = new THREE.Mesh(
      new THREE.TorusGeometry(0.06, 0.022, 6, 12),
      createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.7)
    );
    ribbon.position.set(0.19, 0.2, -0.06);
    ribbon.rotation.x = Math.PI / 2.4;
    hair.add(ribbon);
  } else if (def.appearance.hairStyle === 'alchemist-crest') {
    // Tall pointed crest with a floating sigil
    const crest = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.62, 6), hairMat);
    crest.position.set(0, 0.36, -0.04);
    crest.rotation.x = -0.16;
    hair.add(crest);
    const midCrest = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.36, 6), hairMat);
    midCrest.position.set(0, 0.24, 0.12);
    midCrest.rotation.x = -0.42;
    hair.add(midCrest);
    for (const side of [-1, 1]) {
      const sideLock = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.34, 5), hairMat);
      sideLock.position.set(side * 0.21, -0.1, 0.02);
      sideLock.rotation.z = side * 0.28;
      hair.add(sideLock);
    }
    const sigil = new THREE.Mesh(
      new THREE.TorusGeometry(0.075, 0.014, 6, 14),
      createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 1.0)
    );
    sigil.position.set(0, 0.52, -0.08);
    sigil.rotation.x = 1.1;
    hair.add(sigil);
  } else {
    // Unknown style — fall back to hero spikes rather than a bare cap
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.085, 0.32, 6), hairMat);
      spike.position.set(Math.sin(angle) * 0.18, 0.18, Math.cos(angle) * 0.16 - 0.04);
      spike.rotation.x = Math.cos(angle) * 0.55 - 0.2;
      spike.rotation.z = -Math.sin(angle) * 0.55;
      hair.add(spike);
    }
  }

  // --- DISTINCTIVE BACK ACCESSORY / WINGS / HALO / CAPE ---
  const accessory = new THREE.Group();
  accessory.position.set(0, 0.55, -0.22);
  torso.add(accessory);

  if (def.appearance.accessory === 'astral-halo' || def.appearance.accessory === 'chrono-ring') {
    const halo = new THREE.Mesh(
      new THREE.TorusGeometry(0.55, 0.035, 8, 24),
      accentMat
    );
    halo.position.set(0, 0.25, -0.15);
    accessory.add(halo);
  } else if (def.appearance.accessory === 'solar-wings') {
    for (const side of [-1, 1]) {
      for (let w = 0; w < 3; w++) {
        const wingBlade = new THREE.Mesh(
          new THREE.BoxGeometry(0.68 - w * 0.12, 0.09, 0.03),
          accentMat
        );
        wingBlade.position.set(side * (0.38 + w * 0.06), 0.18 - w * 0.16, -0.1);
        wingBlade.rotation.z = side * (0.35 - w * 0.22);
        accessory.add(wingBlade);
      }
    }
  } else if (def.appearance.accessory === 'frost-lotus') {
    // Eight-petal crystalline frost lotus hovering behind the shoulders
    for (let p = 0; p < 8; p++) {
      const a = (p / 8) * Math.PI * 2;
      const petal = new THREE.Mesh(
        new THREE.ConeGeometry(0.085, 0.52, 5),
        createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.6)
      );
      petal.position.set(Math.cos(a) * 0.34, 0.1 + Math.sin(a) * 0.34, -0.16);
      petal.rotation.z = -a + Math.PI / 2;
      accessory.add(petal);
    }
    const heart = new THREE.Mesh(new THREE.OctahedronGeometry(0.12, 0), accentMat);
    heart.position.set(0, 0.1, -0.16);
    accessory.add(heart);
  } else if (def.appearance.accessory === 'plasma-thrusters') {
    for (const side of [-1, 1]) {
      const thruster = new THREE.Mesh(
        new THREE.CylinderGeometry(0.085, 0.11, 0.44, 8),
        createCelMaterial(def.appearance.secondaryColor, def.appearance.accentColor, 0.3)
      );
      thruster.position.set(side * 0.3, -0.02, -0.16);
      thruster.rotation.x = 0.18;
      accessory.add(thruster);
      const plume = new THREE.Mesh(
        new THREE.ConeGeometry(0.085, 0.5, 8),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(def.appearance.accentColor),
          transparent: true,
          opacity: 0.72,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      );
      plume.position.set(side * 0.3, -0.34, -0.2);
      plume.rotation.x = Math.PI;
      accessory.add(plume);
      const wingBlade = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.06, 0.03), accentMat);
      wingBlade.position.set(side * 0.42, 0.16, -0.14);
      wingBlade.rotation.z = side * 0.42;
      accessory.add(wingBlade);
    }
  } else if (def.appearance.accessory === 'thunder-drums' || def.appearance.accessory === 'runic-orbs') {
    for (let d = 0; d < 5; d++) {
      const a = (d / 5) * Math.PI * 1.4 - Math.PI * 0.2;
      const orb = new THREE.Mesh(new THREE.OctahedronGeometry(0.11, 0), accentMat);
      orb.position.set(Math.cos(a) * 0.52, Math.sin(a) * 0.52 + 0.15, -0.15);
      accessory.add(orb);
    }
  } else if (def.appearance.accessory === 'cape') {
    // Full flowing cape — shoulder-anchored, flared hem, accent trim
    const capeGeo = new THREE.CylinderGeometry(0.3, 0.62, 1.02, 10, 1, true, 0, Math.PI * 1.25);
    const capeMesh = new THREE.Mesh(capeGeo, primaryMat);
    capeMesh.position.set(0, -0.38, -0.08);
    capeMesh.rotation.x = 0.16;
    capeMesh.rotation.y = Math.PI * 0.38;
    accessory.add(capeMesh);
    const collar = new THREE.Mesh(
      new THREE.TorusGeometry(0.19, 0.035, 8, 16, Math.PI * 1.3),
      createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.5)
    );
    collar.position.set(0, 0.16, -0.04);
    collar.rotation.x = Math.PI / 2;
    collar.rotation.z = Math.PI * 0.35;
    accessory.add(collar);
  } else if (def.appearance.accessory === 'tactical-cloak') {
    // Angular half-cloak over one shoulder with a tech clasp
    const cloak = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.82, 0.16), secondaryMat);
    cloak.position.set(0.12, -0.3, -0.08);
    cloak.rotation.z = -0.14;
    cloak.rotation.x = 0.1;
    accessory.add(cloak);
    const clasp = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.1, 0),
      createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 1.1)
    );
    clasp.position.set(0.2, 0.16, -0.02);
    accessory.add(clasp);
    for (let i = 0; i < 3; i++) {
      const vent = new THREE.Mesh(
        new THREE.BoxGeometry(0.3, 0.02, 0.02),
        createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.7)
      );
      vent.position.set(0.12, -0.16 - i * 0.14, 0.02);
      accessory.add(vent);
    }
  } else if (def.appearance.accessory === 'abyss-mantle') {
    // Ragged void mantle: layered tapered shards that read as tattered cloth
    for (let i = 0; i < 7; i++) {
      const t = i / 6;
      const shard = new THREE.Mesh(new THREE.ConeGeometry(0.1 + t * 0.03, 0.55 + (i % 3) * 0.2, 4), secondaryMat);
      shard.position.set((t - 0.5) * 0.66, -0.4 - (i % 2) * 0.08, -0.12 + Math.abs(t - 0.5) * 0.1);
      shard.rotation.x = Math.PI + 0.18;
      shard.rotation.z = (t - 0.5) * 0.3;
      accessory.add(shard);
    }
    const voidCore = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.12, 0),
      new THREE.MeshBasicMaterial({
        color: new THREE.Color(def.appearance.auraColor),
        transparent: true,
        opacity: 0.8,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    voidCore.position.set(0, 0.14, -0.16);
    accessory.add(voidCore);
  } else if (def.appearance.accessory === 'dragon-sash') {
    // Long sash coiled across the torso and trailing behind
    const sash = new THREE.Mesh(
      new THREE.TorusGeometry(0.3, 0.075, 8, 18, Math.PI * 1.15),
      createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.45)
    );
    sash.position.set(0, -0.06, 0);
    sash.rotation.x = Math.PI / 2;
    sash.rotation.z = Math.PI * 0.42;
    sash.scale.set(1, 1, 0.7);
    accessory.add(sash);
    for (const side of [-1, 1]) {
      const trail = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.9, 0.03), createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.35));
      trail.position.set(side * 0.2, -0.52, -0.2);
      trail.rotation.x = -0.34;
      trail.rotation.z = side * 0.24;
      accessory.add(trail);
    }
    const scale = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.09, 0),
      createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 1.2)
    );
    scale.position.set(0, 0.12, 0.06);
    scale.scale.set(1.4, 1, 0.5);
    accessory.add(scale);
  } else if (def.appearance.accessory === 'rose-chains') {
    // Thorned chain links winding down the back with a rose at the anchor
    const linkMat = createCelMaterial(def.appearance.accentColor, def.appearance.accentColor, 0.75);
    for (let i = 0; i < 8; i++) {
      const t = i / 7;
      const link = new THREE.Mesh(new THREE.TorusGeometry(0.055, 0.014, 6, 10), linkMat);
      link.position.set(Math.sin(t * Math.PI * 1.6) * 0.26, 0.14 - t * 0.8, -0.14 + Math.cos(t * 2.2) * 0.05);
      link.rotation.x = Math.PI / 2 + Math.sin(i) * 0.5;
      link.rotation.z = i * 0.6;
      accessory.add(link);
      if (i % 3 === 1) {
        const thorn = new THREE.Mesh(new THREE.ConeGeometry(0.022, 0.09, 4), linkMat);
        thorn.position.copy(link.position);
        thorn.position.x += 0.06;
        thorn.rotation.z = -0.9;
        accessory.add(thorn);
      }
    }
    const roseMat = createCelMaterial(def.appearance.primaryColor, def.appearance.accentColor, 0.6);
    for (let p = 0; p < 5; p++) {
      const petal = new THREE.Mesh(new THREE.SphereGeometry(0.075, 7, 5), roseMat);
      const a = (p / 5) * Math.PI * 2;
      petal.position.set(Math.cos(a) * 0.07, 0.2, -0.16 + Math.sin(a) * 0.07);
      petal.scale.set(1, 0.55, 1);
      accessory.add(petal);
    }
  } else {
    // Unknown accessory — plain mantle rather than nothing
    const capeGeo = new THREE.BoxGeometry(0.58, 0.95, 0.04);
    const capeMesh = new THREE.Mesh(capeGeo, primaryMat);
    capeMesh.position.set(0, -0.35, -0.06);
    capeMesh.rotation.x = 0.18;
    accessory.add(capeMesh);
  }

  // --- ARMS & WEAPONS ---
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.34, 0.58, 0);
  torso.add(leftArm);

  const leftArmMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.075, 0.065, 0.56, 8),
    primaryMat
  );
  leftArmMesh.position.set(0, -0.24, 0);
  leftArm.add(leftArmMesh);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.34, 0.58, 0);
  torso.add(rightArm);

  const rightArmMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.075, 0.065, 0.56, 8),
    primaryMat
  );
  rightArmMesh.position.set(0, -0.24, 0);
  rightArm.add(rightArmMesh);

  // Weapon Group attached to Right Hand
  const weapon = new THREE.Group();
  weapon.position.set(0, -0.5, 0.12);
  rightArm.add(weapon);

  buildWeaponMesh(weapon, def.appearance.weapon, accentMat, secondaryMat);

  // Off-hand weapon for dual-wield archetypes
  let offhandWeapon: THREE.Group | undefined;
  if (def.appearance.weapon === 'dual-katanas' || def.appearance.weapon === 'daggers') {
    offhandWeapon = new THREE.Group();
    offhandWeapon.position.set(0, -0.5, 0.12);
    offhandWeapon.rotation.x = Math.PI * 0.38;
    leftArm.add(offhandWeapon);
    buildWeaponMesh(offhandWeapon, def.appearance.weapon, accentMat, secondaryMat);
  }

  // --- LEGS ---
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.14, 0, 0);
  hips.add(leftLeg);

  const leftLegMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.095, 0.075, 0.88, 8),
    secondaryMat
  );
  leftLegMesh.position.set(0, -0.44, 0);
  leftLeg.add(leftLegMesh);

  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.14, 0, 0);
  hips.add(rightLeg);

  const rightLegMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.095, 0.075, 0.88, 8),
    secondaryMat
  );
  rightLegMesh.position.set(0, -0.44, 0);
  rightLeg.add(rightLegMesh);

  // --- GROUND SELECTION / FACTION RING & AWAKENING AURA ---
  const auraRing = new THREE.Mesh(
    new THREE.RingGeometry(0.68, 0.86, 24),
    new THREE.MeshBasicMaterial({
      color: new THREE.Color(def.appearance.primaryColor),
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.75,
    })
  );
  auraRing.rotation.x = -Math.PI / 2;
  auraRing.position.set(0, 0.04, 0);
  root.add(auraRing);

  const awakeningCorona = new THREE.Mesh(
    new THREE.CylinderGeometry(0.65, 0.85, 2.2, 16, 1, true),
    new THREE.MeshBasicMaterial({
      color: new THREE.Color(def.appearance.auraColor),
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  awakeningCorona.position.set(0, 1.1, 0);
  awakeningCorona.visible = false;
  root.add(awakeningCorona);

  const guardDome = new THREE.Mesh(
    new THREE.SphereGeometry(1.15, 16, 12),
    new THREE.MeshBasicMaterial({
      color: new THREE.Color(def.appearance.accentColor),
      wireframe: true,
      transparent: true,
      opacity: 0.55,
    })
  );
  guardDome.position.set(0, 1.05, 0);
  guardDome.visible = false;
  root.add(guardDome);

  // --- v1.1.0 3D WEAPON SLASH RIBBONS ---
  const slashRibbonGroup = new THREE.Group();
  slashRibbonGroup.position.set(0, 1.05, 0);
  slashRibbonGroup.visible = false;
  root.add(slashRibbonGroup);

  const slashRibbonMeshes: THREE.Mesh[] = [];
  for (let i = 0; i < 3; i++) {
    const ribbonMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(i === 1 ? def.appearance.accentColor : def.appearance.primaryColor),
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const ribbon = new THREE.Mesh(
      new THREE.RingGeometry(0.55 + i * 0.22, 0.95 + i * 0.3, 24, 1, 0, Math.PI * 0.95),
      ribbonMat
    );
    ribbon.rotation.x = -Math.PI / 2 + 0.35;
    ribbon.userData.phase = i * 0.35;
    slashRibbonGroup.add(ribbon);
    slashRibbonMeshes.push(ribbon);
  }

  // --- v1.1.0 DASH / AWAKENING AFTERIMAGE GHOSTS ---
  const afterimageGroup = new THREE.Group();
  root.add(afterimageGroup);
  const ghostMaterial = new THREE.MeshBasicMaterial({
    color: new THREE.Color(def.appearance.auraColor),
    transparent: true,
    opacity: 0,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const ghostMeshes: THREE.Mesh[] = [];
  for (let i = 0; i < 4; i++) {
    const ghost = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 1.15, 4, 8), ghostMaterial);
    ghost.position.set(0, 0.95, 0);
    ghost.visible = false;
    afterimageGroup.add(ghost);
    ghostMeshes.push(ghost);
  }

  // v1.2.0 — ink the full silhouette before handing the rig back
  if (enableOutlines) {
    inkOutlineSilhouette(torso);
    inkOutlineSilhouette(hair);
    inkOutlineSilhouette(accessory);
    inkOutlineSilhouette(leftArm);
    inkOutlineSilhouette(rightArm);
    inkOutlineSilhouette(leftLeg);
    inkOutlineSilhouette(rightLeg);
  }

  return {
    characterId: def.id,
    root,
    hips,
    torso,
    head,
    hair,
    accessory,
    leftArm,
    rightArm,
    weapon,
    leftLeg,
    rightLeg,
    auraRing,
    awakeningCorona,
    guardDome,
    eyes: { left: leftEye, right: rightEye, leftBrow, rightBrow, material: eyeMat },
    slashRibbons: { group: slashRibbonGroup, meshes: slashRibbonMeshes },
    afterimages: { group: afterimageGroup, ghosts: ghostMeshes, material: ghostMaterial },
    offhandWeapon,
    previousPosition: new THREE.Vector3(),
    facingAngle: 0,
  };
}

function buildWeaponMesh(
  weaponGroup: THREE.Group,
  weaponType: CharacterDefinition['appearance']['weapon'],
  accentMat: THREE.Material,
  darkMat: THREE.Material
): void {
  if (weaponType === 'odachi') {
    const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.35, 8), darkMat);
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.03, 1.45, 0.08), accentMat);
    blade.position.set(0, 0.85, 0);
    weaponGroup.add(hilt, blade);
    weaponGroup.rotation.x = Math.PI * 0.38;
  } else if (weaponType === 'scythe') {
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.85, 8), darkMat);
    shaft.position.set(0, 0.45, 0);
    const crescent = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.95, 6), accentMat);
    crescent.position.set(0, 1.35, 0.38);
    crescent.rotation.x = Math.PI * 0.55;
    weaponGroup.add(shaft, crescent);
    weaponGroup.rotation.x = Math.PI * 0.25;
  } else if (weaponType === 'halberd') {
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 1.75, 8), darkMat);
    shaft.position.set(0, 0.45, 0);
    const spearTip = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.55, 6), accentMat);
    spearTip.position.set(0, 1.45, 0);
    weaponGroup.add(shaft, spearTip);
    weaponGroup.rotation.x = Math.PI * 0.3;
  } else if (weaponType === 'greatbow') {
    const bowArc = new THREE.Mesh(
      new THREE.TorusGeometry(0.55, 0.035, 8, 18, Math.PI),
      accentMat
    );
    bowArc.rotation.z = -Math.PI / 2;
    weaponGroup.add(bowArc);
  } else if (weaponType === 'grimoire') {
    const book = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.42, 0.08), accentMat);
    book.position.set(0.15, 0.35, 0.35);
    weaponGroup.add(book);
  } else if (weaponType === 'dual-katanas') {
    const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.3, 8), darkMat);
    const guard = new THREE.Mesh(new THREE.TorusGeometry(0.085, 0.018, 6, 12), darkMat);
    guard.rotation.x = Math.PI / 2;
    guard.position.y = 0.14;
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.035, 1.15, 0.055), accentMat);
    blade.position.set(0, 0.72, 0);
    weaponGroup.add(hilt, guard, blade);
    weaponGroup.rotation.x = Math.PI * 0.36;
  } else if (weaponType === 'lance-cannon') {
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.075, 1.5, 10), darkMat);
    shaft.position.set(0, 0.5, 0);
    const lanceTip = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.62, 8), accentMat);
    lanceTip.position.set(0, 1.52, 0);
    for (let v = 0; v < 3; v++) {
      const vent = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.02, 6, 14), accentMat);
      vent.rotation.x = Math.PI / 2;
      vent.position.set(0, 0.55 + v * 0.32, 0);
      weaponGroup.add(vent);
    }
    const muzzle = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.09, 0.22, 10), accentMat);
    muzzle.position.set(0, 1.08, 0.1);
    muzzle.rotation.x = Math.PI / 2.4;
    weaponGroup.add(shaft, lanceTip, muzzle);
    weaponGroup.rotation.x = Math.PI * 0.2;
  } else if (weaponType === 'chakram') {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.04, 8, 20), accentMat);
    weaponGroup.add(ring);
  } else if (weaponType === 'tonfa') {
    // Paired side-handle batons: shaft plus perpendicular grip
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.72, 8), darkMat);
    shaft.position.set(0, 0.3, 0);
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.2, 8), accentMat);
    grip.position.set(0, 0.06, 0.09);
    grip.rotation.x = Math.PI / 2;
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.06, 8), accentMat);
    cap.position.set(0, 0.66, 0);
    weaponGroup.add(shaft, grip, cap);
    weaponGroup.rotation.x = Math.PI * 0.12;
  } else if (weaponType === 'greaves') {
    // Leg armour: layered plates wrapping the shin, with a striking edge
    for (const side of [-1, 1]) {
      const plate = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.42, 0.18), accentMat);
      plate.position.set(side * 0.1, -0.28, 0.02);
      plate.rotation.z = side * 0.1;
      weaponGroup.add(plate);
      const edge = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.07, 0.21), darkMat);
      edge.position.set(side * 0.1, -0.06, 0.02);
      weaponGroup.add(edge);
      const spur = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.2, 5), accentMat);
      spur.position.set(side * 0.1, -0.52, 0.06);
      spur.rotation.x = Math.PI;
      weaponGroup.add(spur);
    }
  } else if (weaponType === 'gauntlets') {
    // Heavy fist gauntlets with knuckle spikes
    for (const side of [-1, 1]) {
      const fist = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.24, 0.22), accentMat);
      fist.position.set(side * 0.12, -0.1, 0.08);
      weaponGroup.add(fist);
      const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 0.14, 8), darkMat);
      cuff.position.set(side * 0.12, 0.06, 0.04);
      weaponGroup.add(cuff);
      for (let k = 0; k < 3; k++) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.028, 0.11, 4), accentMat);
        spike.position.set(side * 0.12 + (k - 1) * 0.06, -0.06, 0.2);
        spike.rotation.x = Math.PI / 2;
        weaponGroup.add(spike);
      }
    }
  } else if (weaponType === 'daggers') {
    // Twin short blades held in reverse grip
    const blade = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.42, 4), accentMat);
    blade.position.set(0, 0.42, 0);
    const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.18, 6), darkMat);
    hilt.position.set(0, 0.14, 0);
    const pommel = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 5), accentMat);
    pommel.position.set(0, 0.03, 0);
    weaponGroup.add(blade, hilt, pommel);
    weaponGroup.rotation.x = Math.PI * 0.42;
    weaponGroup.rotation.z = 0.3;
  } else {
    // Unknown weapon — a simple short blade
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.65, 0.14), accentMat);
    blade.position.set(0, 0.2, 0.1);
    weaponGroup.add(blade);
    weaponGroup.rotation.x = Math.PI * 0.4;
  }
}

/**
 * Procedural Skeletal Animation Driver for all 13 FighterAnimationStates.
 */
/**
 * v1.1.0 — Dynamic anime facial expression states.
 * Eyes narrow into a killing glare during ultimates, blow wide on awakening,
 * and the brows tilt per animation state for readable emotion at arena scale.
 */
export function updateAnimeExpression(
  rig: ArticulatedCharacterRig,
  animState: FighterAnimationState,
  isAwakened: boolean,
  elapsedSec: number
): void {
  const { eyes } = rig;
  let eyeScaleX = 1;
  let eyeScaleY = 1;
  let browTilt = 0.16;
  let browLift = 0;
  let glow = 1;

  switch (animState) {
    case 'ultimate':
      eyeScaleX = 1.28;
      eyeScaleY = 0.55; // Fierce narrowed glare
      browTilt = 0.62;
      browLift = -0.012;
      glow = 1.85 + Math.sin(elapsedSec * 22) * 0.2;
      break;
    case 'awakening':
      eyeScaleX = 1.42;
      eyeScaleY = 1.5; // Wide open shock of ascension
      browTilt = 0.02;
      browLift = 0.028;
      glow = 2.3;
      break;
    case 'basicCombo':
    case 'heavyAttack':
    case 'signatureSkill':
      eyeScaleX = 1.12;
      eyeScaleY = 0.72;
      browTilt = 0.5;
      glow = 1.35;
      break;
    case 'hit':
      eyeScaleX = 0.82;
      eyeScaleY = 0.7;
      browTilt = -0.18;
      browLift = 0.014;
      glow = 0.85;
      break;
    case 'defend':
    case 'counter':
      eyeScaleX = 1.05;
      eyeScaleY = 0.66;
      browTilt = 0.4;
      glow = 1.25;
      break;
    case 'move':
    case 'movementSkill':
      eyeScaleX = 1.08;
      eyeScaleY = 0.86;
      browTilt = 0.3;
      glow = 1.15;
      break;
    case 'victory':
      eyeScaleX = 1.1;
      eyeScaleY = 1.05;
      browTilt = 0.08;
      browLift = 0.01;
      glow = 1.5;
      break;
    case 'eliminated':
      eyeScaleX = 1;
      eyeScaleY = 0.08; // Eyes closed in astral dissolution
      browTilt = -0.05;
      glow = 0.3;
      break;
    default:
      break;
  }

  if (isAwakened && animState !== 'eliminated') glow *= 1.35;

  eyes.left.scale.set(eyeScaleX, eyeScaleY, 1);
  eyes.right.scale.set(eyeScaleX, eyeScaleY, 1);
  eyes.leftBrow.rotation.z = browTilt;
  eyes.rightBrow.rotation.z = -browTilt;
  eyes.leftBrow.position.y = 0.088 + browLift;
  eyes.rightBrow.position.y = 0.088 + browLift;
  const baseColor = (eyes.material.userData.baseEyeColor as THREE.Color | undefined) ??
    new THREE.Color('#f8fafc');
  eyes.material.color.copy(baseColor).multiplyScalar(Math.min(1.9, glow));
}

/**
 * v1.1.0 — 3D weapon slash ribbons.
 * Draws expanding additive crescent trails locked to the weapon swing.
 */
export function updateSlashRibbons(
  rig: ArticulatedCharacterRig,
  animState: FighterAnimationState,
  elapsedSec: number
): void {
  const group = rig.slashRibbons.group;
  const active =
    animState === 'basicCombo' ||
    animState === 'heavyAttack' ||
    animState === 'signatureSkill' ||
    animState === 'ultimate' ||
    animState === 'counter';

  if (!active) {
    group.visible = false;
    return;
  }

  group.visible = true;
  const intensity = animState === 'ultimate' ? 1 : animState === 'signatureSkill' ? 0.85 : 0.6;
  const travel = animState === 'ultimate' ? 2.35 : animState === 'signatureSkill' ? 1.75 : 1.25;

  rig.slashRibbons.meshes.forEach((ribbon, idx) => {
    const mat = ribbon.material as THREE.MeshBasicMaterial;
    const localPhase = (elapsedSec * (animState === 'ultimate' ? 11 : 8.5) + ribbon.userData.phase) % 1;
    const fade = Math.sin(localPhase * Math.PI);
    mat.opacity = fade * intensity * (1 - idx * 0.2);
    const scale = 0.62 + localPhase * travel;
    ribbon.scale.set(scale, scale, scale);
    ribbon.rotation.z = -2.4 + localPhase * 5.2;
    ribbon.position.y = 0.05 + idx * 0.1;
  });
}

/**
 * v1.1.0 — Dash & Awakening afterimage ghosts.
 * Trails translucent silhouettes behind high-velocity movement and ascension bursts.
 */
export function updateAfterimages(
  rig: ArticulatedCharacterRig,
  animState: FighterAnimationState,
  isAwakened: boolean,
  elapsedSec: number,
  deltaPosXZ: number
): void {
  const { ghosts, material } = rig.afterimages;
  const dashing = animState === 'movementSkill' || (animState === 'move' && deltaPosXZ > 0.24);
  const ascending = animState === 'awakening';
  const ulting = animState === 'ultimate';

  if (!dashing && !ascending && !ulting) {
    material.opacity = Math.max(0, material.opacity - 0.08);
    if (material.opacity <= 0.001) ghosts.forEach((g) => (g.visible = false));
    return;
  }

  const baseOpacity = ascending ? 0.82 : ulting ? 0.4 : 0.55;
  material.opacity = baseOpacity * (isAwakened ? 1.2 : 1);
  if (material.opacity > 1) material.opacity = 1;

  ghosts.forEach((ghost, idx) => {
    ghost.visible = true;
    const stretched = ascending ? 1 + idx * 0.35 : 1 + idx * 0.05;
    ghost.scale.set(1 - idx * 0.12, stretched, 1 - idx * 0.12);
    const offset = (idx + 1) * (dashing ? 0.85 : 0.22);
    ghost.position.set(0, 0.95 + (ascending ? idx * 0.32 : 0), -offset);
  });

  rig.afterimages.group.rotation.y = Math.sin(elapsedSec * 3) * 0.05;
}

export function updateCharacterAnimation(
  rig: ArticulatedCharacterRig,
  animState: FighterAnimationState,
  elapsedSec: number,
  isAwakened: boolean,
  isGuarding: boolean
): void {
  const phase = elapsedSec * 7.5 + rig.characterId.charCodeAt(5);

  rig.awakeningCorona.visible = isAwakened && animState !== 'eliminated';
  if (rig.awakeningCorona.visible) {
    rig.awakeningCorona.rotation.y = elapsedSec * 3.2;
    const pulse = 1 + Math.sin(elapsedSec * 9) * 0.08;
    rig.awakeningCorona.scale.set(pulse, 1, pulse);
  }

  rig.guardDome.visible = isGuarding && animState !== 'eliminated';
  if (rig.guardDome.visible) {
    rig.guardDome.rotation.y = -elapsedSec * 2.5;
  }

  if (animState === 'eliminated') {
    // Non-graphic fallen kneel/dissolution pose
    rig.hips.position.y = 0.32;
    rig.torso.rotation.x = 0.55;
    rig.leftArm.rotation.x = 0.4;
    rig.rightArm.rotation.x = 0.4;
    rig.leftLeg.rotation.x = -1.2;
    rig.rightLeg.rotation.x = -1.1;
    rig.auraRing.visible = false;
    return;
  }

  rig.auraRing.visible = true;
  rig.accessory.rotation.x = 0.15 + Math.sin(phase * 0.8) * 0.12;

  switch (animState) {
    case 'move': {
      rig.hips.position.y = 0.93 + Math.abs(Math.sin(phase * 1.4)) * 0.08;
      rig.torso.rotation.x = 0.22; // Anime sprint lean
      rig.torso.rotation.y = Math.sin(phase * 1.4) * 0.12;
      rig.leftLeg.rotation.x = Math.sin(phase * 1.4) * 0.75;
      rig.rightLeg.rotation.x = -Math.sin(phase * 1.4) * 0.75;
      rig.leftArm.rotation.x = -Math.sin(phase * 1.4) * 0.65;
      rig.rightArm.rotation.x = Math.sin(phase * 1.4) * 0.55 - 0.3;
      break;
    }
    case 'basicCombo': {
      rig.hips.position.y = 0.9;
      rig.torso.rotation.x = 0.18;
      rig.torso.rotation.y = Math.sin(elapsedSec * 28) * 0.65;
      rig.rightArm.rotation.x = -1.4 + Math.cos(elapsedSec * 28) * 0.95;
      rig.rightArm.rotation.z = -0.35;
      rig.leftArm.rotation.x = -0.5;
      break;
    }
    case 'heavyAttack':
    case 'signatureSkill': {
      rig.hips.position.y = 1.05;
      rig.torso.rotation.x = -0.15;
      rig.torso.rotation.y = Math.sin(elapsedSec * 18) * 0.85;
      rig.rightArm.rotation.x = -2.1 + Math.sin(elapsedSec * 20) * 1.2;
      rig.leftArm.rotation.x = -1.2;
      break;
    }
    case 'ultimate': {
      // Dramatic aerial ascension pose during Ultimate
      rig.hips.position.y = 2.15 + Math.sin(elapsedSec * 12) * 0.25;
      rig.torso.rotation.x = -0.25;
      rig.torso.rotation.y = elapsedSec * 6.0;
      rig.leftArm.rotation.z = -0.85;
      rig.rightArm.rotation.z = 0.85;
      rig.rightArm.rotation.x = -1.8;
      break;
    }
    case 'awakening': {
      rig.hips.position.y = 1.45;
      rig.torso.rotation.x = -0.35;
      rig.leftArm.rotation.z = -1.1;
      rig.rightArm.rotation.z = 1.1;
      break;
    }
    case 'movementSkill': {
      rig.hips.position.y = 1.15;
      rig.torso.rotation.x = 0.48;
      rig.leftLeg.rotation.x = -0.6;
      rig.rightLeg.rotation.x = 0.5;
      break;
    }
    case 'defend':
    case 'counter': {
      rig.hips.position.y = 0.86;
      rig.torso.rotation.x = 0.1;
      rig.rightArm.rotation.x = -1.35;
      rig.rightArm.rotation.z = 0.55;
      rig.leftArm.rotation.x = -1.2;
      break;
    }
    case 'hit': {
      rig.hips.position.y = 0.92;
      rig.torso.rotation.x = -0.32;
      rig.leftArm.rotation.x = 0.35;
      rig.rightArm.rotation.x = 0.35;
      break;
    }
    case 'victory': {
      rig.hips.position.y = 0.98 + Math.sin(phase * 0.6) * 0.04;
      rig.torso.rotation.x = -0.12;
      rig.torso.rotation.y = Math.sin(phase * 0.4) * 0.2;
      rig.rightArm.rotation.x = -2.45; // Raised weapon triumphantly
      rig.leftArm.rotation.z = -0.35;
      break;
    }
    case 'idle':
    default: {
      rig.hips.position.y = 0.95 + Math.sin(phase * 0.5) * 0.03;
      rig.torso.rotation.x = 0.04;
      rig.torso.rotation.y = Math.sin(phase * 0.35) * 0.08;
      rig.leftArm.rotation.x = Math.sin(phase * 0.5) * 0.12;
      rig.rightArm.rotation.x = -0.25 + Math.cos(phase * 0.5) * 0.12;
      rig.leftLeg.rotation.x = 0;
      rig.rightLeg.rotation.x = 0;
      break;
    }
  }
}
