import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import {
  ArenaDefinition,
  BattleSimulationState,
  CameraMode,
  CharacterDefinition,
  GraphicsQualityPreset,
  PerformanceTelemetry,
} from '../types/game';
import {
  ArticulatedCharacterRig,
  buildArticulatedAnimeCharacter,
  updateAfterimages,
  updateAnimeExpression,
  updateCharacterAnimation,
  updateSlashRibbons,
} from './animeCharacterMesh';

/**
 * Exponential-smoothing alpha that produces identical camera response regardless
 * of frame rate. `tau` is the time constant in seconds (old per-frame factors of
 * 0.065 @ 60 fps == tau 0.257 s).
 */
function cameraAlpha(dtSec: number, tauSec: number): number {
  return Math.min(1, 1 - Math.exp(-dtSec / tauSec));
}

export class ArenaSceneRenderer {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private ambientLight: THREE.AmbientLight;
  private dirLight: THREE.DirectionalLight;
  private rimLight: THREE.PointLight;

  private arenaGroup: THREE.Group;
  private skyRingGroup: THREE.Group;
  private weatherPoints: THREE.Points | null = null;
  private fighterRigs = new Map<string, ArticulatedCharacterRig>();
  private destructibleMeshes = new Map<string, { intact: THREE.Group; rubble: THREE.Mesh }>();
  private zoneGroup: THREE.Group;
  private vfxGroup: THREE.Group;
  private allianceLinesGroup: THREE.Group;
  private clashGroup: THREE.Group;
  private cataclysmGroup: THREE.Group;

  private composer: EffectComposer | null = null;
  private sceneDrawCalls = 0;
  private sceneTriangles = 0;
  private bloomPass: UnrealBloomPass | null = null;
  private bloomStrength = 0;

  private currentQuality: GraphicsQualityPreset = 'Ultra';
  private arenaPlayableRadius = 38;
  private cameraMode: CameraMode = 'director';
  private followFighterId: string | null = null;
  private camCurrentPos = new THREE.Vector3(0, 26, 44);
  private camCurrentLookAt = new THREE.Vector3(0, 1.5, 0);
  private directorOrbitAngle = 0;
  private lastFrameDtSec = 1 / 60;
  private criticalFastLerp = false;

  // v1.1.0 — Slow-motion final blow (bullet-time) camera
  private finalBlowFighterId: string | null = null;
  private finalBlowVictimId: string | null = null;
  private finalBlowStartedAtSec = -1;
  public isBulletTimeActive = false;
  public bulletTimeProgress = 0;

  // Real-time measured telemetry
  private frameCount = 0;
  private lastFpsUpdate = performance.now();
  private lastFrameTimestamp = performance.now();
  public telemetry: PerformanceTelemetry = {
    fps: 60,
    frameTimeMs: 16.6,
    drawCalls: 0,
    triangles: 0,
    geometriesInMemory: 0,
    texturesInMemory: 0,
    jsHeapMb: null,
  };

  constructor(container: HTMLElement, quality: GraphicsQualityPreset = 'Ultra') {
    this.container = container;
    this.currentQuality = quality;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#090d1e');
    this.scene.fog = new THREE.FogExp2('#090d1e', 0.0085);

    const width = Math.max(1, container.clientWidth);
    const height = Math.max(1, container.clientHeight);
    this.camera = new THREE.PerspectiveCamera(48, width / height, 0.5, 260);
    this.camera.position.copy(this.camCurrentPos);
    this.camera.lookAt(this.camCurrentLookAt);

    this.renderer = new THREE.WebGLRenderer({
      antialias: quality === 'Ultra' || quality === 'High',
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(width, height);
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;

    this.ambientLight = new THREE.AmbientLight('#93c5fd', 0.95);
    this.scene.add(this.ambientLight);

    this.dirLight = new THREE.DirectionalLight('#fef08a', 1.45);
    this.dirLight.position.set(28, 48, 24);
    this.dirLight.castShadow = quality !== 'Low';
    this.dirLight.shadow.camera.left = -46;
    this.dirLight.shadow.camera.right = 46;
    this.dirLight.shadow.camera.top = 46;
    this.dirLight.shadow.camera.bottom = -46;
    this.dirLight.shadow.camera.near = 1;
    this.dirLight.shadow.camera.far = 130;
    this.scene.add(this.dirLight);

    this.rimLight = new THREE.PointLight('#38bdf8', 2.4, 65);
    this.rimLight.position.set(0, 8, 0);
    this.scene.add(this.rimLight);

    this.arenaGroup = new THREE.Group();
    this.skyRingGroup = new THREE.Group();
    this.zoneGroup = new THREE.Group();
    this.vfxGroup = new THREE.Group();
    this.allianceLinesGroup = new THREE.Group();
    this.clashGroup = new THREE.Group();
    this.cataclysmGroup = new THREE.Group();

    this.scene.add(
      this.arenaGroup,
      this.skyRingGroup,
      this.zoneGroup,
      this.vfxGroup,
      this.allianceLinesGroup,
      this.clashGroup,
      this.cataclysmGroup
    );

    this.applyQualityPreset(quality);
    this.buildPostProcessing();
    container.innerHTML = '';
    container.appendChild(this.renderer.domElement);
  }

  public applyQualityPreset(preset: GraphicsQualityPreset): void {
    this.currentQuality = preset;
    const dpr = typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1;

    if (preset === 'Ultra') {
      this.renderer.setPixelRatio(Math.min(dpr, 2.0));
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      this.dirLight.castShadow = true;
      this.dirLight.shadow.mapSize.set(2048, 2048);
    } else if (preset === 'High') {
      this.renderer.setPixelRatio(Math.min(dpr, 1.5));
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      this.dirLight.castShadow = true;
      this.dirLight.shadow.mapSize.set(1024, 1024);
    } else if (preset === 'Medium') {
      this.renderer.setPixelRatio(1.0);
      this.renderer.shadowMap.enabled = true;
      this.dirLight.castShadow = true;
      this.dirLight.shadow.mapSize.set(512, 512);
    } else {
      this.renderer.setPixelRatio(0.85);
      this.renderer.shadowMap.enabled = false;
      this.dirLight.castShadow = false;
    }
    this.dirLight.shadow.map?.dispose();
    this.dirLight.shadow.map = null;
  }

  public setCameraMode(mode: CameraMode, followFighterId: string | null = null): void {
    this.cameraMode = mode;
    this.followFighterId = followFighterId;
  }

  /**
   * v1.2.0 — Anime bloom post-processing.
   *
   * Every VFX in the game (slash ribbons, clash bursts, ultimate inlays,
   * awakening afterimages, eye glow) is additive/emissive, but without a
   * bloom pass they render flat. UnrealBloomPass ships with three.js, so this
   * costs no new dependency. Low quality skips it entirely.
   */
  private buildPostProcessing(): void {
    if (this.currentQuality === 'Low') {
      this.composer = null;
      this.bloomPass = null;
      return;
    }
    const width = Math.max(1, this.container.clientWidth);
    const height = Math.max(1, this.container.clientHeight);

    const composer = new EffectComposer(this.renderer);
    composer.setSize(width, height);

    // Sample the scene pass's own stats. Every later post pass resets
    // renderer.info, so reading it after composer.render() reports the final
    // fullscreen quad instead of the scene.
    const renderPass = new RenderPass(this.scene, this.camera);
    const sceneRender = renderPass.render.bind(renderPass);
    renderPass.render = ((...args: Parameters<typeof sceneRender>) => {
      this.renderer.info.reset();
      sceneRender(...args);
      this.sceneDrawCalls = this.renderer.info.render.calls;
      this.sceneTriangles = this.renderer.info.render.triangles;
    }) as typeof renderPass.render;
    composer.addPass(renderPass);

    const bloom = new UnrealBloomPass(
      new THREE.Vector2(width, height),
      this.bloomStrengthFor(this.currentQuality), // strength
      0.4, // radius — tight halo, not a screen-wide haze
      0.88 // threshold — only true VFX highlights bloom, not lit floor
    );
    composer.addPass(bloom);

    // OutputPass applies tone mapping + colour space at the end of the chain,
    // which the renderer would otherwise do per-material.
    composer.addPass(new OutputPass());

    this.composer = composer;
    this.bloomPass = bloom;
  }

  private bloomStrengthFor(quality: GraphicsQualityPreset): number {
    switch (quality) {
      case 'Ultra': return 0.62;
      case 'High': return 0.48;
      case 'Medium': return 0.3;
      default: return 0;
    }
  }

  /** Bloom swells during ultimates, clashes and the final blow. */
  private updateBloomIntensity(state: BattleSimulationState): void {
    if (!this.bloomPass) return;
    const base = this.bloomStrengthFor(this.currentQuality);

    let surge = 0;
    if (this.isBulletTimeActive) surge += 0.3;
    for (const f of state.fighters) {
      if (!f.isAlive) continue;
      if (f.animationState === 'ultimate') surge += 0.22;
      else if (f.animationState === 'awakening') surge += 0.16;
    }
    if (state.clashLocks && state.clashLocks.some((c) => !c.resolved && c.remainingSec > 0)) surge += 0.18;

    const target = Math.min(1.15, base + surge);
    this.bloomStrength += (target - this.bloomStrength) * cameraAlpha(this.lastFrameDtSec, 0.22);
    this.bloomPass.strength = this.bloomStrength;
  }

  public handleResize(): void {
    if (!this.container) return;
    const width = Math.max(1, this.container.clientWidth);
    const height = Math.max(1, this.container.clientHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    if (this.composer) {
      this.composer.setSize(width, height);
      this.bloomPass?.setSize(width, height);
    }
  }

  /**
   * v1.1.1 — Procedural arena floor texture.
   * A dark stone weave with glowing tactical hexes, so the ground reads as a
   * built colosseum floor instead of a black void at any camera distance.
   */
  private buildArenaFloorTexture(accentHex: string, rimHex: string): THREE.Texture {
    const size = 512;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) return new THREE.Texture();

    ctx.fillStyle = '#12182b';
    ctx.fillRect(0, 0, size, size);

    // Stone tile weave
    const tile = size / 8;
    for (let y = 0; y < 8; y++) {
      for (let x = 0; x < 8; x++) {
        const shade = 14 + ((x * 7 + y * 13) % 5) * 5;
        ctx.fillStyle = `rgb(${shade + 12},${shade + 18},${shade + 32})`;
        ctx.fillRect(x * tile + 1, y * tile + 1, tile - 2, tile - 2);
      }
    }

    // Glowing tactical hexes on a sparse lattice
    ctx.strokeStyle = accentHex;
    ctx.globalAlpha = 0.5;
    ctx.lineWidth = 1.6;
    for (let i = 0; i < 10; i++) {
      const cx = ((i * 137) % size);
      const cy = ((i * 211) % size);
      const r = 8 + (i % 3) * 4;
      ctx.beginPath();
      for (let k = 0; k < 6; k++) {
        const a = (k / 6) * Math.PI * 2;
        const px = cx + Math.cos(a) * r;
        const py = cy + Math.sin(a) * r;
        if (k === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();
    }

    // Faint radial veins in the rim colour
    ctx.globalAlpha = 0.16;
    ctx.strokeStyle = rimHex;
    ctx.lineWidth = 2.4;
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(size / 2, size / 2);
      ctx.lineTo(size / 2 + Math.cos(a) * size * 0.6, size / 2 + Math.sin(a) * size * 0.6);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(5, 5);
    tex.anisotropy = 4;
    return tex;
  }

  public loadBattleScene(
    arena: ArenaDefinition,
    fighters: CharacterDefinition[]
  ): void {
    this.clearBattleObjects();

    this.arenaPlayableRadius = arena.playableRadius;

    // Reset the bullet-time finisher state for the new match
    this.finalBlowFighterId = null;
    this.finalBlowVictimId = null;
    this.finalBlowStartedAtSec = -1;
    this.isBulletTimeActive = false;
    this.bulletTimeProgress = 0;

    const segs = this.currentQuality === 'Low' ? 24 : 48;

    // 1. Main Playable Arena Floor Platform (v1.1.1: textured, lit, readable)
    const floorGeo = new THREE.CylinderGeometry(
      arena.playableRadius,
      arena.playableRadius * 1.06,
      2.4,
      segs
    );
    const floorTex = this.buildArenaFloorTexture(arena.gridAccentColor, arena.rimGlowColor);
    const floorMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(arena.floorColor).multiplyScalar(1.45),
      map: floorTex,
      roughness: 0.72,
      metalness: 0.12,
      emissive: new THREE.Color(arena.gridAccentColor),
      emissiveIntensity: 0.05,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.position.set(0, -1.2, 0);
    floorMesh.receiveShadow = this.currentQuality !== 'Low';
    this.arenaGroup.add(floorMesh);

    // 2. Concentric Runic / Tactical Rings on Floor
    for (const r of [8, 18, 28, arena.playableRadius - 0.4]) {
      const ringGeo = new THREE.RingGeometry(r - 0.18, r, segs);
      const ringMat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(r > 30 ? arena.rimGlowColor : arena.gridAccentColor),
        side: THREE.DoubleSide,
        transparent: true,
        opacity: r > 30 ? 0.75 : 0.42,
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(0, 0.02, 0);
      this.arenaGroup.add(ring);
    }

    // 3. Central Sanctum Altar Pedestal
    const altarBase = new THREE.Mesh(
      new THREE.CylinderGeometry(2.1, 2.7, 0.22, 24),
      new THREE.MeshStandardMaterial({
        color: new THREE.Color(arena.gridAccentColor),
        emissive: new THREE.Color(arena.gridAccentColor),
        emissiveIntensity: 0.25,
        roughness: 0.4,
      })
    );
    altarBase.position.set(0, 0.16, 0);
    this.arenaGroup.add(altarBase);

    // 4. Outer Scenic Colosseum Arches / Monoliths (outside playable radius)
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2;
      const dist = arena.playableRadius + 4.5;
      const x = Math.cos(angle) * dist;
      const z = Math.sin(angle) * dist;

      const spire = new THREE.Mesh(
        new THREE.BoxGeometry(1.8, 11.5, 1.8),
        new THREE.MeshStandardMaterial({
          color: new THREE.Color(arena.floorColor).multiplyScalar(1.3),
          roughness: 0.5,
        })
      );
      spire.position.set(x, 4.5, z);
      spire.lookAt(0, 4.5, 0);
      this.arenaGroup.add(spire);

      const beacon = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.75, 0),
        new THREE.MeshBasicMaterial({ color: new THREE.Color(arena.rimGlowColor) })
      );
      beacon.position.set(x, 11.2, z);
      this.arenaGroup.add(beacon);
    }

    // 5. Rotating Celestial / Cyber Sky Rings
    for (let i = 0; i < 2; i++) {
      const skyRing = new THREE.Mesh(
        new THREE.TorusGeometry(54 + i * 12, 0.35, 8, 64),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(i === 0 ? arena.gridAccentColor : arena.rimGlowColor),
          transparent: true,
          opacity: 0.45,
        })
      );
      skyRing.rotation.x = Math.PI / 2 + (i === 0 ? 0.28 : -0.32);
      skyRing.position.set(0, 18 + i * 6, 0);
      this.skyRingGroup.add(skyRing);
    }

    // 6. Weather / Atmospheric Particle System
    const particleCount =
      this.currentQuality === 'Ultra'
        ? 420
        : this.currentQuality === 'High'
        ? 260
        : this.currentQuality === 'Medium'
        ? 140
        : 60;
    const positions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 90;
      positions[i * 3 + 1] = Math.random() * 34 + 1;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const pMat = new THREE.PointsMaterial({
      color: new THREE.Color(arena.gridAccentColor),
      size: 0.38,
      transparent: true,
      opacity: 0.72,
    });
    this.weatherPoints = new THREE.Points(pGeo, pMat);
    this.arenaGroup.add(this.weatherPoints);

    // 7. Build Destructible Arena Objects
    for (const dSpec of arena.destructibles) {
      const intact = new THREE.Group();
      intact.position.set(dSpec.position[0], 0, dSpec.position[2]);

      const isCrystal = dSpec.type.includes('crystal') || dSpec.type.includes('core') || dSpec.type.includes('plasma');

      // Stone plinth so every object is anchored to the floor
      const plinth = new THREE.Mesh(
        new THREE.CylinderGeometry(dSpec.radius * 0.78, dSpec.radius * 0.95, 0.55, 10),
        new THREE.MeshStandardMaterial({
          color: new THREE.Color(arena.floorColor).multiplyScalar(3.1),
          roughness: 0.88,
          metalness: 0.08,
        })
      );
      plinth.position.set(0, 0.27, 0);
      plinth.castShadow = this.currentQuality !== 'Low';
      intact.add(plinth);

      const mainMesh = new THREE.Mesh(
        isCrystal
          ? new THREE.OctahedronGeometry(dSpec.radius * 0.6, 0)
          : new THREE.CylinderGeometry(dSpec.radius * 0.42, dSpec.radius * 0.58, 3.6, 8),
        new THREE.MeshStandardMaterial({
          color: new THREE.Color(dSpec.color),
          emissive: new THREE.Color(dSpec.color),
          emissiveIntensity: isCrystal ? 0.5 : 0.22,
          roughness: 0.35,
          metalness: 0.3,
        })
      );
      mainMesh.position.set(0, isCrystal ? 1.25 : 2.35, 0);
      mainMesh.castShadow = this.currentQuality !== 'Low';
      intact.add(mainMesh);

      // Vertical energy wisp marking the objective from a distance
      const wisp = new THREE.Mesh(
        new THREE.CylinderGeometry(0.06, 0.16, 3.4, 6, 1, true),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(dSpec.color),
          transparent: true,
          opacity: 0.3,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
          side: THREE.DoubleSide,
        })
      );
      wisp.position.set(0, isCrystal ? 2.9 : 4.4, 0);
      intact.add(wisp);

      const rubble = new THREE.Mesh(
        new THREE.DodecahedronGeometry(dSpec.radius * 0.65, 0),
        new THREE.MeshStandardMaterial({
          color: 0x334155,
          roughness: 0.9,
        })
      );
      rubble.scale.set(1.2, 0.35, 1.2);
      rubble.position.set(dSpec.position[0], 0.25, dSpec.position[2]);
      rubble.visible = false;

      this.arenaGroup.add(intact, rubble);
      this.destructibleMeshes.set(dSpec.id, { intact, rubble });
    }

    // 8. Build Articulated 3D Anime Character Rigs for all 8 Fighters
    for (const charDef of fighters) {
      const rig = buildArticulatedAnimeCharacter(charDef, this.currentQuality);
      this.scene.add(rig.root);
      this.fighterRigs.set(charDef.id, rig);
    }
  }

  /**
   * v1.4.0 — Project a point above a fighter's head into CSS pixel space.
   * The nameplates are DOM (crisp text at any distance), so React needs the
   * projected position rather than a Three.js object.
   * Returns null when the point is behind the lens.
   */
  public projectToScreen(
    x: number,
    y: number,
    z: number,
    width: number,
    height: number
  ): { x: number; y: number; depth: number } | null {
    const v = new THREE.Vector3(x, y, z).project(this.camera);
    if (v.z > 1) return null;
    return {
      x: (v.x * 0.5 + 0.5) * width,
      y: (-v.y * 0.5 + 0.5) * height,
      depth: v.z,
    };
  }

  public renderSimulationState(
    state: BattleSimulationState,
    arena: ArenaDefinition
  ): void {
    const nowPerf = performance.now();
    const dtMs = nowPerf - this.lastFrameTimestamp;
    this.lastFrameTimestamp = nowPerf;
    // Real frame delta (clamped) so camera smoothing is frame-rate independent.
    this.lastFrameDtSec = Math.min(0.25, Math.max(0.001, dtMs / 1000));
    this.frameCount++;

    if (nowPerf - this.lastFpsUpdate >= 500) {
      const elapsed = (nowPerf - this.lastFpsUpdate) / 1000;
      const perfMem = (performance as unknown as { memory?: { usedJSHeapSize: number } }).memory;
      this.telemetry = {
        fps: Math.min(120, Math.round(this.frameCount / elapsed)),
        frameTimeMs: Number(dtMs.toFixed(1)),
        drawCalls: this.sceneDrawCalls,
        triangles: this.sceneTriangles,
        geometriesInMemory: this.renderer.info.memory.geometries,
        texturesInMemory: this.renderer.info.memory.textures,
        jsHeapMb: perfMem ? Math.round(perfMem.usedJSHeapSize / (1024 * 1024)) : null,
      };
      this.frameCount = 0;
      this.lastFpsUpdate = nowPerf;
    }

    // 1. Update Arena Stage Atmosphere & Lighting
    const stageSpec = arena.stages[state.stageNumber - 1] ?? arena.stages[0];
    (this.scene.background as THREE.Color).lerp(new THREE.Color(stageSpec.skyTopColor), 0.04);
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.color.lerp(new THREE.Color(stageSpec.fogColor), 0.04);
    }
    this.ambientLight.color.lerp(new THREE.Color(stageSpec.ambientLightColor), 0.05);
    this.dirLight.color.lerp(new THREE.Color(stageSpec.directionalLightColor), 0.05);
    this.dirLight.intensity = stageSpec.lightIntensity;

    // Animate Sky Rings & Weather Particles
    this.skyRingGroup.children.forEach((ring, i) => {
      ring.rotation.z = state.elapsedSec * (i === 0 ? 0.14 : -0.19);
    });

    if (this.weatherPoints) {
      this.weatherPoints.rotation.y = state.elapsedSec * 0.06;
    }

    // 2. Update Fighter Positions, Rotations & Skeletal Animations
    for (const fState of state.fighters) {
      const rig = this.fighterRigs.get(fState.id);
      if (!rig) continue;

      const deltaXZ = Math.hypot(
        fState.position[0] - rig.previousPosition.x,
        fState.position[2] - rig.previousPosition.z
      );
      rig.previousPosition.set(fState.position[0], fState.position[1], fState.position[2]);

      rig.root.position.set(fState.position[0], fState.position[1], fState.position[2]);
      rig.root.rotation.y = fState.rotationY;

      updateCharacterAnimation(
        rig,
        fState.animationState,
        state.elapsedSec,
        fState.isAwakened,
        fState.isGuarding
      );

      // v1.1.0 — dynamic facial expression, weapon slash ribbons, afterimage ghosts
      updateAnimeExpression(rig, fState.animationState, fState.isAwakened, state.elapsedSec);
      updateSlashRibbons(rig, fState.animationState, state.elapsedSec);
      updateAfterimages(rig, fState.animationState, fState.isAwakened, state.elapsedSec, deltaXZ);
    }

    // 3. Update Destructible Arena Objects
    for (const dState of state.destructibles) {
      const entry = this.destructibleMeshes.get(dState.id);
      if (!entry) continue;
      if (dState.isDestroyed) {
        entry.intact.visible = false;
        entry.rubble.visible = true;
      } else {
        entry.intact.visible = true;
        entry.rubble.visible = false;
        const hpRatio = Math.max(0.35, dState.hp / dState.maxHp);
        entry.intact.scale.set(1, hpRatio, 1);
      }
    }

    // 4. Rebuild Active Environmental Zones & Alliance Tether Lines
    this.disposeGroupChildren(this.zoneGroup);
    for (const zone of state.activeZones) {
      const zRing = new THREE.Mesh(
        new THREE.RingGeometry(Math.max(0.2, zone.radius - 0.35), zone.radius, 32),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(zone.color),
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.78,
        })
      );
      zRing.rotation.x = -Math.PI / 2;
      zRing.position.set(zone.position[0], 0.08, zone.position[2]);

      const zFill = new THREE.Mesh(
        new THREE.CircleGeometry(zone.radius, 32),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(zone.color),
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.2,
        })
      );
      zFill.rotation.x = -Math.PI / 2;
      zFill.position.set(zone.position[0], 0.06, zone.position[2]);
      this.zoneGroup.add(zRing, zFill);
    }

    // Alliance Golden Tether Beams
    this.disposeGroupChildren(this.allianceLinesGroup);
    for (const al of state.alliances) {
      if (al.outcome !== 'active') continue;
      const fA = state.fighters.find((f) => f.id === al.memberAId);
      const fB = state.fighters.find((f) => f.id === al.memberBId);
      if (!fA || !fB || !fA.isAlive || !fB.isAlive) continue;

      const points = [
        new THREE.Vector3(fA.position[0], 1.15, fA.position[2]),
        new THREE.Vector3(
          (fA.position[0] + fB.position[0]) / 2,
          1.85 + Math.sin(state.elapsedSec * 5) * 0.2,
          (fA.position[2] + fB.position[2]) / 2
        ),
        new THREE.Vector3(fB.position[0], 1.15, fB.position[2]),
      ];
      const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
      const lineMat = new THREE.LineBasicMaterial({
        color: 0xfacc15,
        transparent: true,
        opacity: 0.85,
      });
      this.allianceLinesGroup.add(new THREE.Line(lineGeo, lineMat));
    }

    // 4b. v1.1.0 — Anime Clash Lock visuals (locked blades, crossed beams, spark corona)
    this.disposeGroupChildren(this.clashGroup);
    for (const lock of state.clashLocks ?? []) {
      if (lock.resolved && state.elapsedSec - (lock.resolvedAtSec ?? 0) > 3) continue;
      const [lx, , lz] = lock.position;

      // Ground shock ring beneath the struggle
      const groundRing = new THREE.Mesh(
        new THREE.RingGeometry(1.6, 2.1, 32),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color('#fde047'),
          side: THREE.DoubleSide,
          transparent: true,
          opacity: lock.resolved ? 0.35 : 0.85,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      );
      groundRing.rotation.x = -Math.PI / 2;
      groundRing.position.set(lx, 0.1, lz);
      this.clashGroup.add(groundRing);

      // Crossed 3D blades / colliding beams at the clash epicentre
      const clashCount = lock.kind === 'beam-clash' ? 2 : 3;
      for (let i = 0; i < clashCount; i++) {
        const angle = (i / clashCount) * Math.PI * 2 + state.elapsedSec * 6.5;
        const shardLen = lock.kind === 'beam-clash' ? 6.4 : 3.2;
        const shard = new THREE.Mesh(
          new THREE.BoxGeometry(0.09, shardLen, 0.09),
          new THREE.MeshBasicMaterial({
            color: new THREE.Color(i % 2 === 0 ? '#fef9c3' : '#f59e0b'),
            transparent: true,
            opacity: lock.resolved ? 0.25 : 0.95,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
          })
        );
        shard.position.set(lx, 1.35, lz);
        shard.rotation.set(Math.sin(angle) * 0.9, angle, Math.cos(angle) * 0.9);
        this.clashGroup.add(shard);
      }

      // Spark corona sphere
      const corona = new THREE.Mesh(
        new THREE.IcosahedronGeometry(0.55 + Math.abs(lock.momentum - 0.5) * 1.5, 1),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(lock.winnerId ? '#facc15' : '#ffffff'),
          wireframe: true,
          transparent: true,
          opacity: lock.resolved ? 0.3 : 0.8,
        })
      );
      corona.position.set(lx, 1.35, lz);
      corona.rotation.set(state.elapsedSec * 4, state.elapsedSec * 6, 0);
      this.clashGroup.add(corona);
    }

    // 4c. v1.1.0 — Stage-specific Arena Cataclysm telegraph & impact theatre
    this.disposeGroupChildren(this.cataclysmGroup);
    const cataclysm = state.activeCataclysm;
    if (cataclysm) {
      const [cx, , cz] = cataclysm.position;
      const totalWarn = Math.max(0.2, cataclysm.telegraphRemainingSec);
      const dangerRing = new THREE.Mesh(
        new THREE.RingGeometry(cataclysm.radius * 0.94, cataclysm.radius, 40),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(cataclysm.color),
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.9,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      );
      dangerRing.rotation.x = -Math.PI / 2;
      dangerRing.position.set(cx, 0.11, cz);
      this.cataclysmGroup.add(dangerRing);

      const dangerFill = new THREE.Mesh(
        new THREE.CircleGeometry(cataclysm.radius, 40),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(cataclysm.accentColor),
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.16 + Math.abs(Math.sin(state.elapsedSec * 7)) * 0.14,
          depthWrite: false,
        })
      );
      dangerFill.rotation.x = -Math.PI / 2;
      dangerFill.position.set(cx, 0.09, cz);
      this.cataclysmGroup.add(dangerFill);

      // Descending meteor / energy pillar telegraph
      const meteorHeight = 6 + totalWarn * 9;
      const meteor = new THREE.Mesh(
        new THREE.ConeGeometry(cataclysm.radius * 0.22, 2.6, 12),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(cataclysm.color),
          transparent: true,
          opacity: 0.85,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      );
      meteor.position.set(cx, meteorHeight, cz);
      meteor.rotation.x = Math.PI;
      this.cataclysmGroup.add(meteor);

      const dropColumn = new THREE.Mesh(
        new THREE.CylinderGeometry(cataclysm.radius * 0.1, cataclysm.radius * 0.3, meteorHeight, 14, 1, true),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(cataclysm.accentColor),
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.22,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      );
      dropColumn.position.set(cx, meteorHeight / 2, cz);
      this.cataclysmGroup.add(dropColumn);
    }

    // 5. Render Active Hybrid Anime Cinematic VFX
    this.disposeGroupChildren(this.vfxGroup);
    for (const vfx of state.vfxEvents) {
      const progress = Math.max(
        0,
        Math.min(1, (state.elapsedSec - vfx.createdAtSec) / Math.max(0.1, vfx.durationSec))
      );
      const opacity = Math.max(0, 1 - progress);

      if (vfx.type === 'shockwave' || vfx.type === 'shatter-burst' || vfx.type === 'counter-flash') {
        const currentR = Math.max(0.5, vfx.radius * (0.25 + progress * 0.95));
        const waveRing = new THREE.Mesh(
          new THREE.RingGeometry(currentR * 0.72, currentR, 32),
          new THREE.MeshBasicMaterial({
            color: new THREE.Color(vfx.color),
            side: THREE.DoubleSide,
            transparent: true,
            opacity: opacity * 0.9,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
          })
        );
        waveRing.rotation.x = -Math.PI / 2;
        waveRing.position.set(vfx.position[0], 0.18, vfx.position[2]);

        const dome = new THREE.Mesh(
          new THREE.SphereGeometry(currentR * 0.65, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2),
          new THREE.MeshBasicMaterial({
            color: new THREE.Color(vfx.secondaryColor),
            transparent: true,
            opacity: opacity * 0.42,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
          })
        );
        dome.position.set(vfx.position[0], 0.05, vfx.position[2]);
        this.vfxGroup.add(waveRing, dome);
      } else if (vfx.type === 'energy-beam' && vfx.targetPosition) {
        const startVec = new THREE.Vector3(vfx.position[0], 1.25, vfx.position[2]);
        const endVec = new THREE.Vector3(
          vfx.targetPosition[0],
          1.15,
          vfx.targetPosition[2]
        );
        const dist = startVec.distanceTo(endVec);
        if (dist > 0.2) {
          const beamGeo = new THREE.CylinderGeometry(0.28, 0.28, dist, 12);
          beamGeo.rotateX(Math.PI / 2);
          const beamMesh = new THREE.Mesh(
            beamGeo,
            new THREE.MeshBasicMaterial({
              color: new THREE.Color(vfx.color),
              transparent: true,
              opacity: opacity * 0.88,
              blending: THREE.AdditiveBlending,
            })
          );
          beamMesh.position.copy(startVec).lerp(endVec, 0.5);
          beamMesh.lookAt(endVec);
          this.vfxGroup.add(beamMesh);
        }
      } else if (
        vfx.type === 'awakening-pillar' ||
        vfx.type === 'elimination-ascension' ||
        vfx.type === 'lightning-strike'
      ) {
        const pillar = new THREE.Mesh(
          new THREE.CylinderGeometry(vfx.radius * 0.35, vfx.radius * 0.5, 18, 16, 1, true),
          new THREE.MeshBasicMaterial({
            color: new THREE.Color(vfx.color),
            side: THREE.DoubleSide,
            transparent: true,
            opacity: opacity * 0.72,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
          })
        );
        pillar.position.set(vfx.position[0], 9, vfx.position[2]);
        this.vfxGroup.add(pillar);
      } else if (vfx.type === 'clash-burst') {
        const burstR = Math.max(0.4, vfx.radius * (0.3 + progress * 1.05));
        const flare = new THREE.Mesh(
          new THREE.SphereGeometry(burstR * 0.55, 18, 14),
          new THREE.MeshBasicMaterial({
            color: new THREE.Color(vfx.color),
            transparent: true,
            opacity: opacity * 0.72,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
          })
        );
        flare.position.set(vfx.position[0], 1.35, vfx.position[2]);
        this.vfxGroup.add(flare);

        // Radial anime impact shards
        const shardCount = 8;
        for (let i = 0; i < shardCount; i++) {
          const a = (i / shardCount) * Math.PI * 2 + progress * 2.2;
          const len = burstR * (0.9 + (i % 3) * 0.25);
          const shard = new THREE.Mesh(
            new THREE.BoxGeometry(0.07, len, 0.07),
            new THREE.MeshBasicMaterial({
              color: new THREE.Color(i % 2 === 0 ? vfx.color : vfx.secondaryColor),
              transparent: true,
              opacity: opacity * 0.9,
              blending: THREE.AdditiveBlending,
              depthWrite: false,
            })
          );
          shard.position.set(
            vfx.position[0] + Math.cos(a) * burstR * 0.4,
            1.35 + Math.sin(a) * burstR * 0.4,
            vfx.position[2] + Math.sin(a * 0.7) * burstR * 0.35
          );
          shard.rotation.set(a, a * 1.4, a * 0.6);
          this.vfxGroup.add(shard);
        }
      } else if (vfx.type === 'vortex-sphere') {
        const vortex = new THREE.Mesh(
          new THREE.SphereGeometry(vfx.radius * 0.55, 16, 16),
          new THREE.MeshBasicMaterial({
            color: new THREE.Color(vfx.color),
            wireframe: true,
            transparent: true,
            opacity: opacity * 0.82,
          })
        );
        vortex.position.set(
          vfx.targetPosition?.[0] ?? vfx.position[0],
          1.4,
          vfx.targetPosition?.[2] ?? vfx.position[2]
        );
        vortex.rotation.y = state.elapsedSec * 8;
        this.vfxGroup.add(vortex);
      } else {
        // Anime Crescent Slash Arc
        const slash = new THREE.Mesh(
          new THREE.RingGeometry(1.1, 2.25, 16, 1, 0, Math.PI * 1.15),
          new THREE.MeshBasicMaterial({
            color: new THREE.Color(vfx.secondaryColor),
            side: THREE.DoubleSide,
            transparent: true,
            opacity: opacity * 0.92,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
          })
        );
        slash.rotation.x = -Math.PI / 2 + 0.25;
        slash.rotation.z = progress * 4.5;
        slash.position.set(vfx.position[0], 1.15, vfx.position[2]);
        this.vfxGroup.add(slash);
      }
    }

    // 6. Update Intelligent Automatic Cinematic Director Camera
    this.updateCameraDirector(state);

    // 7. Render Frame
    // Scene-layer stats only. With the composer active, renderer.info gets reset
    // by every post pass, so reading it afterwards reports the final fullscreen
    // quad ("1 draw, 1 triangle") instead of the actual scene.
    if (this.composer) {
      this.updateBloomIntensity(state);
      this.composer.render();
    } else {
      this.renderer.info.reset();
      this.renderer.render(this.scene, this.camera);
      this.sceneDrawCalls = this.renderer.info.render.calls;
      this.sceneTriangles = this.renderer.info.render.triangles;
    }
  }

  /**
   * v1.1.0 — Detects the killing blow of the final elimination and switches the
   * director into a 0.2x slow-motion bullet-time orbit around the finisher.
   */
  public getBulletTimeState(): {
    active: boolean;
    progress: number;
    attackerId: string | null;
    victimId: string | null;
  } {
    return {
      active: this.isBulletTimeActive,
      progress: this.bulletTimeProgress,
      attackerId: this.finalBlowFighterId,
      victimId: this.finalBlowVictimId,
    };
  }

  private detectFinalBlow(state: BattleSimulationState): void {
    if (this.finalBlowStartedAtSec >= 0) return;
    // Final elimination (2nd place falling) triggers the slow-motion finisher
    const lastElim = state.eliminations[state.eliminations.length - 1];
    if (!lastElim || state.survivorCount !== 1) return;
    if (lastElim.order !== 7) return;
    if (!lastElim.finalHitterId) return;

    this.finalBlowStartedAtSec = state.elapsedSec;
    this.finalBlowFighterId = lastElim.finalHitterId;
    this.finalBlowVictimId = lastElim.victimId;
    this.isBulletTimeActive = true;
  }

  /**
   * v1.1.1 — Camera obstruction avoidance.
   *
   * A tight 7m orbit can end up *inside* a destructible crystal or plinth, which
   * produces the "giant floating gem fills the screen" artefact. Sample candidate
   * azimuths and pick the one that keeps the camera clear of destructibles, off the
   * arena lip, and never below ground level.
   */
  private pickClearOrbit(
    cx: number,
    cz: number,
    radius: number,
    height: number,
    preferredAngle: number,
    state: BattleSimulationState
  ): { pos: THREE.Vector3 } {
    const obstacles = state.destructibles.filter((d) => !d.isDestroyed);
    const bodies = state.fighters.filter((f) => f.isAlive);
    const candidates = [0, 0.5, -0.5, 1.0, -1.0, 1.6, -1.6, 2.2, -2.2, Math.PI];
    let best = { pos: new THREE.Vector3(0, 20, 0), score: -Infinity };

    for (const offset of candidates) {
      const a = preferredAngle + offset;
      const px = cx + Math.sin(a) * radius;
      const pz = cz + Math.cos(a) * radius;
      const py = Math.max(2.4, height);

      let score = 10 - Math.abs(offset) * 2.5; // prefer the director's intended angle
      score += Math.min(height, 8) * 0.35; // higher angles clear props and read the arena

      // Penalise proximity to destructible structures
      for (const o of obstacles) {
        const d = Math.hypot(px - o.position[0], pz - o.position[2]);
        const clearance = o.radius + 2.6;
        if (d < clearance) score -= (clearance - d) * 14;
      }

      // Keep a real standoff from every fighter: a body straddling the lens
      // (or a slash ribbon in front of the near plane) ruins the shot.
      for (const f of bodies) {
        const d = Math.hypot(px - f.position[0], pz - f.position[2]);
        if (d < 5.0) score -= (5.0 - d) * 22;
      }

      // LINE OF SIGHT. A radial standoff alone still lets a pillar stand between
      // the lens and the duel, which fills the frame with scenery and hides the
      // fighters behind it. Walk the sight line and penalise blocked shots.
      for (const o of obstacles) {
        const ox = o.position[0];
        const oz = o.position[2];
        const segX = cx - px;
        const segZ = cz - pz;
        const segLenSq = segX * segX + segZ * segZ;
        if (segLenSq < 0.001) continue;
        // Project the obstacle centre onto the sight line (clamped to the segment)
        const t = Math.max(0, Math.min(1, ((ox - px) * segX + (oz - pz) * segZ) / segLenSq));
        const nearX = px + segX * t;
        const nearZ = pz + segZ * t;
        const ldist = Math.hypot(ox - nearX, oz - nearZ);
        const blockR = o.radius + 1.1;
        if (ldist < blockR) score -= (blockR - ldist) * 26 + 6;
      }

      // Penalise leaving the arena footprint
      const fromCentre = Math.hypot(px, pz);
      if (fromCentre > this.arenaPlayableRadius - 3) {
        score -= (fromCentre - (this.arenaPlayableRadius - 3)) * 6;
      }

      if (score > best.score) {
        best = { pos: new THREE.Vector3(px, py, pz), score };
      }
    }

    // v1.4.0 — A PENALTY IS NOT A REJECTION.
    // The scoring above only discourages blocked orbits; when every candidate
    // was blocked it still returned the least-bad one, which is how a pillar
    // ends up filling the frame while eight fighters fight behind it.
    // If the winning shot is still occluded, lift the camera until the sight
    // line clears the props entirely.
    if (this.segmentBlocked(best.pos.x, best.pos.z, cx, cz, state)) {
      const startY = best.pos.y;
      for (let lift = 1.5; lift <= 13.5; lift += 1.5) {
        const y = startY + lift;
        // Raising the lens also pulls it back a little so the look-at stays in frame
        const pull = 1 + lift * 0.045;
        const ox = cx + (best.pos.x - cx) * pull;
        const oz = cz + (best.pos.z - cz) * pull;
        if (!this.segmentBlocked(ox, oz, cx, cz, state)) {
          return { pos: new THREE.Vector3(ox, y, oz) };
        }
      }
      // Last resort: bird's-eye, which cannot be occluded by anything in-arena
      return { pos: new THREE.Vector3(cx, startY + 16, cz + 0.001) };
    }

    return { pos: best.pos };
  }

  /** True when any live destructible intersects the lens→focus sight line. */
  private segmentBlocked(
    px: number,
    pz: number,
    cx: number,
    cz: number,
    state: BattleSimulationState
  ): boolean {
    const obstacles = state.destructibles.filter((d) => !d.isDestroyed);
    for (const o of obstacles) {
      const segX = cx - px;
      const segZ = cz - pz;
      const segLenSq = segX * segX + segZ * segZ;
      if (segLenSq < 0.001) continue;
      const t = Math.max(
        0,
        Math.min(1, ((o.position[0] - px) * segX + (o.position[2] - pz) * segZ) / segLenSq)
      );
      const nearX = px + segX * t;
      const nearZ = pz + segZ * t;
      const ldist = Math.hypot(o.position[0] - nearX, o.position[2] - nearZ);
      if (ldist < o.radius + 1.1) return true;
    }
    return false;
  }

  private updateCameraDirector(state: BattleSimulationState): void {
    this.directorOrbitAngle += 0.0035;
    const alive = state.fighters.filter((f) => f.isAlive);

    this.detectFinalBlow(state);

    let desiredPos = new THREE.Vector3(0, 26, 44);
    let desiredLook = new THREE.Vector3(0, 1.5, 0);

    // --- SLOW-MOTION FINAL BLOW BULLET-TIME CAMERA ---
    if (this.finalBlowStartedAtSec >= 0) {
      const blowElapsed = state.elapsedSec - this.finalBlowStartedAtSec;
      this.bulletTimeProgress = Math.min(1, blowElapsed / 2.6);
      this.isBulletTimeActive = blowElapsed < 2.6;

      const attacker = state.fighters.find((f) => f.id === this.finalBlowFighterId);
      const victim = state.fighters.find((f) => f.id === this.finalBlowVictimId);
      // Only hold the tight finisher orbit while the bullet-time window is live
      if (attacker && blowElapsed < 2.9) {
        const ax = attacker.position[0];
        const az = attacker.position[2];
        const vx = victim?.position[0] ?? ax;
        const vz = victim?.position[2] ?? az;
        const midX = (ax + vx) / 2;
        const midZ = (az + vz) / 2;

        const orbitAngle = this.bulletTimeProgress * Math.PI * 0.9;
        const radius = 3.4 + this.bulletTimeProgress * 5.2;
        desiredPos.set(
          midX + Math.sin(orbitAngle + 1.1) * radius,
          2.1 + this.bulletTimeProgress * 2.6,
          midZ + Math.cos(orbitAngle + 1.1) * radius
        );
        desiredLook.set(midX, 1.3, midZ);

        const btDt = this.lastFrameDtSec;
        this.camCurrentPos.lerp(desiredPos, cameraAlpha(btDt, 0.105));
        this.camCurrentLookAt.lerp(desiredLook, cameraAlpha(btDt, 0.083));
        this.camera.position.copy(this.camCurrentPos);
        this.camera.lookAt(this.camCurrentLookAt);
        this.rimLight.position.set(this.camCurrentLookAt.x, 7, this.camCurrentLookAt.z);
        return;
      }
    }

    // Victory Champion Spotlight
    if (state.status === 'completed' && state.winnerId) {
      const champ = state.fighters.find((f) => f.id === state.winnerId) ?? alive[0];
      if (champ) {
        const cx = champ.position[0];
        const cz = champ.position[2];
        desiredPos.set(
          cx + Math.sin(this.directorOrbitAngle * 2.5) * 5.0,
          2.6,
          cz + Math.cos(this.directorOrbitAngle * 2.5) * 5.0
        );
        desiredLook.set(cx, 1.35, cz);
      }
    } else if (this.cameraMode === 'wide') {
      desiredPos.set(
        Math.sin(this.directorOrbitAngle * 0.7) * 46,
        25,
        Math.cos(this.directorOrbitAngle * 0.7) * 46
      );
      desiredLook.set(0, 1.0, 0);
    } else if (this.cameraMode === 'follow' && this.followFighterId) {
      const target =
        state.fighters.find((f) => f.id === this.followFighterId) ?? alive[0];
      if (target) {
        const tx = target.position[0];
        const tz = target.position[2];
        const behindAngle = target.rotationY + Math.PI;
        desiredPos.set(
          tx + Math.sin(behindAngle) * 5.6,
          2.9,
          tz + Math.cos(behindAngle) * 5.6
        );
        const enemy = state.fighters.find((e) => e.id === target.targetId && e.isAlive);
        if (enemy) {
          desiredLook.set(
            (tx + enemy.position[0]) * 0.5,
            1.4,
            (tz + enemy.position[2]) * 0.5
          );
        } else {
          desiredLook.set(tx, 1.45, tz);
        }
      }
    } else {
      // AUTOMATIC CINEMATIC DIRECTOR CAMERA
      // Check for a recent critical event (Ultimate, Elimination, Betrayal, Awakening) within last 2.0s
      const recentCritical = [...state.events]
        .reverse()
        .find(
          (e) =>
            state.elapsedSec - e.timestampSec >= 0 &&
            state.elapsedSec - e.timestampSec <= 2.0 &&
            (e.type === 'ULTIMATE_UNLEASHED' ||
              e.type === 'ELIMINATION' ||
              e.type === 'ALLIANCE_BETRAYED' ||
              e.type === 'AWAKENING_TRIGGERED') &&
            e.position
        );

      if (recentCritical && recentCritical.position) {
        // Aim at the actual bodies, not the ability's impact point — an impact
        // centre can sit metres away from the fighters, which pushes them to the
        // top of the frame while the camera stares at the blast radius.
        const actor = state.fighters.find((f) => f.id === recentCritical.actorId);
        const victim = state.fighters.find((f) => f.id === recentCritical.targetId);
        let ex = recentCritical.position[0];
        let ez = recentCritical.position[2];
        if (actor && actor.isAlive) {
          if (victim && victim.isAlive) {
            ex = (actor.position[0] + victim.position[0]) / 2;
            ez = (actor.position[2] + victim.position[2]) / 2;
          } else {
            ex = actor.position[0];
            ez = actor.position[2];
          }
        }
        const critDist = 10.5;
        desiredPos.set(
          ex + Math.sin(this.directorOrbitAngle * 2.0) * critDist,
          5.4,
          ez + Math.cos(this.directorOrbitAngle * 2.0) * critDist
        );
        desiredLook.set(ex, 1.25, ez);
        // A 2s dramatic beat is too short to earn from a slow pan: cut onto it
        // when the subject is far away, otherwise arrive quickly.
        this.criticalFastLerp = true;
        if (this.camCurrentLookAt.distanceTo(desiredLook) > 14) {
          this.camCurrentPos.copy(desiredPos);
          this.camCurrentLookAt.copy(desiredLook);
        }
      } else if (alive.length > 0) {
        // v1.1.1 — ACTION HOTSPOT DIRECTOR.
        //
        // Averaging all eight bodies framed empty floor; scoring *pairs* was no
        // better, because two fighters 15m apart with mutual target locks out-scored
        // a tight duel and their midpoint is empty arena. So score local clusters
        // instead: the focus is always the weighted centroid of real bodies, which
        // makes "camera stares at nothing" structurally impossible.
        const actWeight = (f: (typeof alive)[number]): number => {
          switch (f.animationState) {
            case 'ultimate': return 55;
            case 'awakening': return 48;
            case 'signatureSkill': return 30;
            case 'counter': return 18;
            case 'heavyAttack': return 20;
            case 'basicCombo': return 14;
            default: return 0;
          }
        };

        let bestScore = -Infinity;
        let focalX = 0;
        let focalZ = 0;
        let focalSpread = 5;

        const CLUSTER_R = 11;
        for (const anchor of alive) {
          const members = alive.filter(
            (o) =>
              Math.hypot(o.position[0] - anchor.position[0], o.position[2] - anchor.position[2]) <= CLUSTER_R
          );
          if (members.length < 2) continue; // a lone drifter is not a shot

          let score = 0;
          let wx = 0;
          let wz = 0;
          let wSum = 0;
          for (const m of members) {
            const d = Math.hypot(m.position[0] - anchor.position[0], m.position[2] - anchor.position[2]);
            const prox = 1 - d / CLUSTER_R; // 1 at the anchor, 0 at the rim
            score += prox * 34 + actWeight(m);
            // Drama: low HP and active fights
            score += (1 - m.hp / m.maxHp) * 14;
            const lock = alive.some(
              (o) =>
                o.id === m.targetId &&
                Math.hypot(o.position[0] - m.position[0], o.position[2] - m.position[2]) < 7
            );
            if (lock) score += 16;
            wx += m.position[0] * prox;
            wz += m.position[2] * prox;
            wSum += prox;
          }
          score += (members.length - 2) * 10; // a bigger brawl is a better shot

          if (wSum > 0.001 && score > bestScore) {
            bestScore = score;
            focalX = wx / wSum;
            focalZ = wz / wSum;
            let spread = 0;
            for (const m of members) {
              spread = Math.max(
                spread,
                Math.hypot(m.position[0] - focalX, m.position[2] - focalZ)
              );
            }
            focalSpread = spread;
          }
        }

        // Fall back to the most damaged living fighter if the field is scattered
        if (bestScore === -Infinity) {
          const hurt = [...alive].sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp)[0];
          focalX = hurt.position[0];
          focalZ = hurt.position[2];
          focalSpread = 3;
        }

        // Keep the duel centred. A multiplicative pull toward the origin used to
        // shove the action into the corner of the frame; instead only clamp the
        // focus point inward when the fight is genuinely pinned against the lip.
        const maxFocusR = this.arenaPlayableRadius * 0.78;
        const focusR = Math.hypot(focalX, focalZ);
        const focusScale = focusR > maxFocusR ? maxFocusR / focusR : 1;
        const blendX = focalX * focusScale;
        const blendZ = focalZ * focusScale;

        // v1.1.1 — Fighters are ~1.9m tall. The old 17.5–28m orbit made them
        // specks and hid every expression, ribbon and afterimage; a flat 7m was
        // too tight and cropped the bodies. Frame at a distance derived from the
        // size of the duel actually being fought:
        //   tight 1v1 (2m apart)  -> ~9m orbit  (character detail reads)
        //   4v4 melee (12m apart) -> ~17m orbit (whole skirmish stays in frame)
        // Frame the cluster: a tight duel needs ~9m, a five-way brawl ~17m.
        const camDist = Math.min(17.5, Math.max(9.0, 7.8 + focalSpread * 1.05));
        // Slightly higher lens on wider shots keeps the front rank from occluding
        const camHeight = camDist * 0.44;

        // A slow breathing drift adds cinematic life without ever cropping bodies
        const breath = 1 + Math.sin(state.elapsedSec * 0.42) * 0.045;
        const camDistFinal = camDist * breath;

        // Push in a little when the framed cluster is throwing heavy attacks
        const clashZoom = bestScore > 120 ? 0.93 : 1.0;

        const { pos } = this.pickClearOrbit(
          blendX,
          blendZ,
          camDistFinal * clashZoom,
          camHeight * clashZoom,
          this.directorOrbitAngle,
          state
        );
        desiredPos.copy(pos);
        desiredLook.set(blendX, 1.15, blendZ);
      }
    }

    // Frame-rate independent smoothing: same response at 15 fps as at 144 fps.
    // Critical beats converge ~4x faster so the shot actually lands inside its
    // 2s window even on a sluggish machine.
    const camDt = this.lastFrameDtSec;
    const posTau = this.criticalFastLerp ? 0.062 : 0.257;
    const lookTau = this.criticalFastLerp ? 0.048 : 0.196;
    this.criticalFastLerp = false;
    this.camCurrentPos.lerp(desiredPos, cameraAlpha(camDt, posTau));
    this.camCurrentLookAt.lerp(desiredLook, cameraAlpha(camDt, lookTau));
    this.camera.position.copy(this.camCurrentPos);
    this.camera.lookAt(this.camCurrentLookAt);
    this.rimLight.position.set(this.camCurrentLookAt.x, 7, this.camCurrentLookAt.z);
  }

  private disposeGroupChildren(group: THREE.Group): void {
    while (group.children.length > 0) {
      const child = group.children[0];
      group.remove(child);
      child.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        if (mesh.material) {
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((m) => m.dispose());
          } else {
            mesh.material.dispose();
          }
        }
      });
    }
  }

  public clearBattleObjects(): void {
    for (const rig of this.fighterRigs.values()) {
      this.scene.remove(rig.root);
      rig.root.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        if (mesh.material) {
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((m) => m.dispose());
          } else {
            mesh.material.dispose();
          }
        }
      });
    }
    this.fighterRigs.clear();
    this.destructibleMeshes.clear();

    this.disposeGroupChildren(this.arenaGroup);
    this.disposeGroupChildren(this.skyRingGroup);
    this.disposeGroupChildren(this.zoneGroup);
    this.disposeGroupChildren(this.vfxGroup);
    this.disposeGroupChildren(this.allianceLinesGroup);
    this.disposeGroupChildren(this.clashGroup);
    this.disposeGroupChildren(this.cataclysmGroup);
    this.weatherPoints = null;
  }

  public dispose(): void {
    this.clearBattleObjects();
    this.renderer.dispose();
    if (this.renderer.domElement && this.renderer.domElement.parentNode) {
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
    }
  }
}
