import { describe, expect, it } from 'vitest';
import {
  ASCENT_ADVANCERS_PER_ROUND,
  ASCENT_TOTAL_ROUNDS,
  AscentState,
  createAscent,
  deriveRoundSeed,
  getBenchFighters,
  getAscentRoundName,
  recordAscentRound,
} from '../src/engine/ascentTournament';
import { getAllRegisteredCharacters, getEligibleCharacters } from '../src/pipeline/assetPipeline';

const eligible = getEligibleCharacters(getAllRegisteredCharacters()).eligible;

/** Builds a legal round result where the given fighter ids fill the top ranks. */
function makeResult(
  state: AscentState,
  winnerOrder: string[]
): Omit<Parameters<typeof recordAscentRound>[1], 'advancedIds'> {
  const entrants = state.pendingEntrants.map((e) => ({ id: e.characterId, name: e.name }));
  const ordered = [
    ...winnerOrder.map((id) => entrants.find((e) => e.id === id)!),
    ...entrants.filter((e) => !winnerOrder.includes(e.id)),
  ];
  return {
    roundNumber: state.currentRound,
    seed: deriveRoundSeed(state.rootSeed, state.currentRound),
    arenaId: 'arena-neo-kyoto',
    arenaName: 'Neo-Kyoto Crater',
    battleId: `battle_r${state.currentRound}`,
    entrantIds: entrants.map((e) => e.id),
    standings: ordered.map((e, i) => ({
      characterId: e.id,
      name: e.name,
      rank: i + 1,
      eliminatedAtSec: i === 0 ? null : 30 + i,
    })),
    winnerId: ordered[0].id,
    winnerName: ordered[0].name,
    durationSec: 120,
  };
}

describe('Cataclysm Ascent tournament', () => {
  it('always stages exactly 8 unique entrants in round 1', () => {
    const state = createAscent(eligible, 'ascent-test-seed');
    expect(state.pendingEntrants).toHaveLength(8);
    expect(new Set(state.pendingEntrants.map((e) => e.characterId)).size).toBe(8);
    expect(state.status).toBe('ready');
    expect(state.currentRound).toBe(1);
  });

  it('is deterministic for the same root seed', () => {
    const a = createAscent(eligible, 'repeatable');
    const b = createAscent(eligible, 'repeatable');
    expect(a.pendingEntrants.map((e) => e.characterId)).toEqual(
      b.pendingEntrants.map((e) => e.characterId)
    );
    expect(a.rootSeed).toBe(b.rootSeed);
  });

  it('derives stable per-round seeds', () => {
    expect(deriveRoundSeed('root', 1)).toBe(deriveRoundSeed('root', 1));
    expect(deriveRoundSeed('root', 1)).not.toBe(deriveRoundSeed('root', 2));
  });

  it('advances the top 4 and refills the round to 8 with newcomers', () => {
    let state = createAscent(eligible, 'advance-test');
    const winners = state.pendingEntrants.slice(0, ASCENT_ADVANCERS_PER_ROUND).map((e) => e.characterId);

    state = recordAscentRound(state, makeResult(state, winners), eligible);

    expect(state.rounds).toHaveLength(1);
    expect(state.rounds[0].advancedIds).toEqual(winners);
    expect(state.currentRound).toBe(2);
    expect(state.status).toBe('ready');
    expect(state.pendingEntrants).toHaveLength(8);
    expect(new Set(state.pendingEntrants.map((e) => e.characterId)).size).toBe(8);

    // The four advancers must be carried over, the other four must be newcomers
    const carried = state.pendingEntrants.filter((e) => e.entry === 'advanced');
    expect(carried.map((e) => e.characterId).sort()).toEqual([...winners].sort());
    expect(state.pendingEntrants.filter((e) => e.entry === 'newcomer')).toHaveLength(4);
  });

  it('never re-admits a fighter who was eliminated', () => {
    let state = createAscent(eligible, 'no-return-test');
    const round1Entrants = state.pendingEntrants.map((e) => e.characterId);
    const winners = round1Entrants.slice(0, 4);
    const eliminated = round1Entrants.slice(4);

    state = recordAscentRound(state, makeResult(state, winners), eligible);
    const round2Entrants = state.pendingEntrants.map((e) => e.characterId);

    for (const id of eliminated) {
      expect(round2Entrants).not.toContain(id);
    }

    // And round 2 must still be a legal 8-way battle
    expect(new Set(round2Entrants).size).toBe(8);
    expect(round2Entrants.length).toBe(8);
  });

  it('consumes the full 12-fighter roster across three rounds', () => {
    let state = createAscent(eligible, 'full-roster-test');
    const seen = new Set(state.pendingEntrants.map((e) => e.characterId));

    for (let round = 1; round < ASCENT_TOTAL_ROUNDS; round++) {
      const winners = state.pendingEntrants.slice(0, 4).map((e) => e.characterId);
      state = recordAscentRound(state, makeResult(state, winners), eligible);
      for (const e of state.pendingEntrants) seen.add(e.characterId);
    }

    expect(seen.size).toBe(eligible.length);
    expect(eligible.length).toBe(12);
  });

  it('crowns a champion after the grand final and refuses further rounds', () => {
    let state = createAscent(eligible, 'champion-test');

    for (let round = 1; round <= ASCENT_TOTAL_ROUNDS; round++) {
      const winners = state.pendingEntrants.slice(0, 4).map((e) => e.characterId);
      const result = makeResult(state, winners);
      state = recordAscentRound(state, result, eligible);
      if (round === ASCENT_TOTAL_ROUNDS) {
        expect(state.status).toBe('completed');
        expect(state.championId).toBe(result.winnerId);
        expect(state.championName).toBe(result.winnerName);
      }
    }

    expect(state.rounds).toHaveLength(ASCENT_TOTAL_ROUNDS);
    // Build the bogus round by hand: after completion there are no pending
    // entrants left for the helper to rank.
    const bogusRound = {
      roundNumber: ASCENT_TOTAL_ROUNDS + 1,
      seed: 'x',
      arenaId: 'arena-neo-kyoto',
      arenaName: 'Neo-Kyoto Crater',
      battleId: 'battle_extra',
      entrantIds: [],
      standings: [],
      winnerId: 'nobody',
      winnerName: 'Nobody',
      durationSec: 0,
    };
    expect(() => recordAscentRound(state, bogusRound, eligible)).toThrow(
      /ASCENT_ALREADY_COMPLETE/
    );
  });

  it('rejects out-of-order rounds', () => {
    const state = createAscent(eligible, 'order-test');
    const bogus = { ...makeResult(state, []), roundNumber: 2 };
    expect(() => recordAscentRound(state, bogus, eligible)).toThrow(/ASCENT_ROUND_MISMATCH/);
  });

  it('refuses to start with fewer than 8 eligible fighters', () => {
    expect(() => createAscent(eligible.slice(0, 7), 'too-small')).toThrow(
      /INSUFFICIENT_ELIGIBLE_FIGHTERS/
    );
  });

  it('reports the bench correctly', () => {
    const state = createAscent(eligible, 'bench-test');
    const bench = getBenchFighters(eligible, state);
    const entrants = new Set(state.pendingEntrants.map((e) => e.characterId));
    expect(bench).toHaveLength(eligible.length - 8);
    for (const c of bench) expect(entrants.has(c.id)).toBe(false);
  });

  it('names each round', () => {
    expect(getAscentRoundName(1)).toContain('Opening');
    expect(getAscentRoundName(2)).toContain('Survivors');
    expect(getAscentRoundName(3)).toContain('Grand Final');
  });
});
