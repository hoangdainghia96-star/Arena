import { afterEach, describe, expect, it, vi } from 'vitest';

(globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
import { act } from 'react';
import { createRoot, Root } from 'react-dom/client';
import React from 'react';
import { BattleSpectatorView } from '../src/components/BattleSpectatorView';
import { ARENA_DEFINITIONS } from '../src/data/arenas';
import { DEFAULT_ARENA_SETTINGS } from '../src/data/settings';
import { INITIAL_CHARACTER_ROSTER } from '../src/data/characters';

// jsdom has no WebGL — stub the renderer so the component tree can mount.
vi.mock('../src/rendering/arenaSceneRenderer', () => ({
  ArenaSceneRenderer: class {
    public telemetry = {
      fps: 60, frameTimeMs: 16.6, drawCalls: 0, triangles: 0,
      geometriesInMemory: 0, texturesInMemory: 0, jsHeapMb: null,
    };
    private bullet = { active: false, progress: 0, attackerId: null, victimId: null };
    constructor() {}
    applyQualityPreset() {}
    loadBattleScene() {}
    setCameraMode() {}
    handleResize() {}
    renderSimulationState() {}
    getBulletTimeState() { return { ...this.bullet }; }
    dispose() {}
  },
}));

const mounted: Array<{ root: Root; el: HTMLDivElement }> = [];

function mount(node: React.ReactElement) {
  const el = document.createElement('div');
  el.style.width = '1200px';
  el.style.height = '800px';
  Object.defineProperty(el, 'clientWidth', { value: 1200 });
  Object.defineProperty(el, 'clientHeight', { value: 800 });
  document.body.appendChild(el);
  const root = createRoot(el);
  act(() => { root.render(node); });
  mounted.push({ root, el });
  return el;
}

afterEach(() => {
  for (const { root, el } of mounted.splice(0)) {
    act(() => root.unmount());
    el.remove();
  }
});

describe('BattleSpectatorView integration smoke', () => {
  it('mounts, runs the live loop, and renders radar + HUD without crashing', async () => {
    const el = mount(
      React.createElement(BattleSpectatorView, {
        roster: INITIAL_CHARACTER_ROSTER,
        arenas: ARENA_DEFINITIONS,
        selectedArenaId: 'arena_sanctum',
        settings: { ...DEFAULT_ARENA_SETTINGS, autoSkipIntroCinematic: true },
        onUpdateSettings: () => {},
        activeReplayPayload: null,
        onClearReplay: () => {},
        onBattleArchived: () => {},
        onNavigate: () => {},
      })
    );

    // Let the staged asset loader + RAF loop advance
    await act(async () => { await new Promise((r) => setTimeout(r, 2500)); });

    expect(el.textContent).toContain('Live Tactical Radar');
    expect(el.textContent).toContain('Survivors');
    expect(el.textContent).toContain('Aetherium Sanctum');
    expect(el.querySelector('svg')).toBeTruthy();
  });
});
